"""Layout-only eager boundary immediately after the HSTU UVQK projection."""
import torch


def original(x):
    b,l,_ = x.shape
    u,v,q,k = torch.split(x, [64,64,64,64], dim=-1)
    return u, v.view(b,l,4,16).transpose(1,2), q.view(b,l,4,16).transpose(1,2), k.view(b,l,4,16).transpose(1,2)


def supported(x):
    return (x.ndim == 3 and x.size(-1) == 256 and x.is_contiguous() and
            x.dtype == torch.bfloat16 and x.device.type in ("cpu","npu") and x.shape[0] > 0 and x.shape[1] > 0)


class ProjectedLayout(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x):
        b,l,_ = x.shape
        ctx.dims = b,l
        if x.device.type == "cpu":
            return tuple(t.clone(memory_format=torch.contiguous_format) for t in original(x))
        from layout_kernels import unpack_four
        u = x.new_empty((b,l,64))
        v,q,k = (x.new_empty((b,4,l,16)) for _ in range(3))
        unpack_four[(b*l,)](x,u,v,q,k,l)
        return u,v,q,k

    @staticmethod
    @torch.autograd.function.once_differentiable
    def backward(ctx, gu,gv,gq,gk):
        b,l = ctx.dims
        if gu.device.type == "cpu":
            return torch.cat((gu, *(t.transpose(1,2).reshape(b,l,64) for t in (gv,gq,gk))),dim=-1)
        from layout_kernels import pack_four
        grad = gu.new_empty((b,l,256))
        pack_four[(b*l,)](gu,gv,gq,gk,grad,l,*gu.stride(),*gv.stride(),*gq.stride(),*gk.stride())
        return grad


def candidate(x):
    return ProjectedLayout.apply(x) if supported(x) else original(x)

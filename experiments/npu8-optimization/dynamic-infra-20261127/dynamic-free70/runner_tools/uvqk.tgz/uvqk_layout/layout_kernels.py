"""Copy [B,L,4,4,16] into contiguous U[B,L,64] and V/Q/K[B,4,L,16]."""
import triton
import triton.language as tl


@triton.jit
def unpack_four(x, u, v, q, k, length):
    token = tl.program_id(0)
    c = tl.arange(0, 64)
    batch = token // length
    seq = token % length
    offset = ((batch * 4 + c // 16) * length + seq) * 16 + c % 16
    row = token * 256 + c
    tl.store(u + token * 64 + c, tl.load(x + row))
    tl.store(v + offset, tl.load(x + row + 64))
    tl.store(q + offset, tl.load(x + row + 128))
    tl.store(k + offset, tl.load(x + row + 192))


@triton.jit
def pack_four(gu, gv, gq, gk, grad, length, u0, u1, u2, v0, v1, v2, v3,
              q0, q1, q2, q3, k0, k1, k2, k3):
    token = tl.program_id(0)
    c = tl.arange(0, 64)
    batch = token // length
    seq = token % length
    h, f = c // 16, c % 16
    row = token * 256 + c
    tl.store(grad + row, tl.load(gu + batch*u0 + seq*u1 + c*u2))
    tl.store(grad + row + 64, tl.load(gv + batch*v0 + h*v1 + seq*v2 + f*v3))
    tl.store(grad + row + 128, tl.load(gq + batch*q0 + h*q1 + seq*q2 + f*q3))
    tl.store(grad + row + 192, tl.load(gk + batch*k0 + h*k1 + seq*k2 + f*k3))

"""Match the eight HSTU attention matmuls to autograd sequence and real hardware."""
import argparse
from collections import Counter
import gzip
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"causal_tril"))
from core_budget import intersect,merge,ns,read_leg


def run(trace):
    cpu,free,_=read_leg(trace)
    with (gzip.open if trace.suffix==".gz" else open)(trace,"rt",encoding="utf-8-sig") as f:
        doc=json.load(f)
    rows=doc if isinstance(doc,list) else doc["traceEvents"]
    hwid,={r["pid"] for r in rows if r["name"]=="process_name" and r["args"]["name"]=="Ascend Hardware"}
    hw={(r["tid"],ns(r["ts"])):r for r in rows if r["ph"]=="X" and r["pid"]==hwid}
    starts={r["id"]:(r["tid"],ns(r["ts"])) for r in rows if r["ph"]=="s" and r.get("cat")=="async_npu"}
    tasks=[(*starts[r["id"]],hw[r["tid"],ns(r["ts"])]) for r in rows
           if r["ph"]=="f" and r.get("cat")=="async_npu" and r["pid"]==hwid and r["id"] in starts]
    out=[]
    for a,b,step,main,_ in (r for r in cpu if r[2].startswith("ProfilerStep#")):
        (fl,fr,*_),=[r for r in cpu if r[2]=="hstu_forward_and_loss" and a<=r[0] and r[1]<=b]
        fw=[r for r in cpu if r[2]=="aten::matmul" and r[3]==main and fl<=r[0] and r[1]<=fr]
        # The final tied projection is a 2-D MatMulCommon; the attention paths
        # are exactly the eight forward operations that submit BatchMatMul.
        def linked(r):
            return [t for tid,ts,t in tasks if tid==r[3] and r[0]<=ts<r[1]]
        fw=[r for r in fw if any("BatchMatMul" in t["name"] for t in linked(r))]
        if len(fw)!=8:
            raise ValueError(f"found {len(fw)} attention matmuls")
        seqs={r[4] for r in fw}
        bw=[r for r in cpu if r[2]=="MatmulBackward0" and r[4] in seqs]
        if len(bw)!=8:
            raise ValueError(f"found {len(bw)} attention matmul backwards")
        result={"step":step}
        for kind,scopes in (("fwd",fw),("bwd",bw)):
            ts=[t for r in scopes for t in linked(r)]
            parent=merge([r[:2] for r in scopes])
            result[kind]={"scopes":len(scopes),"wall_ms":sum(y-x for x,y in parent)/1e6,
                          "free_overlap_ms":intersect(parent,free)/1e6,
                          "real_device_tasks":len(ts),"by_name":dict(Counter(t["name"] for t in ts)),
                          "streams":dict(Counter(str(t["args"]["Physic Stream Id"]) for t in ts))}
        out.append(result)
    return out


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("trace",type=Path)
    p.add_argument("out",type=Path)
    args=p.parse_args()
    args.out.write_text(json.dumps(run(args.trace),indent=2)+"\n")

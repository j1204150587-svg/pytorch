"""Compare all projection gradients and the real causal-attention outputs after repacking."""
import argparse
import json
from pathlib import Path
import time

import torch
from torch.nn import functional as F
from layout import candidate, original


def compare(a,b):
    a,b=a.detach().cpu().contiguous(),b.detach().cpu().contiguous()
    mismatch=a.view(torch.int16) != b.view(torch.int16)
    return {"elements":a.numel(), "different":int(mismatch.sum()),
            "max_abs":float((a.float()-b.float()).abs().max()) if torch.isfinite(a).all() and torch.isfinite(b).all() else None}


def semantic_layer(split,x,dy):
    b,l,_=x.shape
    u,v,q,k=split(x)
    scores=torch.matmul(q,k.transpose(-2,-1)) * 0.25
    mask=torch.tril(torch.ones((l,l),dtype=torch.bool,device=x.device))
    causal=F.silu(scores).masked_fill(~mask,0.0) / float(l)
    attn=torch.matmul(causal,v).transpose(1,2).reshape(b,l,64)
    # Both uses of U are live, with the same gradient join as gate + concatenation.
    gate=F.silu(u)*attn
    y=torch.cat((gate,u),dim=-1)
    (dx,)=torch.autograd.grad((y.float()*dy).sum(),(x,))
    return (scores,causal,attn,y,dx)


def layout_gradient(split,x,grads):
    us=split(x)
    # Exercise the raw four-output Jacobian with four arbitrary, potentially strided gradients.
    loss=sum((s.float()*g.float()).sum() for s,g in zip(us,grads))
    (dx,)=torch.autograd.grad(loss,(x,))
    return dx


def run(device, repeats):
    rng=torch.Generator().manual_seed(1234)
    all_cases=[]
    inputs=[]
    for b,l in ((1,19),(2,14),(2,22),(4,31)):
        x=torch.randn((b,l,256),generator=rng).to(device=device,dtype=torch.bfloat16).requires_grad_()
        dy=torch.randn((b,l,128),generator=rng).to(device=device)
        source=torch.randint(-32768,32768,(b,l,256),generator=rng,dtype=torch.int16).to(device).view(torch.bfloat16)
        raw=[compare(a,z) for a,z in zip(original(source),candidate(source))]
        grads=[torch.randn((b,l,64),generator=rng).to(device=device,dtype=torch.bfloat16)]
        grads.extend(torch.randn((b,l,4,16),generator=rng).to(device=device,dtype=torch.bfloat16).transpose(1,2)
                     for _ in range(3))
        grad_check=compare(layout_gradient(original,x,grads),layout_gradient(candidate,x,grads))
        reference=semantic_layer(original,x,dy)
        changed=semantic_layer(candidate,x,dy)
        outputs={k:compare(a,z) for k,a,z in zip(("qk_scaled","causal","attn","output","dUVQK"),reference,changed)}
        all_cases.append({"shape":[b,l],"layout_bits":raw,"layout_gradient":grad_check,
                          "attention":outputs,"pass":all(d["different"]==0 for d in (*raw,grad_check,*outputs.values()))})
        inputs.append((x,dy))
    passed=all(z["pass"] for z in all_cases)
    times=[]
    if passed and device=="npu" and repeats:
        for i in range(8):
            semantic_layer(original,*inputs[i%4])
            semantic_layer(candidate,*inputs[i%4])
        for order in ("AB","BA","AB","BA"):
            pair={}
            for label in order:
                fn=original if label=="A" else candidate
                torch.npu.synchronize()
                start=time.perf_counter_ns()
                for i in range(repeats):
                    semantic_layer(fn,*inputs[i%4])
                torch.npu.synchronize()
                pair[label]=(time.perf_counter_ns()-start)/1000/repeats
            times.append({"order":order,"stock_us":pair["A"],"candidate_us":pair["B"],
                          "reduction_pct":(1-pair["B"]/pair["A"])*100})
    return {"device":device,"torch":str(torch.__version__),"pass":passed,"cases":all_cases,"timing":times}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--device",choices=("cpu","npu"),required=True)
    p.add_argument("--out",type=Path,required=True)
    p.add_argument("--repeats",type=int,default=48)
    args=p.parse_args()
    if args.device=="npu":
        import torch_npu
        torch.npu.set_device(0)
    else:
        torch.set_num_threads(2)
    report=run(args.device,args.repeats)
    args.out.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"pass":report["pass"],"timing":report["timing"]}))

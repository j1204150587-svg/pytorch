import dataclasses
import os
import sys
from contextlib import contextmanager
from itertools import count, zip_longest
from typing import Any, Optional, Union
from typing_extensions import Self

import sympy

import torch
from torch import dtype as torch_dtype
from torch._inductor import config
from torch._inductor.codecache import (
    CudaKernelParamCache,
    get_cpp_wrapper_cubin_path_name,
)
from torch._inductor.codegen.aoti_hipify_utils import maybe_hipify_code_wrapper
from torch._inductor.codegen.common import get_device_op_overrides
from torch._inductor.codegen.cpp_utils import cexpr, DEVICE_TO_ATEN, DTYPE_TO_CPP
from torch._inductor.codegen.cpp_wrapper_gpu import (
    cpp_string_literal,
    CppWrapperGpu,
    DeferredTritonCallWrapper,
    UnwrapUnspecArg,
)
from torch._inductor.codegen.multi_kernel import MultiKernelCall
from torch._inductor.codegen.wrapper import PythonWrapperCodegen, SymbolicCallArg
from torch._inductor.ir import GraphPartitionSignature
from torch._inductor.runtime.runtime_utils import dynamo_timed
from torch._inductor.utils import IndentedBuffer
from torch._inductor.virtualized import V

from .. import config as npu_config
from ..runtime.triton_heuristics import GridExprNpu
from ..utils import triton_support_ffts, triton_support_auto_blockify

# follow triton-ascend implement, except torch.bfloat16
# torch.bfloat16 -> "float" will be specially deal in codegen_tensor_item_npu
DTYPE_TO_TA_TYPE = {
    **DTYPE_TO_CPP,
    torch.bool: "int32_t"
}

@dataclasses.dataclass
class DeferredNpuTritonCallWrapper(DeferredTritonCallWrapper):
    """
    When using cpp wrapper, GPU kernel load and launch needs to wait for Triton kernels
    to be tuned and stored as cubin files, so use a deferred generating the final wrapper around
    the triton kernel until right before the prefix is written.
    """

    wrapper_name: str
    kernel_name: str
    kernel_name_to_body: dict[str, str]
    arg_types: list[Any]
    kernel_id: int

    @contextmanager
    def _patch_runtime_block_params(self):
        if self.kernel_name.startswith("multi_kernel_"):
            self.kernel_name = MultiKernelCall.lookup_choice(self.kernel_name)
        params = CudaKernelParamCache.get(self.kernel_name)
        if not params:
            raise RuntimeError(
                f"CudaKernelParamCache not populated for {self.kernel_name}"
            )

        original_def_args = params["def_args"]
        original_arg_types = self.arg_types
        inductor_meta = params["inductor_meta"]
        runtime_block_names = tuple(inductor_meta.get("runtime_block_arg_names", ()))

        try:
            if runtime_block_names:
                wrapper_def_args = [
                    name for name in original_def_args if name not in runtime_block_names
                ]
                params["def_args"] = wrapper_def_args

                if (
                    "extra_launcher_args" in inductor_meta
                    and len(wrapper_def_args) > len(original_arg_types)
                ):
                    expected_arg_count = len(original_arg_types) - len(
                        inductor_meta["extra_launcher_args"]
                    )
                    if len(wrapper_def_args) != expected_arg_count:
                        raise RuntimeError(
                            "wrapper_def_args and arg_types do not match for extra_launcher_args: "
                            f"{len(wrapper_def_args)} != {expected_arg_count}"
                        )
                    self.arg_types = original_arg_types + [SymbolicCallArg] * len(
                        inductor_meta["extra_launcher_args"]
                    )

            yield params
        finally:
            params["def_args"] = original_def_args
            self.arg_types = original_arg_types

    def generate(self, wrapper: CppWrapperGpu):
        with self._patch_runtime_block_params() as params:
            super().generate(wrapper)
            cubin_path = params[get_cpp_wrapper_cubin_path_name()]
            if cubin_path not in V.graph.wrapper_code.additional_files:
                V.graph.wrapper_code.additional_files.append(cubin_path)

    def generate_grid(
        self,
        prefix: IndentedBuffer,
        inductor_meta: dict[str, Any],
        params: dict[str, Any],
    ):
        numels = [arg for arg in params["def_args"] if "_numel" in arg]
        for block_name, block_value in dict(params.get("runtime_blocks", {})).items():
            prefix.writeline(f"int64_t {block_name} = {block_value};")
        grid = GridExprNpu.from_meta_and_set_numel(
            inductor_meta, params["config"], numels, "cpp"
        )
        for line in grid.prefix:
            prefix.writeline(line)
        prefix.splice(
            f"""\
            uint32_t grid_0 = {grid.x_grid};
            uint32_t grid_1 = {grid.y_grid};
            uint32_t grid_2 = {grid.z_grid};
            """
        )
        prefix.writeline("if (grid_0 == 0 || grid_1 == 0 || grid_2 == 0) return;")

    def generate_load_kernel(self, prefix, kernel_var_name, params):
        prefix.writeline(f"if ({kernel_var_name} == nullptr) {{")
        with prefix.indent():
            load_kernel_args = [
                cpp_string_literal(params[get_cpp_wrapper_cubin_path_name()]),
                cpp_string_literal(params["mangled_name"]),
                # add mix_mode into kernel load param
                cpp_string_literal(params["mix_mode"]),
                str(params["shared_mem"]),
                "cubin_dir_",
            ]
            prefix.writeline(
                f"{kernel_var_name} = loadKernel({', '.join(load_kernel_args)}); "
            )
        prefix.writeline("}")

    def generate_launch_kernel(self, prefix, wrapper, kernel_var_name, params):
        triton_meta = params["triton_meta"]
        arg_type_lookup = dict(zip(params["def_args"], self.arg_types))
        for block_name in params["inductor_meta"].get("runtime_block_arg_names", ()):
            arg_type_lookup.setdefault(block_name, SymbolicCallArg)
        # difference between Python and C++ wrapper: C++ wrapper strips out equal_to_1 constants
        call_args = [
            name for name in params["call_args"] if name not in triton_meta["constants"]
        ]
        arg_types = [arg_type_lookup[name] for name in call_args]
        arg_signatures = [triton_meta["signature"][name] for name in call_args]
        force_simt_only = npu_config.is_ascend950 and params["force_simt_only"]
        enable_simt = npu_config.is_ascend950 and (
            "simt" in params["parallel_mode"] or params["force_simt_only"]
        )
        enable_auto_blockify = not params.get("has_auto_blockify_blacklist_op", False) and triton_support_auto_blockify()
        prefix.splice(f"""
        auto launch_call = [=]() {{
        {wrapper.generate_args_decl(prefix, call_args, arg_types, arg_signatures, True, force_simt_only)}
        {wrapper.generate_launch_preparation(kernel_var_name, params, enable_simt, enable_auto_blockify)}
        }};
        """)
        prefix.writeline(
            r"launchKernel({}, {});".format("launch_call", f'"{kernel_var_name}"')
        )


class CppWrapperNpu(CppWrapperGpu):
    """
    Generates cpp wrapper for running on NPU and calls CUDA kernels
    """

    def __init__(self) -> None:
        self.device = "npu"
        self.device_codegen = get_device_op_overrides(self.device)
        super().__init__()

    @staticmethod
    def create(
        is_subgraph: bool,
        subgraph_name: Optional[str],
        parent_wrapper: Optional[PythonWrapperCodegen],
        partition_signatures: Optional[GraphPartitionSignature] = None,
    ):
        # comment at CppWrapperCpu `codegen_subgraph` function.
        return CppWrapperNpu()

    def write_header(self):
        if V.graph.is_const_graph:
            # We do not write header for constant graph, it will be written by main module.
            return

        self.header.splice("#include <torch_npu/csrc/inductor/aoti_runtime/model.h>")
        self.header.splice("#include <torch_npu/csrc/inductor/aoti_runtime/device_utils.h>")
        self.header.splice("#include <torch_npu/csrc/inductor/aoti_runtime/utils_npu.h>")
        self.header.splice(f"#include <torch_npu/csrc/inductor/aoti_torch/generated/c_shim_{self.device}.h>")

        if not V.graph.aot_mode:
            self.header.splice(
                """
                import torch
                from torch._inductor.codecache import CppWrapperCodeCache

                cpp_wrapper_src = (
                r'''
                """
            )

        for device in V.graph.device_types:
            if device != "meta":
                self.add_device_include(device)

        if V.graph.aot_mode:
            if config.aot_inductor.dynamic_linkage:
                self.header.splice(self._adapt_community_interface_cpp())
                self.header.splice("\n")
            else:
                # we produce a separate model header for each model in static linkage
                self.header.splice(f"""#include \"{self.model_class_name_suffix}.h\"""")
            self.header.splice("\n")

        if config.cpp.enable_kernel_profile:
            self.header.splice(
                "#include <torch/csrc/inductor/aoti_runtime/kernel_context_tls.h>"
            )
            self.header.splice(
                """
                namespace torch::aot_inductor {
                thread_local KernelContext* tls_kernel_context = nullptr;
                }
                """
            )

        self.header.splice(
            maybe_hipify_code_wrapper(self.device_codegen.kernel_driver())
        )

    @staticmethod
    def _adapt_community_interface_cpp() -> str:
        """Reuse the upstream interface.cpp from torch and adapt it for NPU.

        Instead of maintaining a duplicated copy, read the community
        interface.cpp and apply the minimal NPU-specific transformations:
        - Redirect model_container.h include to the torch_npu variant, since
          NPU ships its own model container implementation.
        - Default to "npu" instead of "cuda" in AOTInductorModelContainerCreate.
        """
        community_interface_path = os.path.join(
            os.path.dirname(torch.__file__),
            "_inductor",
            "codegen",
            "aoti_runtime",
            "interface.cpp",
        )
        with open(community_interface_path) as f:
            content = f.read()
        content = content.replace(
            "<torch/csrc/inductor/aoti_runtime/model_container.h>",
            "<torch_npu/csrc/inductor/aoti_runtime/model_container.h>",
        )
        content = content.replace("cuda", "npu")
        return content

    def generate_node_numel_expr(self, kernel_name: str, node, numel_expr):
        expr = f"{kernel_name}_{node.name}_numel"

        if (expr, V.graph) not in self.kernel_numel_expr:
            # declare expr once in each graph (scope)
            self.kernel_numel_expr.add((expr, V.graph))
            self.writeline(f"int64_t {expr} = {cexpr(numel_expr)};")
        else:
            self.writeline(f"{expr} = {cexpr(numel_expr)};")
        return SymbolicCallArg(expr, numel_expr)

    def _generate_kernel_call_helper(
        self,
        kernel_name: str,
        call_args,
        *,
        device=None,
        triton=True,
        arg_types=None,
        raw_keys=None,
        raw_args=None,
        triton_meta=None,
        graph_name="",
        original_fxnode_name=None,
    ):
        if (
            not triton
            and not V.graph.aot_mode
            and kernel_name in self.initialized_kernels
        ):
            # CATLASS kernel in JIT cpp_wrapper mode.
            #
            # In the community CUTLASS flow, AOT mode links the kernel .o into
            # model.so and calls it through a function pointer in the
            # AOTInductorModelKernels class (kernels.<name>(...)).  In JIT mode
            # the community does not support CUTLASS cpp_wrapper.  We extend it
            # by loading the standalone .so via dlopen/dlsym at first call,
            # which is the CATLASS analog of Triton's loadKernel/launchKernel
            # pattern.  The load_* helper and function pointer are emitted in
            # finalize_prefix().
            device = device or V.graph.get_current_device_or_throw()
            stream = self.write_get_raw_stream(device.index, graph_name)

            # Build the casted argument list (same logic as CppWrapperGpu).
            casted = []
            for arg_type, arg in zip(arg_types, call_args):
                new_arg = arg
                if isinstance(arg_type, str) and arg_type.endswith("*") and arg != "nullptr":
                    new_arg = f"{arg}.data_ptr()"
                casted.append(f"({arg_type}){cexpr(new_arg)}")
            call_args_str = ", ".join(casted)

            # Lazy-load the .so on first call, then invoke through the
            # function pointer.
            self.writeline(f"load_{kernel_name}();")
            # Synchronize the stream before launching the catlass kernel.
            # Catlass kernels read input tensors (e.g., offsets/group_list
            # produced by aten ops like cumsum) directly from device memory.
            # Aten ops in cpp_wrapper use the implicit "current stream" which
            # may differ from the explicit stream used by catlass, or the
            # AscendC <<<>>> launch may not fully respect stream ordering with
            # preceding aten ops.  This sync ensures all prior operations
            # (including aten ops that produce catlass inputs) have completed
            # before the catlass kernel reads them.
            self.writeline(f"aclrtSynchronizeStream({stream});")
            self.writeline(f"{kernel_name}({call_args_str}, {stream});")
            return

        super()._generate_kernel_call_helper(
            kernel_name,
            call_args,
            device=device,
            triton=triton,
            arg_types=arg_types,
            raw_keys=raw_keys,
            raw_args=raw_args,
            triton_meta=triton_meta,
            graph_name=graph_name,
            original_fxnode_name=original_fxnode_name,
        )
        wrapper_name = f"call_{kernel_name}"
        if wrapper_name in self._triton_call_wrappers:
            # trans DeferredTritonCallWrapper to DeferredNpuTritonCallWrapper
            wrapper = self._triton_call_wrappers[wrapper_name]
            current_kernel_id = next(self.kernel_callsite_id)
            npu_wrapper = DeferredNpuTritonCallWrapper(
                wrapper_name=wrapper.wrapper_name,
                kernel_name=wrapper.kernel_name,
                arg_types=wrapper.arg_types,
                kernel_name_to_body=self._kernel_name_to_body,
                kernel_id=current_kernel_id,
            )
            self._triton_call_wrappers[wrapper_name] = npu_wrapper

    @staticmethod
    def get_device_include_path(device: str) -> str:
        common_include = f"""
        #include <fstream>
        #include <acl/acl.h>
        #include <acl/acl_rt.h>
        #include <runtime/runtime/rt.h>
        #include <torch_npu/csrc/core/npu/NPUStream.h>
        #include <torch_npu/csrc/framework/OpCommand.h>
        """
        if V.graph.aot_mode:
            return f"""
        {common_include}
        #include <torch_npu/csrc/inductor/aoti_runtime/model_container.h>
        #include <torch_npu/csrc/inductor/aoti_include/{device}.h>
        """
        return f"""
        {common_include}
        #include <torch_npu/csrc/inductor/cpp_wrapper/{device}.h>
        """

    def add_device_include(self, device: str) -> None:
        if device in self.included_devices:
            return

        self.included_devices.add(device)

        # Add the default header for this device, plus any C-shim extensions that are
        # present.
        self.header.splice(self.get_device_include_path(device))
        extend_aoti_c_shim_include = (
            f"torch_npu/csrc/inductor/aoti_torch/generated/extend/c_shim_{self.device}.h"
        )
        extend_aoti_c_shim_path = os.path.join(
            os.path.dirname(torch.__file__),
            "include",
            extend_aoti_c_shim_include,
        )
        if os.path.exists(extend_aoti_c_shim_path):
            self.header.splice(f"#include <{extend_aoti_c_shim_include}>")

    def generate(self, is_inference):
        with dynamo_timed("CppWrapperNpu.generate", log_pt2_compile_event=True):
            return super().generate(is_inference)

    def finalize_prefix(self):
        """Generate C++ declarations for CATLASS kernels before the parent
        finalises the prefix.

        AOT mode:
            The parent ``codegen_model_kernels()`` (called via
            ``CppWrapperCpu.finalize_prefix``) emits ``extern "C"`` declarations
            and function-pointer bindings for every kernel in
            ``initialized_kernels``, and the CATLASS .o files are linked into
            model.so via ``CATLASSCodeCache.aot_kernels_o`` — exactly the same
            flow as the community CUTLASS backend.

        JIT cpp_wrapper mode:
            The community does not support CUTLASS in JIT cpp_wrapper.  We
            extend it by emitting a function-pointer typedef, a static pointer
            initialised to ``nullptr``, and a ``load_*`` helper that uses
            ``dlopen``/``dlsym`` on first call.  The .so path is computed from
            ``src_to_kernel`` + ``_catlass_kernel_is_mix`` (populated in
            ``CATLASSScheduling.define_kernel``) so that no redundant
            compilation is triggered.
        """
        old_prefix = self.prefix

        # Generate C++ declarations for CATLASS kernels (JIT mode only).
        self.prefix = IndentedBuffer()
        if not V.graph.aot_mode and self.initialized_kernels:
            import textwrap as _textwrap
            from torch_npu._inductor.codecache import CATLASSCodeCache

            # Build reverse lookup: kernel_name -> original src_code
            src_to_kernel = V.graph.wrapper_code.src_to_kernel
            kernel_to_src = {v: k for k, v in src_to_kernel.items()}
            is_mix_map = getattr(V.graph.wrapper_code, "_catlass_kernel_is_mix", {})

            # Ensure <dlfcn.h> is available for dlopen/dlsym.
            self.prefix.writeline("#include <dlfcn.h>")
            self.prefix.writeline("")

            # CATLASS kernels use catlass-native type names (bfloat16_t, half)
            # in their signatures.  Provide aliases so the C++ wrapper code
            # (which uses the at:: namespace) can reference them.
            self.prefix.writeline("// CATLASS-native type aliases for cpp_wrapper")
            self.prefix.writeline("using bfloat16_t = at::BFloat16;")
            self.prefix.writeline("using half = at::Half;")
            self.prefix.writeline("")

            for kernel_name, kernel in self.initialized_kernels.items():
                signature = kernel.get_signature()

                # Build a typedef by replacing the function name with
                # "(*typedef_name)".
                typedef_sig = signature.replace(
                    kernel_name, f"(*{kernel_name}_t)"
                )
                self.prefix.writeline(f"typedef {typedef_sig};")
                self.prefix.writeline(
                    f"static {kernel_name}_t {kernel_name} = nullptr;"
                )
                self.prefix.writeline(
                    f"static void* {kernel_name}_so_handle = nullptr;"
                )
                self.prefix.writeline("")

                # Compute the .so path from the source code that
                # async_compile.catlass() will compile.  We must use the
                # *exact* source string: splice(src_code, strip=True)
                # produces "\n" + textwrap.dedent(src_code).strip() + "\n".
                # CATLASSCodeCache.write() only writes the .cpp source file
                # (no compilation), so this is cheap and the resulting path
                # matches the .so that async_compile.catlass() produces.
                original_src = kernel_to_src.get(kernel_name, "")
                compiled_src = original_src.replace("KERNEL_NAME", kernel_name)
                autotune_src = "\n" + _textwrap.dedent(compiled_src).strip() + "\n"
                is_mix = is_mix_map.get(kernel_name, False)
                _key, _input_path = CATLASSCodeCache.write(
                    autotune_src, "so", is_mix
                )
                so_path = (
                    _input_path[: -len(CATLASSCodeCache._SOURCE_CODE_SUFFIX)] + "so"
                )

                self.prefix.splice(f"""
static inline void load_{kernel_name}() {{
    if ({kernel_name} == nullptr) {{
        const char* so_path = "{so_path}";
        {kernel_name}_so_handle = dlopen(so_path, RTLD_NOW);
        if ({kernel_name}_so_handle == nullptr) {{
            throw std::runtime_error(std::string("Failed to dlopen catlass kernel: ") + so_path + " error: " + dlerror());
        }}
        {kernel_name} = reinterpret_cast<{kernel_name}_t>(dlsym({kernel_name}_so_handle, "{kernel_name}"));
        if ({kernel_name} == nullptr) {{
            throw std::runtime_error(std::string("Failed to dlsym catlass kernel '{kernel_name}' in: ") + so_path + " error: " + dlerror());
        }}
    }}
}}
""")
                self.prefix.writeline("")

        catlass_prefix = self.prefix

        # Now let the parent (CppWrapperGpu -> CppWrapperCpu) do its work.
        # In AOT mode, this calls codegen_model_kernels() which emits
        # extern "C" declarations and function-pointer bindings for
        # initialized_kernels — the same flow as community CUTLASS.
        self.prefix = IndentedBuffer()
        super().finalize_prefix()

        # Prepend our CATLASS declarations.
        self.prefix.splice(catlass_prefix)
        self.prefix.writeline("\n")
        self.prefix.splice(old_prefix)

    def codegen_tensor_item_npu(
        self, dtype: torch.dtype, tensor: str, scalar: str, indented_buffer=None
    ):
        dtype_str = str(dtype).split(".")[-1]
        writer = indented_buffer or self

        if dtype == torch.float16 or dtype == torch.bfloat16:
            scalar_tmp = f"{scalar}_tmp"
            writer.writeline(f"{DTYPE_TO_TA_TYPE[dtype]} {scalar_tmp};")
            writer.writeline(
                f"AOTI_TORCH_ERROR_CODE_CHECK(aoti_torch_item_{dtype_str}({tensor}, &{scalar_tmp}));"
            )
            writer.writeline(f"float {scalar} = float({scalar_tmp});")
            struct_data = f"float {scalar} __attribute__((aligned(4)));"
            arg_data = f"static_cast<float>({scalar})"
        else:
            writer.writeline(f"{DTYPE_TO_TA_TYPE[dtype]} {scalar};")
            writer.writeline(
                f"AOTI_TORCH_ERROR_CODE_CHECK(aoti_torch_item_{dtype_str}({tensor}, &{scalar}));"
            )
            struct_data = f"{DTYPE_TO_TA_TYPE[dtype]} {scalar} __attribute__((aligned(sizeof({DTYPE_TO_TA_TYPE[dtype]} ))));"
            arg_data = f"static_cast<{DTYPE_TO_TA_TYPE[dtype]}>({scalar})"

        return struct_data, arg_data

    def codegen_device(self, device):
        if device.type not in DEVICE_TO_ATEN:
            raise RuntimeError(device.type + "not found in DEVICE_TO_ATEN")
        device_str = DEVICE_TO_ATEN[device.type][5:].lower()  # remove "at::k"
        if device_str == "privateuse1":
            device_str = "npu"
        self.used_cached_devices.add(device_str)
        return f"cached_torch_device_type_{device_str}, {device.index if device.index else 0}"

    def generate_args_decl(
        self,
        code: Union[IndentedBuffer, Self],
        call_args,
        arg_types,
        arg_signatures,
        is_triton_kernel=True,
        force_simt_only=False,
    ):
        """
        Generates any declarations of args to pass into a kernel call, and then returns the arg names.

        In more detail:
        * declarations: e.g. this function has a side effect of generating lines like `auto var_0 = ...;`
        * returns: a string with the list of args, e.g. "var_0, var_1"

        call_args: list of call arguments
        arg_types: list of argument types
        arg_signatures: list with signatures of all the args
        is_triton_kernel: whether these are passed into a triton kernel or not. In particular,
                          calls to triton kernels will have an additional global scratch space
                          arg injected at the front of the arg list.
        """

        # Add more cases for other types as needed
        signature2dtype = {
            "i1": "int32_t",
            "i8": "int8_t",
            "i16": "int16_t",
            "i32": "int32_t",
            "i64": "int64_t",
            "u1": "uint32_t",
            "u8": "uint8_t",
            "u16": "uint16_t",
            "u32": "uint32_t",
            "u64": "uint64_t",
            "fp16": "float",
            "bf16": "float",
            "fp32": "float",
            "f32": "float",
            "fp64": "double",
        }

        struct_def_body = ""
        struct_arg_body = ""

        target_support_ffts = triton_support_ffts()

        def process_args(arg, arg_type, arg_signature=None):
            var_name = f"var_{next(self.arg_var_id)}"
            # ignore nvTmaDesc, as host-side TMA descriptors need
            # to be passed to the compiled Triton kernel by value
            if isinstance(arg_type, UnwrapUnspecArg) and arg_signature != "nvTmaDesc":
                struct_data, arg_data = self.codegen_tensor_item_npu(
                    arg_type.dtype,
                    arg,
                    var_name,
                    indented_buffer=code,
                )
            elif isinstance(arg_type, torch_dtype) and arg_signature != "nvTmaDesc":
                device_ptr_type = self.device_codegen.cpp_device_ptr()
                code.writeline(
                    maybe_hipify_code_wrapper(
                        f"{device_ptr_type} {var_name} = reinterpret_cast<{device_ptr_type}>({arg}.data_ptr());"
                    )
                )
                struct_data = f"void* {var_name} __attribute__((aligned(8)));"
                arg_data = f"static_cast<void*>({var_name})"
            elif arg_type in (sympy.Integer, int):
                code.writeline(f"int32_t {var_name} = {cexpr(arg)};")
                struct_data = f"int32_t {var_name} __attribute__((aligned(4)));"
                arg_data = f"static_cast<int32_t>({var_name})"
            elif arg_type in (sympy.Float, float):
                code.writeline(f"float {var_name} = {cexpr(arg)};")
                struct_data = f"float {var_name} __attribute__((aligned(4)));"
                arg_data = f"static_cast<float>({var_name})"
            # For symbolic call arguments, examine the arg signatures from triton meta
            # to explicitly cast to the right type
            # Reason: `auto` can infer unexpected type against kernel input signature.
            elif (
                isinstance(arg_type, type(SymbolicCallArg))
                and arg_signature is not None
                and arg_signature in signature2dtype
            ):
                arg_dtype = signature2dtype[arg_signature]
                code.writeline(f"{arg_dtype} {var_name} = {cexpr(arg)};")
                struct_data = f"{arg_dtype} {var_name} __attribute__((aligned(sizeof({arg_dtype}))));"
                arg_data = f"static_cast<{arg_dtype}>({var_name})"
            else:
                raise TypeError("Infer arg_type to cpp failed!")
            nonlocal struct_def_body
            nonlocal struct_arg_body
            struct_def_body += struct_data + " "
            struct_arg_body += arg_data + ", "

        for arg, arg_type, arg_signature in zip_longest(
            call_args, arg_types, arg_signatures
        ):
            process_args(arg, arg_type, arg_signature)

        ffts_str = """
            void* ffts_addr = NULL;
            ret = aclrtGetHardwareSyncAddr(&ffts_addr);
            if (ret != ACL_SUCCESS) {
                throw std::runtime_error(std::string("aclrtGetHardwareSyncAddr failed, 0x") + std::to_string(ret));
            }
            """

        args_str = f"""
            aclError ret;
            {ffts_str if target_support_ffts else ""}
            {"void* workspace_addr = NULL;" if not force_simt_only else ""}
            {"void* sync_block_lock = NULL;" if not force_simt_only else ""}
            struct __attribute__((packed)) {{
                {"void* ffts_addr __attribute__((aligned(8)));" if target_support_ffts else ""}
                {"void* sync_block_lock __attribute__((aligned(8)));" if not force_simt_only else ""}
                {"void* workspace_addr __attribute__((aligned(8)));" if not force_simt_only else ""}
                {struct_def_body}
                int32_t grid_0 __attribute__((aligned(4)));
                int32_t grid_1 __attribute__((aligned(4)));
                int32_t grid_2 __attribute__((aligned(4)));
            }} kernel_args = {{
                {"static_cast<void*>(ffts_addr)," if target_support_ffts else ""}
                {"static_cast<void*>(sync_block_lock)," if not force_simt_only else ""}
                {"static_cast<void*>(workspace_addr)," if not force_simt_only else ""}
                {struct_arg_body}
                static_cast<int32_t>(grid_0),
                static_cast<int32_t>(grid_1),
                static_cast<int32_t>(grid_2)
        }};"""

        return args_str

    def generate_launch_preparation(self, kernel_var_name, params, enable_simt, enable_auto_blockify):
        if enable_simt:
            shared_mem_dynamic_size = params["shared_mem_dynamic_size"]
            cpp_kernel_launch = f"""
            aclrtLaunchKernelAttr attrInfo = {{}};
            attrInfo.id = ACL_RT_LAUNCH_KERNEL_ATTR_DYN_UBUF_SIZE;
            aclrtLaunchKernelAttrValue value = {{}};
            value.localMemorySize = {shared_mem_dynamic_size};
            attrInfo.value = value;

            aclrtLaunchKernelCfg cfgCfgInfo = {{}};
            cfgCfgInfo.attrs = &attrInfo;
            cfgCfgInfo.numAttrs = 1;
            void* args = static_cast<void*>(&kernel_args);
            auto args_size = sizeof(kernel_args);
            ret = aclrtLaunchKernelWithHostArgs({kernel_var_name}, block_num, stream_, &cfgCfgInfo, args, args_size, nullptr, 0);
            """
        else:
            cpp_kernel_launch = f"""
            void* args = static_cast<void*>(&kernel_args);
            auto args_size = sizeof(kernel_args);
            ret = aclrtLaunchKernelWithHostArgs({kernel_var_name}, block_num, stream_, nullptr, args, args_size, nullptr, 0);
            """

        launch_str = f"""
            uint32_t block_num = grid_0 * grid_1 * grid_2;
            {f'block_num = std::min(block_num, (uint32_t){str(npu_config.num_vector_core)});' if enable_auto_blockify else ''}
            {cpp_kernel_launch}
            if (ret != ACL_SUCCESS) return ret;
            return ret;"""
        return launch_str

import itertools
from math import gcd
from typing import cast

import sympy

import torch
from torch._inductor import sizevars
from torch._inductor.ir import FloorDiv, ModularIndexing
from torch._inductor.loop_body import CaptureIndexing, LoopBody, MemoryUsageType
from torch._inductor.utils import has_free_symbols, sympy_index_symbol, sympy_subs
from torch._inductor.virtualized import V
from torch.utils._sympy.value_ranges import IntInfinity, ValueRanges

from ..config import inductor_indirect_memory_mode, is_ascend950, log
from .triton import NPUIndexTritonKernel
from .triton_utils import get_indirect_mem_var, get_indirect_var, NPUKernelType


def detect_flattened_dims(kernel, index):
    new_vars = {}  # noqa: set_linter
    if not isinstance(index, (sympy.core.add.Add, ModularIndexing, FloorDiv)):
        return new_vars

    def detect_flattened_axis(expr):
        def init_new_vars(var, length):
            if var not in new_vars:
                new_vars[var] = {length: [None, None]}
            if length not in new_vars[var]:
                new_vars[var][length] = [None, None]
        if isinstance(expr, ModularIndexing):
            var, divisor, length = expr.args
            if isinstance(var, sympy.Symbol):
                init_new_vars(var, length)
                new_vars[var][length][1] = (expr, divisor, length)
            else:
                # Handle complex expressions (e.g., s77**2) by checking if base symbols exist
                if hasattr(var, 'free_symbols') and var.free_symbols:
                    found_valid_symbol = False
                    for sym in var.free_symbols:
                        if sym in kernel.range_tree_nodes or sym in kernel.range_tree_nodes_removed:
                            log.warning(
                                "Skipping ModularIndexing with complex var %s, "
                                "base symbol %s found in range_tree_nodes",
                                var,
                                sym
                            )
                            found_valid_symbol = True
                            break
                    if not found_valid_symbol:
                        detect_flattened_axis(var)
                else:
                    detect_flattened_axis(var)
        elif isinstance(expr, FloorDiv):
            var, divisor = expr.args
            if isinstance(var, sympy.Symbol):
                init_new_vars(var, divisor)
                # var may be deleted from range_tree_nodes after node_schedule, check both dicts
                if var in kernel.range_tree_nodes:
                    numel = kernel.range_tree_nodes[var].length
                elif var in kernel.range_tree_nodes_removed:
                    numel = kernel.range_tree_nodes_removed[var].length
                else:
                    log.warning(
                        "Skipping FloorDiv with var %s not found in range_tree_nodes or range_tree_nodes_removed",
                        var
                    )
                    return

                length = expr.eval(numel, divisor)
                new_vars[var][divisor][0] = (expr, divisor, length)
            else:
                # Handle complex expressions (e.g., s77**2) by checking if base symbols exist
                if hasattr(var, 'free_symbols') and var.free_symbols:
                    found_valid_symbol = False
                    for sym in var.free_symbols:
                        if sym in kernel.range_tree_nodes or sym in kernel.range_tree_nodes_removed:
                            log.warning(
                                "Skipping FloorDiv with complex var %s, "
                                "base symbol %s found in range_tree_nodes",
                                var,
                                sym
                            )
                            found_valid_symbol = True
                            break
                    if not found_valid_symbol:
                        detect_flattened_axis(var)
                else:
                    detect_flattened_axis(var)
        else:
            for x in expr.args:
                detect_flattened_axis(x)


    # add
    if isinstance(index, sympy.core.add.Add):
        for x in index.args:
            detect_flattened_axis(x)
    elif isinstance(index, (ModularIndexing, FloorDiv)):
        detect_flattened_axis(index)
    else:
        pass

    # make sure FloorDiv, ModularIndexing must be in-pair
    for var, divisors in new_vars.items():
        if var in kernel.range_tree_nodes:
            parent_axis = kernel.range_tree_nodes[var]
        elif var in kernel.range_tree_nodes_removed:
            parent_axis = kernel.range_tree_nodes_removed[var]
        else:
            continue

        for divisor, pair in divisors.items():
            if not pair[0] and not pair[1]:
                pass
            # FloorDiv not inplace
            elif not pair[0]:
                # _, _, length = pair[1]
                mod_expr, divisor_value, length = pair[1]
                floor_divisor = length
                if isinstance(divisor_value, sympy.Integer) and divisor_value == 1:
                    floor_divisor = length
                elif isinstance(divisor_value, sympy.Symbol) and isinstance(length, sympy.Symbol):
                    floor_divisor =  sympy.expand(divisor_value * length)
                expr = FloorDiv(var, floor_divisor)
                parent_axis_length = parent_axis.length
                if isinstance(parent_axis.length, sympy.core.mul.Mul) and str(parent_axis.length) in kernel.axioms_index_map.keys() and str(length) not in str(parent_axis.length):
                    if kernel.axioms_index_map.get(str(parent_axis.length)).lhs == parent_axis.length:
                        parent_axis_length = kernel.axioms_index_map.get(str(parent_axis.length)).rhs
                new_vars[var][divisor][0] = (expr, floor_divisor, parent_axis_length // floor_divisor)
            # ModularIndexing not inplace
            elif not pair[1]:
                expr = ModularIndexing(var, 1, divisor)
                new_vars[var][divisor][1] = (expr, 1, divisor)
            else:
                pass

    return new_vars


def _should_skip_store_substitution(key, index, var, has_multiple_expansions, kernel, has_multi_symbol_divisor):
    if not (hasattr(kernel, "store_index_keys") and key in kernel.store_index_keys):
        if has_multi_symbol_divisor:
            return True
        return False
    if not has_multiple_expansions:
        return False
    if var not in index.free_symbols:
        return False
    if has_multi_symbol_divisor:
        return True

    prefix = str(var)[0]
    same_prefix_symbols = sorted(
        [
            sym
            for sym in index.free_symbols
            if getattr(sym, "name", str(sym)).startswith(prefix)
        ],
        key=str,
    )
    return len(same_prefix_symbols) == 1 and same_prefix_symbols[0] == var


def rebuild_flattened_dims(indexing):
    """
    Rebuild flattened dimensions in indexing expressions.

    This function processes indexing expressions to detect and rebuild
    flattened dimensions. For Store indices with unified anchors
    (symbols that have multiple expansion candidates), the processing
    is is skipped to preserve the unified axis.
    """

    def rebuild_flattened_dim(key, index, old_node, flatten_dim):
        for pair in flatten_dim.values():
            new_var_expr = sympy.Integer(0)
            origin_axis_length = 0
            # don't create duplicated axis, e.g. y1:1024, y1 % 1024 is duplicated
            expr, divisor, length = pair[1]
            if not old_node.parent.duplicated_check(divisor, length):
                if expr not in V.kernel.expr_substituted:
                    V.kernel.expr_substituted[expr] = old_node.symbol()
                break

            for axis in pair:
                expr, divisor, length = axis
                # 3. try to rebuild the axis in kernel
                new_node = old_node.parent.lookup(divisor, length)

                # 4. substitute div/mod expression in indexing
                if isinstance(expr, FloorDiv):
                    new_var_expr = new_var_expr + new_node.symbol() * divisor
                    origin_axis_length = divisor * length
                elif isinstance(expr, ModularIndexing):
                    new_var_expr = new_var_expr + new_node.symbol()
                V.kernel.expr_substituted[expr] = new_node.symbol()

            if old_node.symbol() not in V.kernel.range_tree_nodes_substituted:
                V.kernel.range_tree_nodes_substituted[old_node.symbol()] = []
            V.kernel.range_tree_nodes_substituted[old_node.symbol()].append(
                (origin_axis_length, new_var_expr)
            )

            log.debug(
                "rebuild_flattened_dim: key=%s, old_node=%s, new_var_expr=%s",
                key,
                old_node.symbol(),
                new_var_expr,
            )

    def find_index_in_substitute(index, kernel):
        from collections import defaultdict
        divisors = defaultdict(set)

        for key in kernel.expr_substituted.keys():
            if isinstance(key, ModularIndexing):
                dividend = key.args[0]
                divisor = key.args[2]
                divisors[dividend].add(divisor)
            elif isinstance(key, FloorDiv):
                dividend = key.args[0]
                divisor = key.args[1]
                divisors[dividend].add(divisor)
        for key in kernel.expr_substituted:
            if len(divisors) > 0:
                for dividend, ds in divisors.items():
                    if str(dividend) in str(key) and index.find(key) and len(ds) == 1:
                        return True
            else:
                if index.find(key):
                    return True
        return False

    kernel = V.kernel

    log.debug(
        "rebuild_flattened_dims: indexing_keys=%s, range_tree_nodes=%s",
        list(indexing.keys()),
        list(kernel.range_tree_nodes.keys()),
    )

    # Process non-Store indices first to populate range_tree_nodes_substituted.
    # Then process Store indices and skip those with unified anchors
    # (symbols that have multiple expansion candidates).
    store_keys = getattr(kernel, "store_index_keys", {})  # noqa: set_linter
    store_items = []

    for key, index in indexing.items():
        if key in store_keys:
            store_items.append((key, index))
            continue

        # 1. try to find out flattened axis from indexing
        flatten_dims = detect_flattened_dims(kernel, index)

        # 2. try to rebuild these flattened dims
        for var, flatten_dim in flatten_dims.items():
            if var in kernel.range_tree_nodes:
                old_node = kernel.range_tree_nodes[var]
            elif var in kernel.range_tree_nodes_removed:
                old_node = kernel.range_tree_nodes_removed[var]
            else:
                continue

            rebuild_flattened_dim(key, index, old_node, flatten_dim)

    for key, index in indexing.items():
        if find_index_in_substitute(index, kernel):
            new_index = sympy_subs(index, kernel.expr_substituted)
            indexing[key] = new_index

    log.debug(
        "rebuild_flattened_dims: range_tree_nodes_substituted=%s, store_items=%s",
        kernel.range_tree_nodes_substituted,
        store_items,
    )

    # Now process Store indices. Skip those containing a unified anchor:
    # a symbol that is the only one with its prefix in the Store index AND
    # has multiple expansion candidates in range_tree_nodes_substituted.
    for key, index in store_items:
        skip = False
        for sym in index.free_symbols:
            prefix = str(sym)[0]
            same_prefix_symbols = [
                s
                for s in index.free_symbols
                if getattr(s, "name", str(s)).startswith(prefix)
            ]
            # Check if this symbol is a unified anchor:
            # 1. It's the only symbol with this prefix in the Store index
            # 2. It has multiple expansion candidates (multiple expansion patterns)
            if (
                len(same_prefix_symbols) == 1
                and same_prefix_symbols[0] == sym
                and sym in kernel.range_tree_nodes_substituted
                and len(kernel.range_tree_nodes_substituted[sym]) > 1
            ):
                skip = True
                log.info(
                    "Skip Store index %s because %s is a unified anchor with multiple expansions",
                    key,
                    sym,
                )
                break

        if skip:
            continue

        flatten_dims = detect_flattened_dims(kernel, index)

        for var, flatten_dim in flatten_dims.items():
            if var in kernel.range_tree_nodes:
                old_node = kernel.range_tree_nodes[var]
            elif var in kernel.range_tree_nodes_removed:
                old_node = kernel.range_tree_nodes_removed[var]
            else:
                continue

            rebuild_flattened_dim(key, index, old_node, flatten_dim)

        if find_index_in_substitute(index, kernel):
            new_index = sympy_subs(index, kernel.expr_substituted)
            indexing[key] = new_index

    log.debug(
        "rebuild_flattened_dims: range_trees AFTER=%s",
        [(t.prefix, t.var_list) for t in kernel.range_trees],
    )


def substituted_dims_in_indexing(self, indexing, kernel, range_tree_nodes_substituted):
    substituted = False
    for var, candidates in range_tree_nodes_substituted.items():
        if not (len(candidates) > 0):
            raise RuntimeError("assert len(candidates) > 0, candidates")
        exprs = []
        has_multi_symbol_divisor = False
        remaining = list(candidates)
        while remaining:
            max_item = remaining[0]
            max_idx = 0
            for i in range(1, len(remaining)):
                if isinstance(remaining[i][0], sympy.core.mul.Mul) and isinstance(max_item[0], sympy.core.mul.Mul) and all(isinstance(arg, sympy.Symbol) for arg in remaining[i][0].args) and all(isinstance(arg, sympy.Symbol) for arg in max_item[0].args):
                    if (str(max_item[0]) in kernel.axioms_index_map.keys()) or (str(remaining[i][0]) in kernel.axioms_index_map.keys()):
                        if kernel.axioms_index_map.get(str(max_item[0])).lhs == remaining[i][0] or kernel.axioms_index_map.get(str(max_item[0])).rhs == remaining[i][0] or kernel.axioms_index_map.get(str(remaining[i][0])).lhs == max_item[0] or kernel.axioms_index_map.get(str(remaining[i][0])).rhs == max_item[0]:
                            has_multi_symbol_divisor = True
                            continue
                elif remaining[i][0] > max_item[0]:
                    max_item = remaining[i]
                    max_idx = i
            exprs.append(max_item)
            remaining.pop(max_idx)
        numel = exprs[0][0]
        expr = exprs[0][1]
        node = kernel.range_tree_nodes[var]
        if node.length != numel:
            log.debug(
                "sub nodes (expr%s, numel:%d) can not substitute parent node(%s:%d)",
                expr,
                numel,
                node.symbol(),
                node.length,
            )
            continue

        has_multiple_expansions = len(candidates) > 1

        for key, index in indexing.items():
            if _should_skip_store_substitution(
                key, index, var, has_multiple_expansions, kernel, has_multi_symbol_divisor
            ):
                log.info(
                    "Skip Store substitution for key=%s var=%s because Store unified anchor is preserved",
                    key,
                    var,
                )
                continue
            if var in index.free_symbols:
                index = index.subs(var, expr)
                indexing[key] = index
                substituted = True
    return substituted


def generate_body_indexing(body, indices):
    index = list(itertools.chain.from_iterable(indices))

    if not (len(index) == len(body.var_ranges)):
        raise RuntimeError(
            "assert len(index) == len(body.var_ranges), (index, body.var_ranges)"
        )
    if not (all(v not in body.var_ranges for v in index)):
        raise RuntimeError("assert all(v not in body.var_ranges for v in index)")

    replacements = dict(zip(body.var_ranges.keys(), index))
    indexing_map = dict(zip(index, body.var_ranges.keys()))
    body.indexing_map = indexing_map
    body.indexing = {
        name: sympy_subs(expr, replacements)
        for name, expr in body.indexing_exprs.items()
    }

    body.indirect_replacements = {}
    body.generate_indirect_replacements()

    body.masked_indexing = {}
    body.generate_masked_indexing()


def remove_zero_terms_impl(expr, var_ranges):
    shape_env = V.graph.sizevars.shape_env
    var_to_range = dict(shape_env.var_to_range)
    var_to_range.update(
        {
            k: ValueRanges(
                0, max(0, v - 1) if not has_free_symbols([v]) else IntInfinity()
            )
            for k, v in var_ranges.items()
        }
    )
    for var in expr.free_symbols:
        if var not in var_to_range:
            var_to_range[var] = ValueRanges(0, IntInfinity())

    var_to_range_tuple = cast(
        tuple[tuple[sympy.Symbol, ValueRanges[sympy.Expr]]],
        tuple(var_to_range.items()),
    )

    axioms = []
    for var, upper_bound in var_ranges.items():
        axioms.append(0 <= var)
        axioms.append(var < upper_bound)
    axioms = tuple(axioms) + shape_env.get_axioms()

    def statically_known(expr):
        evaluated = shape_env._maybe_evaluate_static(
            expr,
            axioms=axioms,
            var_to_range=var_to_range_tuple,
        )
        return bool(evaluated)

    def _remove_zero_terms(base, divisor):
        if statically_known(base < divisor):
            return sympy.Integer(0)
        return FloorDiv(base, divisor)

    replacements = {}
    for sub_expr in expr.atoms(FloorDiv):
        base, divisor = sub_expr.args
        if statically_known(base < divisor):
            replacements[sub_expr] = sympy.Integer(0)

    if replacements:
        expr = expr.xreplace(replacements)

    return expr


# Eliminate terms such as 2560(((320p1 + p2)//2560)) when (320*p1 + p2)//2560 is constantly zero
def remove_zero_terms(indexing, var_ranges):
    for key, expr in indexing.items():
        if expr.has(FloorDiv):
            new_expr = remove_zero_terms_impl(expr, var_ranges)
            indexing[key] = new_expr


def analyze_expression(expr, range_tree_nodes):
    """
    Analyze the entire expression, identify all FloorDiv and ModularIndexing expressions
    and determine if they can be split

    Parameters:
        expr: sympy expression
        range_tree_nodes: dictionary mapping symbols to range nodes

    Returns:
        Dict: analysis result dictionary
    """
    result = {
        "original_expr": str(expr),
        "floordiv_expressions": [],
        "modular_expressions": [],
        "can_split_all": True,
        "split_details": {},
    }

    # Recursively collect all FloorDiv and ModularIndexing expressions
    def collect_expressions(sub_expr, path=""):
        """Recursively collect FloorDiv and ModularIndexing expressions"""
        nonlocal result

        # If it's a FloorDiv expression
        if isinstance(sub_expr, FloorDiv):
            analysis = analyze_floordiv_expression(sub_expr, range_tree_nodes)
            analysis["path"] = path
            result["floordiv_expressions"].append(analysis)

            # Update the can_split_all flag
            if not analysis.get("can_split", True):
                result["can_split_all"] = False

        # If it's a ModularIndexing expression
        elif isinstance(sub_expr, ModularIndexing):
            analysis = analyze_modular_expression(sub_expr, range_tree_nodes)
            analysis["path"] = path
            result["modular_expressions"].append(analysis)

            # Check if it can be split
            if not analysis.get("can_split", True):
                result["can_split_all"] = False

        # Recursively process sub-expressions
        if hasattr(sub_expr, "args"):
            for i, arg in enumerate(sub_expr.args):
                collect_expressions(arg, f"{path}.args[{i}]")

    # Start collection
    collect_expressions(expr, "")
    return result


def calculate_max_remainder(coeff, length, divisor_or_mod):
    """
    Calculate the maximum remainder for term coeff * symbol, where symbol ∈ [0, length-1]

    Parameters:
        coeff: coeff
        length: length
        divisor_or_mod: divisor_or_mod

    Returns:
        result
    """
    # Try to convert coefficient and divisor/modulus to integers
    coeff_int = int(coeff) if isinstance(coeff, sympy.Integer) else None
    divisor_int = (
        int(divisor_or_mod) if isinstance(divisor_or_mod, sympy.Integer) else None
    )

    # If not integers, use conservative estimate
    if coeff_int is None or divisor_int is None:
        return min(divisor_or_mod - 1, coeff * (length - 1))

    # If coefficient is 0, remainder is always 0
    if coeff_int == 0:
        return 0

    # Calculate greatest common divisor
    g = gcd(coeff_int, divisor_int)

    # If length-1 is large enough, can reach maximum remainder divisor_int - g
    # The remainder period is divisor_int/g
    period = divisor_int // g

    # If symbol's value range covers the entire period, then maximum remainder is divisor_int - g
    if length - 1 >= period - 1:
        return divisor_int - g
    else:
        # Cannot reach maximum remainder, need to calculate the maximum remainder within the range [0, length-1]
        max_k = length - 1

        # Remainder sequence: 0, coeff, 2*coeff, ... mod divisor_int
        # We need to find k ∈ [0, max_k] such that (coeff_int * k) % divisor_int is maximized

        # Calculate maximum possible value
        max_possible = coeff_int * max_k

        if max_possible < divisor_int:
            # If maximum possible value is less than divisor, then maximum remainder is the maximum possible value
            return max_possible
        else:
            # Calculate max_possible % divisor_int
            remainder = max_possible % divisor_int

            # Find the largest multiple of g that does not exceed remainder
            # Because all remainders are multiples of g
            max_remainder = remainder // g * g
            start_k = max(0, max_k - period + 1)
            best_remainder = max_remainder

            for k in range(start_k, max_k + 1):
                r = (coeff_int * k) % divisor_int
                if r > best_remainder:
                    best_remainder = r

            return best_remainder


def analyze_floordiv_expression(expr, range_tree_nodes: dict) -> dict:
    """
    analyze_floordiv_expression for expr and range_tree_nodes

    Parameters:
        expr: expr
        range_tree_nodes: symbol's value range length (symbol ∈ [0, length-1])

    Returns:
        maximum remainder value
    """
    result = {
        "expression": str(expr),
        "type": "FloorDiv",
        "can_split": False,
        "reason": "",
        "details": {},
        "split_form": "",
    }

    if not isinstance(expr, FloorDiv):
        result["reason"] = "not FloorDiv expression"
        return result

    arg, divisor = expr.args[0], expr.args[1]
    free_symbols = arg.free_symbols
    num_symbols = len(free_symbols)

    result["details"]["divisor"] = divisor
    result["details"]["expr"] = arg
    result["details"]["num_symbols"] = num_symbols
    result["details"]["symbols"] = list(free_symbols)

    # Multi-dimensional memory access expressions (≥2 dimensions) require splitting;
    # unary(single-dimension) expressions do not.
    if num_symbols < 2:
        result["can_split"] = True
        result["reason"] = f"num_symbols {num_symbols} < 2, no need split"
        return result

    if not isinstance(arg, sympy.Add):
        result["reason"] = f"expr {arg} not sympy.Add expression, can not split"
        return result

    add_terms = arg.args
    max_remainder_sum = 0
    term_details = []

    for term in add_terms:
        term_info = {
            "term": term,
            "coeff": 1,
            "symbol": None,
            "length": None,
            "max_value": None,
            "max_remainder": None,
        }
        term_details.append(term_info)

        coeff = 1
        symbol = None

        if isinstance(term, sympy.Symbol):
            symbol = term
        elif isinstance(term, sympy.Mul):
            constant_factors = []
            for factor in term.args:
                if isinstance(factor, sympy.Symbol):
                    symbol = factor
                elif factor.is_number:
                    constant_factors.append(factor)

            if constant_factors:
                coeff = 1
                for cf in constant_factors:
                    coeff *= cf

        term_info["coeff"] = coeff
        term_info["symbol"] = symbol

        if symbol is None:
            result["reason"] = f"term {term} with no symbol"
            result["details"]["term_details"] = term_details
            return result

        if symbol not in range_tree_nodes:
            result["reason"] = f"symbol {symbol} not in range_tree_nodes"
            result["details"]["term_details"] = term_details
            return result

        length = range_tree_nodes[symbol].length
        term_info["length"] = length

        max_term_value = coeff * (length - 1)
        term_info["max_value"] = max_term_value

        max_remainder = calculate_max_remainder(coeff, length, divisor)
        term_info["max_remainder"] = max_remainder

        max_remainder_sum += max_remainder

    result["details"]["term_details"] = term_details
    result["details"]["max_remainder_sum"] = max_remainder_sum

    if max_remainder_sum < divisor:
        result["can_split"] = True
        result["reason"] = (
            f"expr can split, max_remainder_sum {max_remainder_sum} < divisor {divisor}"
        )

        split_terms = []
        for term in add_terms:
            split_terms.append(f"({term} // {divisor})")

        result["split_form"] = " + ".join(split_terms)
    else:
        result["reason"] = (
            f"expr can not split, max_remainder_sum {max_remainder_sum} >= divisor {divisor}"
        )

    return result


def analyze_modular_expression(expr, range_tree_nodes: dict) -> dict:
    """
    Analyze a single ModularIndexing expression

    Parameters:
        expr: ModularIndexing expression
        range_tree_nodes: dictionary mapping symbols to range nodes

    Returns:
        Dict: analysis result dictionary
    """
    result = {
        "expression": str(expr),
        "type": "ModularIndexing",
        "can_split": False,
        "reason": "",
        "details": {},
        "split_form": "",
    }

    # Check number of arguments
    args = expr.args
    if len(args) != 3:
        result["reason"] = f"ModularIndexing must have 3 args, but {len(args)} found"
        return result

    expr_to_mod, lower, upper = args

    # Check free symbols in expr_to_mod
    free_symbols = expr_to_mod.free_symbols
    num_symbols = len(free_symbols)

    result["details"]["expr_to_mod"] = expr_to_mod
    result["details"]["lower"] = lower
    result["details"]["upper"] = upper
    result["details"]["num_symbols"] = num_symbols
    result["details"]["symbols"] = list(free_symbols)

    if num_symbols < 2:
        result["can_split"] = True
        result["reason"] = f"num_symbols {num_symbols} < 2, no need split"
        return result

    # Check if expr_to_mod is an addition
    if not isinstance(expr_to_mod, sympy.Add):
        result["can_split"] = True
        result["reason"] = f"expr {expr_to_mod} not sympy.Add expression, no need split"
        return result

    # For ModularIndexing, the split condition is:
    # (expr1 % mod) + (expr2 % mod) < mod
    # where mod = upper - lower + 1

    mod = upper - lower + 1

    # Calculate the maximum sum of remainders
    add_terms = expr_to_mod.args
    max_remainder_sum = 0
    term_details = []

    for term in add_terms:
        term_info = {
            "term": term,
            "coeff": 1,
            "symbol": None,
            "length": None,
            "max_value": None,
            "max_remainder": None,
            "gcd_val": None,
            "period": None,
        }
        term_details.append(term_info)

        # Extract coefficient and symbol
        coeff = 1
        symbol = None

        if isinstance(term, sympy.Symbol):
            symbol = term
        elif isinstance(term, sympy.Mul):
            constant_factors = []
            for factor in term.args:
                if isinstance(factor, sympy.Symbol):
                    symbol = factor
                elif factor.is_number:
                    constant_factors.append(factor)

            if constant_factors:
                coeff = 1
                for cf in constant_factors:
                    coeff *= cf

        term_info["coeff"] = coeff
        term_info["symbol"] = symbol

        if symbol is None:
            result["reason"] = f"term {term} with no symbol"
            result["details"]["term_details"] = term_details
            return result

        # Get symbol's length
        if symbol not in range_tree_nodes:
            result["reason"] = f"symbol {symbol} not in range_tree_nodes"
            result["details"]["term_details"] = term_details
            return result

        node = range_tree_nodes[symbol]
        length = node.length
        term_info["length"] = length

        # Calculate maximum possible value
        max_term_value = coeff * (length - 1)
        term_info["max_value"] = max_term_value

        if coeff is not None and mod is not None:
            gcd_val = gcd(coeff, mod)
            term_info["gcd_val"] = gcd_val

            # Remainder period
            period = mod // gcd_val
            term_info["period"] = period

        max_remainder = calculate_max_remainder(coeff, length, mod)
        term_info["max_remainder"] = max_remainder

        max_remainder_sum += max_remainder

    result["details"]["term_details"] = term_details
    result["details"]["max_remainder_sum"] = max_remainder_sum
    result["details"]["mod"] = mod

    # Determine if it can be split
    if max_remainder_sum < mod:
        result["can_split"] = True
        result["reason"] = (
            f"expr can split, max_remainder_sum {max_remainder_sum} < mod {mod}"
        )

        # Generate the split expression form
        split_terms = []
        for term in add_terms:
            split_terms.append(f"ModularIndexing({term}, {lower}, {upper})")

        result["split_form"] = " + ".join(split_terms)
    else:
        result["reason"] = (
            f"expr can not split, max_remainder_sum {max_remainder_sum} >= mod {mod}"
        )

    return result


def extract_modular_indexing_coefficient(expr):
    """
    Extract coefficient from ModularIndexing expression

    Convert ModularIndexing(k*x, lower, upper) to k * ModularIndexing(x, lower, upper/k)
    Condition: k is a constant and can divide (upper - lower + 1)
    """
    if not isinstance(expr, ModularIndexing):
        return expr

    args = expr.args
    if len(args) != 3:
        return expr

    expr_to_mod, lower, upper = args

    # Check if expr_to_mod is a multiplication expression
    if isinstance(expr_to_mod, sympy.Mul):
        # Find constant coefficient
        coefficient = 1
        other_factors = []

        for factor in expr_to_mod.args:
            # Check if it's an integer constant
            if isinstance(factor, sympy.Integer) and factor.is_constant():
                coefficient = coefficient * factor
            else:
                other_factors.append(factor)

        # If a constant coefficient greater than 1 is found
        if coefficient != 1:
            # Calculate modulus range
            mod_range = upper - lower + 1

            # Check if coefficient can divide modulus range
            if mod_range % coefficient == 0:
                # Construct new ModularIndexing arguments
                if other_factors:
                    if len(other_factors) == 1:
                        new_expr = other_factors[0]
                    else:
                        new_expr = sympy.Mul(*other_factors)
                else:
                    # If no other factors, use 1
                    new_expr = sympy.Integer(1)

                # Calculate new upper bound
                new_upper = lower + mod_range // coefficient - 1

                # Create new ModularIndexing
                new_mod = ModularIndexing(new_expr, lower, new_upper)

                # Return coefficient multiplied by new ModularIndexing
                return coefficient * new_mod

    return expr


def eliminate_zero_term(term):
    expr, divisor = term.args
    if not isinstance(expr, sympy.Symbol):
        return term
    if expr in V.kernel.range_tree_nodes:
        numel = V.kernel.range_tree_nodes[expr].length
    elif expr in V.kernel.range_tree_nodes_removed:
        numel = V.kernel.range_tree_nodes_removed[expr].length
    else:
        return term

    length = term.eval(numel, divisor)
    if length == 0:
        return sympy.Integer(0)
    return term


def eliminate_modular(term):
    """
    Eliminate unnecessary ModularIndexing expressions

    When ModularIndexing(expr, lower, upper) has the same range as the entire range,
    it can be simplified to expr itself.

    Parameters:
        term: ModularIndexing expression

    Returns:
        Simplified expression or original expression
    """
    # If not a ModularIndexing expression, return directly
    if not isinstance(term, sympy.Function) or term.func.__name__ != "ModularIndexing":
        return term

    # Get arguments
    expr, lower, upper = term.args

    # Get symbol's length information
    def get_symbol_length(symbol: sympy.Symbol) -> int | None:
        """Get symbol's length (from range tree)"""
        if symbol in V.kernel.range_tree_nodes:
            return V.kernel.range_tree_nodes[symbol].length
        elif symbol in V.kernel.range_tree_nodes_removed:
            return V.kernel.range_tree_nodes_removed[symbol].length
        return None

    # Handle symbol expression
    if isinstance(expr, sympy.Symbol):
        numel = get_symbol_length(expr)
        if numel is not None:
            length = term.eval(numel, lower, upper)
            if length == numel:
                return expr

    # Handle multiplication expression
    elif isinstance(expr, sympy.Mul):
        # Try to extract coefficient and variable
        coeff = 1
        var = None

        for arg in expr.args:
            if isinstance(arg, sympy.Symbol):
                var = arg
            elif arg.is_number:
                coeff *= arg
            else:
                # Contains complex cases with non-symbols and non-numbers, not supported yet
                return term

        if var is not None:
            numel = get_symbol_length(var)
            if numel is not None:
                length = term.eval(numel, lower, upper)
                if length == numel:
                    return expr  # Return entire multiplication expression

    # Unsupported cases, return original expression
    return term


def split_expression(expr):
    """
    Split expression according to specified logic:
    1. If it's an Add/Mul expression, split into multiple args, recursively process each arg
    2. If it's a // expression (floor division), split it
    3. If it's a ModularIndexing expression, split it
    """
    # 1. If it's an Add expression
    if isinstance(expr, sympy.Add):
        # Recursively process each argument, then reconstruct Add
        new_args = [split_expression(arg) for arg in expr.args]
        return sympy.Add(*new_args)

    # 2. If it's a Mul expression
    elif isinstance(expr, sympy.Mul):
        # Recursively process each argument, then reconstruct Mul
        new_args = [split_expression(arg) for arg in expr.args]
        return sympy.Mul(*new_args)

    # 3. If it's a floor division expression
    elif isinstance(expr, FloorDiv):
        # Get floor arguments
        arg = expr.args[0]
        divisor = expr.args[1]

        # Check if arg is Add
        if isinstance(arg, sympy.Add):
            # Assume denominator is 1: floor(a+b) -> floor(a) + floor(b)
            split_terms = []
            for term in arg.args:
                new_term = FloorDiv(term, divisor)
                new_term = eliminate_zero_term(new_term)
                split_terms.append(new_term)
            return sympy.Add(*split_terms)

        # Cannot split, return original expression
        return expr

    # 4. If it's a ModularIndexing expression
    elif isinstance(expr, ModularIndexing):
        args = expr.args
        expr_to_mod, lower, upper = args

        # If first argument is Add, split it
        if isinstance(expr_to_mod, sympy.Add):
            # Split: ModularIndexing(a+b, lower, upper) ->
            # ModularIndexing(a, lower, upper) + ModularIndexing(b, lower, upper)
            split_terms = []
            for term in expr_to_mod.args:
                new_mod = ModularIndexing(term, lower, upper)
                # ModularIndexing(16*z0, 1, 128) -> 16*ModularIndexing(z0, 1, 8)
                new_mod = eliminate_modular(new_mod)
                new_mod = extract_modular_indexing_coefficient(new_mod)
                split_terms.append(new_mod)
            return sympy.Add(*split_terms)
        else:
            new_mod = ModularIndexing(expr_to_mod, lower, upper)
            new_mod = eliminate_modular(new_mod)
            new_mod = extract_modular_indexing_coefficient(new_mod)
            return new_mod

    # 5. Other types of expressions, return directly
    else:
        return expr


def has_dynamic_shape(var_ranges):
    """
    Check if any dimension in var_ranges is dynamic (unbacked symint)

    A dimension is considered dynamic if:
    1. Its length is a sympy Symbol (not a concrete value)
    2. Its length is a sympy expression containing free symbols
    This indicates the dimension size is not statically known at compile time.

    Args:
        var_ranges: Dict[sympy.Symbol, int/sympy.Expr]
                   Mapping from variable symbols to their range lengths

    Returns:
        bool: True if any dimension is dynamic, False otherwise
    """
    try:
        for length in var_ranges.values():
            # Check 1: If length is a pure Symbol, it's dynamic
            if isinstance(length, sympy.Symbol):
                return True

            # Check 2: If length has free symbols (expression with unknowns), it's dynamic
            if hasattr(length, "free_symbols"):
                free_syms = length.free_symbols
                if free_syms:
                    return True

            # Check 3: If length is not a concrete number, it's dynamic
            if not isinstance(length, (int, sympy.Integer)):
                return True

        return False

    except Exception:
        log.exception("Exception in checking dynamic shape")
        return False


def check_subexpr_for_dynamic_symbols(expr):
    """
    Recursively check if expression contains symbolic variables in problematic contexts.

    Checks ModularIndexing.upper and FloorDiv.divisor for symbolic variables.
    These parameters cause issues in linearization when they are symbolic.

    Args:
        expr: sympy expression to check

    Returns:
        bool: True if expression contains symbolic bounds, False otherwise
    """
    if isinstance(expr, ModularIndexing):
        args = expr.args
        if len(args) == 3:
            expr_to_mod, lower, upper = args
            # If upper is a symbol or has free symbols, it's dynamic
            if isinstance(upper, sympy.Symbol):
                return True
            if hasattr(upper, "free_symbols") and upper.free_symbols:
                return True

    elif isinstance(expr, FloorDiv):
        args = expr.args
        if len(args) >= 1:
            divisor = args[-1]
            # If divisor is a symbol or has free symbols, it's dynamic
            if isinstance(divisor, sympy.Symbol):
                return True
            if hasattr(divisor, "free_symbols") and divisor.free_symbols:
                return True

    # Recursively check args
    if hasattr(expr, "args"):
        for arg in expr.args:
            if check_subexpr_for_dynamic_symbols(arg):
                return True

    return False

def get_subexpr_for_dynamic_symbols(expr, range_tree_nodes, dim_symbol_index_map):
    """
    构建符号变量length
    """
    if isinstance(expr, ModularIndexing):
        args = expr.args
        if len(args) == 3:
            expr_to_mod, lower, upper = args
            build_symbol_index_map(range_tree_nodes, expr_to_mod, dim_symbol_index_map)
            build_symbol_index_map(range_tree_nodes, lower, dim_symbol_index_map)
            build_symbol_index_map(range_tree_nodes, upper, dim_symbol_index_map)
    elif isinstance(expr, FloorDiv):
        args = expr.args
        if len(args) == 2:
            dividend, divisor = args
            build_symbol_index_map(range_tree_nodes, dividend, dim_symbol_index_map)
            build_symbol_index_map(range_tree_nodes, divisor, dim_symbol_index_map)
    elif isinstance(expr, sympy.Symbol):
        build_symbol_index_map(range_tree_nodes, expr, dim_symbol_index_map)

    if hasattr(expr, "args"):
        for arg in expr.args:
            get_subexpr_for_dynamic_symbols(arg, range_tree_nodes, dim_symbol_index_map)



def build_symbol_index_map(range_tree_nodes, symbol_val, dim_symbol_index_map):
    if symbol_val not in dim_symbol_index_map and isinstance(symbol_val, sympy.Symbol) and symbol_val in range_tree_nodes:
        range_node = range_tree_nodes[symbol_val]
        length = range_node.length
        name = symbol_val.name
        dim_symbol_index_map[name] = length


def should_skip_linearization_on_a5(var_ranges, indexing):
    """
    Determine if memory access linearization should be skipped on A5 platform.

    On A5 platform, skip linearization when:
    1. var_ranges contain dynamic shapes (symbolic lengths)
    2. indexing expressions contain symbolic bounds in ModularIndexing/FloorDiv

    Args:
        var_ranges: Dict mapping symbols to their range lengths
        indexing: Dict mapping buffer names to index expressions

    Returns:
        bool: True if should skip linearization on A5, False otherwise
    """
    if not is_ascend950:
        return False

    # Check var_ranges for dynamic shapes
    if has_dynamic_shape(var_ranges):
        return True

    # Check indexing expressions for symbolic bounds
    if indexing:
        for index_expr in indexing.values():
            if check_subexpr_for_dynamic_symbols(index_expr):
                return True

    return False


# Reduction types that produce an index or are multi-output/Welford. They have
# never been validated on simt_template and miscompute there (e.g. wrong argmax
# index for a dynamic-length reduction axis), so they must fall back to the
# community SIMT_ONLY path (same as static SIMD and the community dynamic
# fallback). reduction_type is recorded as a bare string arg on the reduction
# node, so match by value rather than a fragile positional index.
_SIMT_TEMPLATE_UNSAFE_REDUCTION_TYPES = {
    "argmax",
    "argmin",
    "welford_reduce",
    "welford_combine",
}


def _loop_body_has_unsafe_reduction(loop_body):
    graphs = [loop_body.root_block.graph]
    graphs.extend(sub.graph for sub in getattr(loop_body, "subblocks", {}).values())
    for graph in graphs:
        for node in graph.nodes:
            if "reduction" not in node.name:
                continue
            for arg in node.args:
                if isinstance(arg, str) and arg in _SIMT_TEMPLATE_UNSAFE_REDUCTION_TYPES:
                    return True
    return False


def is_linear_dynamic_reduction(loop_body):
    """Keep a dynamic reduction on simt_template only when it is safe to do so.
    Bail (fall back to community SIMT_ONLY) when an index carries a SYMBOLIC bound
    in ModularIndexing/FloorDiv (breaks linearization), or when the reduction
    produces an index / is Welford (argmax/argmin from max.dim/min.dim, var/std).
    Static-bound modular/floordiv from folding static dims are fine; the step-3
    can_split_all check is the final fallback."""
    kernel = V.kernel
    if kernel is None or not getattr(kernel, "inside_reduction", False):
        return False
    indexing = loop_body.indexing
    if not indexing:
        return False
    for index_expr in indexing.values():
        if check_subexpr_for_dynamic_symbols(index_expr):
            return False
    if _loop_body_has_unsafe_reduction(loop_body):
        return False
    return True


def transform_dims_in_indexing(self, indices):
    # Step 1: Generate basic indexing (always executed)
    if self.indexing is None:
        remove_zero_terms(self.indexing_exprs, self.var_ranges)
        generate_body_indexing(self, indices)

    # Step 3: Perform memory access linearization
    log.debug(
        "[Linear] ori indexing:%s\nV.kernel.range_tree_nodes: %s",
        self.indexing,
        V.kernel.range_tree_nodes,
    )
    dim_symbol_index_map, axioms_index_map, symbol_range_map = build_symbolvar_data(self.indexing)
    V.kernel.dim_symbol_index_map = dim_symbol_index_map
    V.kernel.axioms_index_map = axioms_index_map
    V.kernel.symbol_range_map = symbol_range_map
    for key, index_expr in self.indexing.items():
        self.indexing[key] = simplify_index_max_and_mod(index_expr)
        index_expr = self.indexing[key]
        analyse_res = analyze_expression(index_expr, V.kernel.range_tree_nodes)
        log.debug("[Linear] linear analyse res: %s", analyse_res)

        if not analyse_res["can_split_all"]:
            if is_ascend950:
                log.warning(
                    "Skip memory access linearization due to can not split expression: %s"
                    "\nrange_tree_nodes:%s"
                    "\nanalyse_res:%s",
                    self.indexing,
                    V.kernel.range_tree_nodes,
                    analyse_res,
                )
                # Set SIMT_ONLY compile option for dynamic shapes on A5
                V.kernel.npu_kernel_type = NPUKernelType.SIMT_ONLY
                return
            else:
                raise ValueError(
                    f"Can not split expression:{self.indexing}"
                    f"\nrange_tree_nodes:{V.kernel.range_tree_nodes}"
                    f"\nanalyse_res:{analyse_res}"
                )
        self.indexing[key] = split_expression(index_expr)

    if V.kernel is not None and isinstance(V.kernel, NPUIndexTritonKernel):
        rebuild_flattened_dims(self.indexing)

def simplify_index_max_and_mod(index_expr):
    '''
    解析索引表达式中的Max运算，根据符号变量的上下界值简化Max运算
    '''
    if isinstance(index_expr, sympy.Add):
        new_args = [simplify_index_max_and_mod(arg) for arg in index_expr.args]
        return sympy.Add(*new_args)

    elif isinstance(index_expr, sympy.Mul):
        new_args = [simplify_index_max_and_mod(arg) for arg in index_expr.args]
        return sympy.Mul(*new_args)
    elif isinstance(index_expr, torch.utils._sympy.functions.Max):
        arg_0, arg_1 = index_expr.args
        if isinstance(arg_0, sympy.Symbol) and isinstance(arg_1, sympy.Integer) and str(arg_0) in V.kernel.symbol_range_map.keys():
            lower_value = V.kernel.symbol_range_map.get(str(arg_0)).lower
            if arg_1 >= lower_value:
                return arg_1
            else:
                return arg_0
        elif isinstance(arg_1, sympy.Symbol) and isinstance(arg_0, sympy.Integer) and str(arg_1) in V.kernel.symbol_range_map.keys():
            lower_value = V.kernel.symbol_range_map.get(str(arg_1)).lower
            if arg_0 >= lower_value:
                return arg_0
            else:
                return arg_1
    else:
        return index_expr


def build_symbolvar_data(indexings):
    '''
    构建符号变量(dim和动态shape的符号变量)length、以及符号变量运算(Mul等)恒等式
    '''
    shape_env = V.graph.sizevars.shape_env
    dim_symbol_index_map = {} # 索引表达式中轴的带有符号变量的范围值，例如{'x1':s23*s24}
    axioms_index_map = {} # 符号变量的恒等式，例如{'s21*s24': Eq(s21*s24, s31*s79)}
    symbol_range_map = {} # 符号变量的范围值，例如{'s21': [2, int_oo]}
    for key, index_expr in indexings.items():
        get_subexpr_for_dynamic_symbols(index_expr, V.kernel.range_tree_nodes, dim_symbol_index_map)

    axioms = shape_env.get_axioms()
    for range in axioms:
        if isinstance(range, sympy.core.relational.Equality):
            for _, symbol_value in dim_symbol_index_map.items():
                if str(range.lhs) == str(symbol_value) or str(range.rhs) == str(symbol_value):
                    axioms_index_map[str(symbol_value)] = range
    for _, dim_symbol_value in dim_symbol_index_map.items():
        if hasattr(dim_symbol_value, "args") and len(dim_symbol_value.args) > 0:
            for arg in dim_symbol_value.args:
                if isinstance(arg, sympy.Symbol):
                    value_range = shape_env.var_to_range[arg]
                    symbol_range_map[str(arg)] = value_range
        elif isinstance(dim_symbol_value, sympy.Symbol):
            value_range = shape_env.var_to_range[dim_symbol_value]
            symbol_range_map[str(dim_symbol_value)] = value_range
    return dim_symbol_index_map, axioms_index_map, symbol_range_map

# subsititude indirct var with real axis var
def substitube_indirect_index(self, index):
    indirect_var = None

    for symbol in index.free_symbols:
        indirect_var = get_indirect_var(str(symbol))
        if indirect_var:
            break

    if indirect_var:
        indirect_symbol = sympy_index_symbol(indirect_var)
        if not self.indirect_replacements.get(indirect_symbol, None):
            return None
        tmp_index = sympy_subs(index, self.indirect_replacements)
        return self.substitube_indirect_index(tmp_index)
    return index


def get_load_index_from_subblock(loop_body, subblock):
    node_map = {}
    for node in subblock.graph.nodes:
        node_map[node.name] = node
        load_index = get_indirect_index(loop_body, node, node_map)
        if load_index:
            return load_index

    return None


def analyze_all_index(all_indexs):
    if not all_indexs:
        return None

    if not all(all_indexs[0] == index for index in all_indexs):
        return None
    return all_indexs[0]


def get_indirect_index(loop_body, find_node, node_map):
    all_indexs = []
    for node in find_node.args:
        if not isinstance(node, torch.fx.node.Node):
            continue
        node = node_map[node.name]
        if "get_index" in node.name:
            return node.args[0]
        if "masked_subblock" in node.name:
            if node.name not in loop_body.subblocks:
                raise RuntimeError(f"can't find {node.name} in loopbody")
            load_index = get_load_index_from_subblock(
                loop_body, loop_body.subblocks[node.name]
            )
        else:
            load_index = get_indirect_index(loop_body, node, node_map)
        if load_index:
            all_indexs.append(load_index)

    return analyze_all_index(all_indexs)


def define_npu_kernel_type(loop_body):
    """
    For indirect load + sum pattern: simt_only is faster
    """
    pointwise_op_list = ["mul", "add"]

    def check_pointwise_op(reduction_index):
        for pointwise_op in pointwise_op_list:
            if pointwise_op in reduction_index:
                return True
        return False

    if inductor_indirect_memory_mode != str(NPUKernelType.SIMD_SIMT_MIX):
        return NPUKernelType(inductor_indirect_memory_mode)

    node_map = {}
    for node in loop_body.root_block.graph.nodes:
        node_map[node.name] = node
        if "reduction" == node.name:
            reduction_type_pos = 3  # 3 is reduction_type_pos
            reduction_index_pos = 4  # 4 is reduction_index_pos
            load_index_pos = 2  # 2 is load index position
            reduction_type = node.args[reduction_type_pos]
            if reduction_type != "sum":
                continue
            reduction_index = str(node.args[reduction_index_pos])
            if "load" in reduction_index:
                if reduction_index not in node_map:
                    continue
                load_node = node_map[reduction_index]
                if load_node.args[load_index_pos].name not in node_map:
                    continue
                get_load_index = node_map[load_node.args[load_index_pos].name]
                load_index = get_load_index.args[0]
                if load_index not in loop_body.indexing:
                    continue
                if "indirect" in str(loop_body.indexing[load_index]):
                    return NPUKernelType.SIMT_ONLY

            elif check_pointwise_op(reduction_index):
                pointwise_node = node_map.get(reduction_index)
                if pointwise_node is None:
                    continue
                pointwise_inputs = pointwise_node.args
                for pointwise_input in pointwise_inputs:
                    if "load" not in pointwise_input.name:
                        continue
                    load_node = node_map.get(pointwise_input.name, None)
                    if load_node is None:
                        continue
                    get_load_index = node_map.get(
                        load_node.args[load_index_pos].name, None
                    )
                    if get_load_index is None:
                        continue
                    load_index = get_load_index.args[0]
                    if load_index not in loop_body.indexing:
                        continue
                    if "indirect" in str(loop_body.indexing[load_index]):
                        return NPUKernelType.SIMT_ONLY

    return NPUKernelType(inductor_indirect_memory_mode)


def get_masked_index(loop_body, find_node, node_map):
    all_load_indexs = set()  # noqa: set_linter
    for node in find_node.args:
        if not isinstance(node, torch.fx.node.Node):
            continue
        if node.name not in node_map:
            continue
        node = node_map[node.name]
        if "get_index" in node.name:
            return {node.args[0]}  # noqa: set_linter
        if "masked_subblock" in node.name:
            continue
        else:
            load_index = get_masked_index(loop_body, node, node_map)
        if load_index:
            all_load_indexs = all_load_indexs.union(load_index)

    return all_load_indexs


def generate_masked_indexing(self):
    masked_index_ids = {}  # noqa: set_linter

    def add_masked_indexing_from_graph(graph):
        node_map = {}  # noqa: set_linter
        for node in graph.nodes:
            node_map[node.name] = node
            if "masked_subblock" in node.name:
                masked_indexs = get_masked_index(self, node.args[0], node_map)
                masked_index_ids[node.name] = masked_indexs

    add_masked_indexing_from_graph(self.root_block.graph)
    for subblock in self.subblocks.values():
        add_masked_indexing_from_graph(subblock.graph)

    for subblock_name in self.subblocks:
        if subblock_name in masked_index_ids:
            # change indexid to real index
            index_vars = set()  # noqa: set_linter
            for index_id in masked_index_ids[subblock_name]:
                coefficients_dict = self.indexing[index_id].as_coefficients_dict()
                for key in coefficients_dict:
                    if not key.free_symbols:
                        continue
                    index_vars = index_vars.union(key.free_symbols)
            self.masked_indexing[subblock_name] = {str(var) for var in index_vars}  # noqa: set_linter


def generate_indirect_replacements(self):
    """
    ir:
        get_index=self.get_index('index0')
        load=ops.load('arg2_1', get_index)
        set_indirect0=ops.set_indirect(load)
    find { indirect0 : index0 }
    """
    node_map = {}
    indirect_node_map = {}
    for node in self.root_block.graph.nodes:
        node_map[node.name] = node
        index_select_var = get_indirect_mem_var(node.name)
        if index_select_var:
            indirect_var = node.args[4]
            if indirect_var in indirect_node_map:
                indirect_node = indirect_node_map[indirect_var]
                indirect_node.meta["indirect_template"] = True
            indirect_var_symbol = sympy_index_symbol(indirect_var)
            origin_index = self.indirect_replacements.get(indirect_var_symbol, "")
            if "indirect" in str(origin_index):
                node.meta["multi_indirect_index"] = True
            continue
        indirect_var = get_indirect_var(node.name)
        if indirect_var is None:
            continue
        indirect_var_symbol = sympy_index_symbol(indirect_var)
        if inductor_indirect_memory_mode:
            V.kernel.npu_kernel_type = define_npu_kernel_type(self)
        indirect_node_map[indirect_var] = node

        load_index = get_indirect_index(self, node, node_map)
        if load_index is None:
            continue

        origin_index = self.indexing[load_index]
        self.indirect_replacements[indirect_var_symbol] = origin_index


def loop_body_block_index_select(
    self,
    name: str,
    index: sympy.Expr,
    indirect_var,
    set_indirect,
    bound,
    index_select_type,
):
    index = self._simplify(index)
    index = self._add_index(index, MemoryUsageType.LOAD, buffer_name=name)
    return self._inner.index_select(
        name, index, indirect_var, str(set_indirect), bound, index_select_type
    )


def simplify_indexing_index_select(
    self,
    name: str,
    index: sympy.Expr,
    indirect_var,
    set_indirect,
    bound,
    index_select_type,
):
    return self._inner.index_select(
        name,
        self._simplify(index),
        indirect_var,
        str(set_indirect),
        bound,
        index_select_type,
    )


def loop_body_block_gather_template(
    self, name: str, index: sympy.Expr, indirect_var, set_indirect, index_boundary
):
    index = self._simplify(index)
    index = self._add_index(index, MemoryUsageType.LOAD, buffer_name=name)
    return self._inner.gather_template(
        name, index, indirect_var, str(set_indirect), index_boundary
    )


def simplify_indexing_gather_template(
    self, name: str, index: sympy.Expr, indirect_var, set_indirect, index_boundary
):
    return self._inner.gather_template(
        name, self._simplify(index), indirect_var, str(set_indirect), index_boundary
    )


def loop_body_block_indexput_template(self, name, index, value, indirect_var, boundary):
    index = self._simplify(index)
    index = self._add_index(index, MemoryUsageType.STORE, buffer_name=name)
    return self._inner.indexput_template(
        name, index, value, str(indirect_var), boundary
    )


def simplify_indexing_indexput_template(
    self, name, index, value, indirect_var, boundary
):
    return self._inner.indexput_template(
        name, self._simplify(index), value, str(indirect_var), boundary
    )


def loop_body_block_scatter_template(self, name, index, value, indirect_var, boundary):
    index = self._simplify(index)
    index = self._add_index(index, MemoryUsageType.STORE, buffer_name=name)
    return self._inner.scatter_template(name, index, value, str(indirect_var), boundary)


def simplify_indexing_scatter_template(
    self, name, index, value, indirect_var, boundary
):
    return self._inner.scatter_template(
        name, self._simplify(index), value, str(indirect_var), boundary
    )


def patch_loop_body():
    # todo: move patch function to loop_body.py
    origin_loopbody_call = LoopBody.__call__

    # select tiling axis, recover missing dimensions,
    def loopbody__call__(self, *indices, allow_same_symbol_in_index=False):
        if V.kernel is not None and not isinstance(V.kernel, NPUIndexTritonKernel):
            return origin_loopbody_call(self, *indices, allow_same_symbol_in_index=allow_same_symbol_in_index)
        if self.indexing is None:
            generate_body_indexing(self, indices)
        result = self.root_block()
        self.indexing = None
        return result

    LoopBody.__call__ = loopbody__call__

    LoopBody.transform_dims_in_indexing = transform_dims_in_indexing
    LoopBody.substituted_dims_in_indexing = substituted_dims_in_indexing
    LoopBody.generate_indirect_replacements = generate_indirect_replacements
    LoopBody.generate_masked_indexing = generate_masked_indexing
    LoopBody.substitube_indirect_index = substitube_indirect_index


def patch_indexing():
    # todo: move patch function to loop_body.py and _sizevars.py
    CaptureIndexing.index_select = loop_body_block_index_select
    sizevars.SimplifyIndexing.index_select = simplify_indexing_index_select
    CaptureIndexing.gather_template = loop_body_block_gather_template
    sizevars.SimplifyIndexing.gather_template = simplify_indexing_gather_template
    CaptureIndexing.indexput_template = loop_body_block_indexput_template
    sizevars.SimplifyIndexing.indexput_template = simplify_indexing_indexput_template
    CaptureIndexing.scatter_template = loop_body_block_scatter_template
    sizevars.SimplifyIndexing.scatter_template = simplify_indexing_scatter_template

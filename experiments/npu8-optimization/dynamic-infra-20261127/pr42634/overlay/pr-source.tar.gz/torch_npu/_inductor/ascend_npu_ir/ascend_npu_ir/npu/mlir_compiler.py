import os
import sys
import functools
from typing import Callable, Dict, Any, List, Tuple, Iterator, Optional
from itertools import count
from pathlib import Path
import importlib
import tempfile
import subprocess
import shutil

import torch
import torch_npu
from torch_npu._C.mlir import load_kernel_binary
from torch._inductor.compile_fx import clone_preserve_strides
from torch._inductor.runtime.cache_dir_utils import triton_cache_dir


from .utils import (
    MLIRProcessor,
    _build_npu_ext,
    replace_placeholders,
    do_bench,
    logger,
)
from .. import config as anir_config
from ..cache import get_cache_manager
from .codegen.cpp_wrapper import cpp_launcher
from .meta_compiler import MetaCompiler

akg_spec = importlib.util.find_spec("akg")
if akg_spec is not None:
    from akg.kernel import Kernel as MlirKernel


reinterpret_tensor = torch.ops.inductor._reinterpret_tensor
global_cache = set()

class NpuMlirCompiler(MetaCompiler):
    def __init__(self,
            kernel_name: str = '',
            multiprocess_compile=False,
            no_more_compile=False,
            kernel_meta=None,
            autotune=True):
        super().__init__(
            kernel_name=kernel_name,
            multiprocess_compile=multiprocess_compile,
            no_more_compile=no_more_compile,
            kernel_meta=kernel_meta,
            autotune=autotune,
        )
        self.function = None
        self.mode = None
        self.launch = None
        if self.dynamic:
            self.get_host_func_and_tiling_size = None
        self.mlir_processed = False
        self.fx_graph_launcher = None
        self.mlir_text = None
        self.autotuned = False

    def init(self, module, extra_env):
        os.environ.update(extra_env)
        self.mlir_text = module
        if os.getenv("TRITON_CACHE_DIR") is None:
            os.environ["TRITON_CACHE_DIR"] = triton_cache_dir(
                self.kernel_meta.get("device_index", 0)
            )
        self.cache = get_cache_manager(self.kernel_hash or self.traced_graph_hash)
        self.mlir_text, self.kernel_info = self._to_named_op_mlir(module)
        self.prepare_launch(need_pickle=self.multiprocess_compile)
        self.get_named_op_path()

    def _to_named_op_mlir(self, module):
        mlir_processor = MLIRProcessor()
        return mlir_processor.get_named_op_str(
            module, self.kernel_name, dynamic=self.dynamic
        )

    def bisheng_compile(self,
                        input_path: str,
                        output_path: str,
                        auto_db=True,
                        ops_reorder=False,
                        tiling_size=None,
                        extra_command=None):
        bisheng_install_path = os.getenv('BISHENG_INSTALL_PATH', '')
        bisheng_ir_compile_path = os.path.join(bisheng_install_path, "bishengir-compile")
        command = [
            bisheng_ir_compile_path,
            "-enable-hfusion-compile=true",
            "--enable-bin-relocation=0",
            f"-block-dim={anir_config.block_dim}",
        ]
        if auto_db:
            command.append("--enable-auto-multi-buffer=true")
        else:
            command.append("--enable-auto-multi-buffer=false")

        if ops_reorder:
            command.append("--enable-ops-reorder=true")
        else:
            command.append("--enable-ops-reorder=false")

        if tiling_size is not None:
            command.append(f"--hfusion-max-buffer-count-tuning={tiling_size}")

        if anir_config.autotune:
            command.append("-enable-tuning-mode=true")

        if self.dynamic:
            command.append("--enable-static-bare-ptr=false")
            command.append("--enable-symbol-analysis=true")

        if isinstance(extra_command, list) and extra_command:
            command += extra_command
        command += [
            input_path,
            "-o", output_path
        ]
        logger.info(f"Start to compile, command is: [{' '.join(command)}]")
        try:
            subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=30)
            logger.info(f"[bisheng-compile success]")
        except subprocess.CalledProcessError as e:
            logger.info(f"[bisheng-compile failed]")
            logger.warning(f"Compile error msg: {e.stderr.decode('utf-8')}")
            raise e

    def prepare_launch(self, need_pickle=False):
        def get_launch_mod(so_path):
            spec = importlib.util.spec_from_file_location("__launcher", so_path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod

        so_name = f"{self.kernel_name}.so"
        cache_so_path = self.cache.get_file(so_name)
        if cache_so_path is None or (anir_config.always_compile and cache_so_path not in global_cache):
            with tempfile.TemporaryDirectory() as tmpdir:
                c_wrapper_path = os.path.join(tmpdir, f"{self.kernel_name}_launch.cpp")
                cache_mlir_path = self.cache.put(cpp_launcher(self.signature, self.kernel_name, self.ranks, dynamic=self.dynamic), f"{self.kernel_name}_launch.cpp")
                global_cache.add(cache_mlir_path)
                with open(c_wrapper_path, 'w') as c_wrapper_file:
                    c_wrapper_file.write(cpp_launcher(self.signature, self.kernel_name, self.ranks, dynamic=self.dynamic))
                if self.dynamic:
                    with open(c_wrapper_path, "rb") as f:
                        cache_c_wrapper_path = self.cache.put(f.read(), f"{self.kernel_name}_launch.cpp", binary=True)
                    global_cache.add(cache_c_wrapper_path)
                so_path = _build_npu_ext(self.kernel_name, c_wrapper_path, tmpdir)
                with open(so_path, "rb") as f:
                    cache_so_path = self.cache.put(f.read(), so_name, binary=True)
                global_cache.add(cache_so_path)
        if not need_pickle:
            mod = get_launch_mod(cache_so_path)
            self.launch = getattr(mod, "launch")
            if self.dynamic:
                self.get_host_func_and_tiling_size = getattr(mod, "get_host_func_and_tiling_size")

    def get_named_op_path(self):
        named_op_name = f"{self.kernel_name}_named_op.mlir"
        cache_mlir_path = self.cache.get_file(named_op_name)
        if cache_mlir_path is None or (anir_config.always_compile and cache_mlir_path not in global_cache):
            #if anir_config.cache_named_op:
            cache_mlir_path = self.cache.put(self.mlir_text, named_op_name)
            global_cache.add(cache_mlir_path)
        if anir_config.fx_subgraph_dump_path:
            shutil.copy(cache_mlir_path, os.path.join(anir_config.fx_subgraph_dump_path, \
                                                      str(self.device_index), self.kernel_name))
        return cache_mlir_path

    def get_launch_dynamic(self, function, tiling_func, tiling_size):
        block_dim = anir_config.block_dim
        arg_tiling_device = torch.empty((tiling_size // 8), device='npu', dtype=torch.int64)
        arg_tiling_host = torch.empty((tiling_size // 8), dtype=torch.int64)
        def kernel_call(*args, stream=None):
            self.launch(block_dim, stream, function, tiling_func, tiling_size, arg_tiling_host, arg_tiling_device, None, None, None, *args)
        return kernel_call

    def get_launch(self, function):
        block_dim = anir_config.block_dim
        def kernel_call(*args, function, stream=None):
            self.launch(block_dim, stream, function, None, None, None, *args)

        return functools.partial(kernel_call, function=function)

    def get_launch_func(self, cache_kernel_path):
        if self.dynamic:
            function, tiling_func, tiling_size = self.get_host_func_and_tiling_size(self.kernel_name,
                                                                                    self.kernel_name + '_tiling_function',
                                                                                    self.kernel_name + '_get_tiling_struct_size_function',
                                                                                    cache_kernel_path)
            return self.get_launch_dynamic(function, tiling_func, tiling_size)
        else:
            function = load_kernel_binary(self.kernel_name, cache_kernel_path)
            return self.get_launch(function)

    def register_launcher(self,
                          launcher,
                          kernel_path=None,
                          num_outputs=None,
                          disable_dump=False,
                          auto_fallback=False,
                          is_fallback_kernel=False):
        if num_outputs:
            self.num_outputs = num_outputs
        super().register_launcher(launcher, kernel_path, is_fallback_kernel)
        self.fx_graph_launcher = launcher
        if kernel_path.endswith('_fx_fallback'):
            if auto_fallback:
                if anir_config.fallback_warning:
                    print(f"This kernel {self.kernel_name} has been fallback to the eager fx graph mode, ", \
                    "which will lead to a significant decrease in performance.", flush=True)
                if anir_config.fallback_dump and not disable_dump:
                    self.fx_subgraph_dump('fallback')
        logger.info(f"register launcher {launcher} {kernel_path} success")

    def compile_mlir(self,
                     device_info: Tuple[Any],
                     compile_args: List[Any],
                     logger_level = None) -> Callable[..., None]:
        if logger_level is not None:
            # re-init logger level in subprocess
            logger.setLevel(logger_level)
        named_op_mlir_path = self.get_named_op_path()

        kernel_name = self.kernel_name

        tiling_size, ops_reorder, auto_db = compile_args
        tiling_str = f"_{tiling_size}_{ops_reorder}_{auto_db}"
        tiling_kernel_name = kernel_name + tiling_str
        if self.dynamic:
            cache_kernel_path = self.cache.get_file(f"lib{tiling_kernel_name}.so")
        else:
            cache_kernel_path = self.cache.get_file(f"{tiling_kernel_name}.o")

        logger.info("Start to get cached kernel. Tiling info: " +
                    f"tiling_size {tiling_size} ops_reorder {ops_reorder} auto_db {auto_db}")

        if cache_kernel_path is None and self.no_more_compile:
            raise RuntimeError("Skip compile.")

        if cache_kernel_path is None or (anir_config.always_compile and cache_kernel_path not in global_cache):
            logger.info("No cached kernel. Start to exec compile.")
            with tempfile.TemporaryDirectory() as tmpdir:
                kernel_path = os.path.join(tmpdir, tiling_kernel_name)
                self.bisheng_compile(named_op_mlir_path, kernel_path, tiling_size=tiling_size,
                                    ops_reorder=ops_reorder, auto_db=auto_db,
                                    extra_command=anir_config.extra_command)


                if self.dynamic:
                    kernel_path = os.path.join(tmpdir, f"lib{tiling_kernel_name}.so")
                    with open(kernel_path, "rb") as f:
                        cache_kernel_path =  self.cache.put(f.read(), f"lib{tiling_kernel_name}.so", binary=True)
                    global_cache.add(cache_kernel_path)
                else:
                    kernel_path =  os.path.join(tmpdir, tiling_kernel_name + '.o')
                    with open(kernel_path, "rb") as f:
                        cache_kernel_path =  self.cache.put(f.read(), f"{tiling_kernel_name}.o", binary=True)
                    global_cache.add(cache_kernel_path)

        logger.info("Get kernel success.")
        if not self.multiprocess_compile:
            logger.info(f"Start to register kernel, path '{cache_kernel_path}' func '{self.kernel_name}'")
            launch_func = self.get_launch_func(cache_kernel_path)
            self.register_launcher(launch_func, cache_kernel_path)

        if anir_config.fx_subgraph_dump_path:
            kernel_dump_path = os.path.join(anir_config.fx_subgraph_dump_path, \
                                            str(self.device_index), self.kernel_name, 'kernel_dump')
            os.makedirs(kernel_dump_path, exist_ok=True)
            shutil.copy(cache_kernel_path, kernel_dump_path)

    def replace_kernel_by_path(self, kernel_path: str):
        self.launchers.clear()
        self.kernel_paths.clear()
        self.is_fallback_kernels.clear()
        logger.info(f"Start to replace kernel by specific path, path '{kernel_path}' func '{self.kernel_name}'")
        launch_func = self.get_launch_func(kernel_path)
        self.register_launcher(launch_func, kernel_path)

    def get_best_kernel(self):
        def get_launch_mod(so_path):
            spec = importlib.util.spec_from_file_location("__launcher", so_path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod

        best_kernel = self.cache.get_file('best_kernel')
        if best_kernel is None:
            raise RuntimeError("can not find best kernel")
        with open(best_kernel, 'r') as f:
            kernel_path = self.cache.get_file(f.read())
        if not kernel_path.endswith(('.so', '.o')):
            self.register_fx_fallback(self.kernel_meta)
            return
        so_path = self.cache.get_file(f'{self.kernel_name}.so')
        if kernel_path is None:
            return RuntimeError()
        mod = get_launch_mod(so_path)
        self.launch = getattr(mod, "launch")
        if self.dynamic:
            self.get_host_func_and_tiling_size = getattr(mod, "get_host_func_and_tiling_size")

        launch_func = self.get_launch_func(kernel_path)
        self.register_launcher(launch_func, kernel_path)
        return True

    def get_autotune_config(self):
        def get_tiling_range():
            return [i for i in range(-10, 20, 2)]
        compile_args = []
        for ops_reorder in [True, False]:
            for auto_db in [True, False]:
                for tiling_size in get_tiling_range():
                    compile_args.append((tiling_size, ops_reorder, auto_db))
        return compile_args

    def _should_disable_autotune_for_determinism(self):
        return (
            self.kernel_meta.get('are_deterministic_algorithms_enabled', False)
            and self.kernel_meta.get('is_reduction', False)
        )

    def precompile(self,
                    device_info: Tuple[Any],
                    suppress_error=False,
                    logger_level=None):

        if anir_config.autotune and not self._should_disable_autotune_for_determinism():
            compile_args = self.get_autotune_config()
        else:
            compile_args = [(None, True, True)]
        for cargs in compile_args:
            try:
                self.compile_mlir(device_info, cargs, logger_level=logger_level)
            except Exception as e:
                if suppress_error:
                    logger.warning(f"compile args {cargs} fail, err msg: {e}")
                else:
                    raise e

    def bench(self, idx, launcher, *args, **kwargs):
        if anir_config.runtime_error_dump:
            self.data_dump_fake(*args)
        cloned_args = args
        def kernel_call():
            launcher(*cloned_args, **kwargs)
        try:
            return do_bench(kernel_call, warmup=1, rep=5, fast_flush=True)
        except Exception as e:
            log_dir = os.getenv("TORCHINDUCTOR_CACHE_DIR")
            log_file = os.path.join(log_dir, 'tune_error.log')
            with open(log_file, 'a') as f:
                f.write(f"RUNTIME ERROR: eval kernel fail, kernel path: {self.kernel_paths[idx]}, "
                        f"try to add {self.kernel_paths[idx]} to anir_config.force_fallback_kernel_paths")
                f.write(f"{e}\n\n")
            if anir_config.runtime_error_dump:
                self.fx_subgraph_dump('runtime_error')
            return anir_config.tune_error_time

    def clone_args(self, *args, **kwargs) -> Tuple[List[Any], Dict[str, Any]]:
        # [Note: clone mutated buffers]
        # clone inplace buffers to avoid autotune contaminating them if
        # the kernel does in-place stores. avoid cloning other buffers because
        # it leads to increase memory use
        cloned_args = []
        for i, arg in enumerate(args):
            if i in self.mutated_indices:
                assert isinstance(arg, torch.Tensor)
                cloned_args.append(clone_preserve_strides(arg))
            else:
                cloned_args.append(arg)

        return cloned_args

    def accuracy_pass(self, fx_outputs, *args):
        num_inputs = len(args) - self.num_outputs
        for _, (actual, expected) in enumerate(zip(args[num_inputs:], fx_outputs)):
            if actual.dtype != expected.dtype:
                expected = expected.to(actual.dtype)
            acc_comp_tol = anir_config.acc_comp_tol.get(actual.dtype, anir_config.acc_comp_tol['default'])
            rtol = acc_comp_tol['rtol']
            atol = acc_comp_tol['atol']
            matches = torch.allclose(
                actual, expected, rtol=rtol, atol=atol, equal_nan=True
            )
            if not matches:
                return False

        return True

    def benchmark_all_configs(self, *args, **kwargs):
        timings = []
        args_new = ()
        args = list(args)

        if anir_config.acc_check_during_tune:
            launcher_fx = self.launchers[-1]
            fx_outputs = [clone_preserve_strides(arg).to(torch.float32) if arg.dtype == torch.bfloat16 \
                        else clone_preserve_strides(arg) for arg in args[-self.num_outputs:]]
            fx_inputs = [clone_preserve_strides(arg) if isinstance(arg, torch.Tensor) else arg for arg in args[:-self.num_outputs]]
            fx_inputs = [inp.float() if isinstance(inp, torch.Tensor) and inp.dtype == torch.bfloat16 else inp for inp in fx_inputs]

            fx_args = fx_inputs + fx_outputs
            launcher_fx(*fx_args, **kwargs)

        if self.dynamic:
            for idx, arg in enumerate(args):
                if not torch.is_tensor(arg):
                    args_new = args_new + (arg, )
                    continue
                if idx in self.mutated_indices:
                    cloned_arg = clone_preserve_strides(arg)
                    args[idx] = cloned_arg
                    args_new = args_new + (cloned_arg, cloned_arg, 0) + tuple(arg.size()) + tuple(arg.stride())
                else:
                    args_new = args_new + (arg, arg, 0) + tuple(arg.size()) + tuple(arg.stride())
        else:
            for idx, arg in enumerate(args):
                if torch.is_tensor(arg) and idx in self.mutated_indices:
                    cloned_arg = clone_preserve_strides(arg)
                    args_new = args_new + (cloned_arg, )
                    args[idx] = cloned_arg
                else:
                    args_new = args_new + (arg, )

        for idx, launcher in enumerate(self.launchers):
            if self.dynamic and not self.is_fallback_kernels[idx]:
                transformed_args = args_new
            else:
                transformed_args = args
            if self.kernel_name in anir_config.force_fallback_kernel_names and not self.kernel_paths[idx].endswith('_fx_fallback'):
                continue
            if self.kernel_paths[idx] in anir_config.force_fallback_kernel_paths:
                print(f"Skip kernel: {self.kernel_paths[idx]}", flush=True)
                continue
            if self.is_fallback_kernels[idx] and not anir_config.autotune_fx_fallback:
                continue
            try:
                logger.info(f"start to eval kernel {self.kernel_paths[idx]}")
                times = self.bench(idx, launcher, *transformed_args, **kwargs)
                if anir_config.acc_check_during_tune:
                    if self.accuracy_pass(fx_outputs, *args):
                        timings.append([times, idx])
                else:
                    timings.append([times, idx])
                logger.info(f"eval over")
            except Exception as e:
                print(e)
                continue
        if not timings:
            print(f"{self.kernel_name}: Tuning accuracy failed, no valid kernels found, using fallback")
            timings.append([float(1.0), len(self.launchers) - 1])
        return timings

    def autotune_to_one_config(self, *args, **kwargs):
        if any([isinstance(arg, torch.Tensor) and not arg.is_contiguous() for arg in args]):
            print(f'Non contiguous args exists! Kernel name is {self.kernel_name}')
        timings = self.benchmark_all_configs(*args, **kwargs)
        timings.sort()
        logger.info(f"autotune over, timings: {timings}")
        if timings[0][0] > 99999:
            self.launchers.clear()
            self.is_fallback_kernels.clear()
            self.register_fx_fallback(self.kernel_meta)
            return
        idx = timings[0][1]
        logger.info(f"autotune benchmark over, using kernel {self.kernel_paths[idx]}")
        self.kernel_paths = [self.kernel_paths[idx]]
        self.launchers = [self.launchers[idx]]
        self.is_fallback_kernels = [self.is_fallback_kernels[idx]]
        if self.is_fallback_kernels[0]:
            self.cache.put(self.traced_graph_hash, "best_kernel", binary=False)
        else:
            self.cache.put(self.kernel_paths[0].split('/')[-1], "best_kernel", binary=False)

    def mlir_dump(self, *args, **kwargs):
        self.data_dump(*args)
        launcher_fx = self.launchers[-1]
        fx_output = launcher_fx(*args, **kwargs)
        return fx_output

    def make_inputs_contiguous(self, args):
        args = list(args)
        for idx in self.non_contiguous_indices['inputs']:
            args[idx] = args[idx].contiguous()
        return tuple(args)


class AkgCompiler(MetaCompiler):
    def __init__(
        self,
        kernel_name: str = "",
        multiprocess_compile: bool = False,
        no_more_compile: bool = False,
        kernel_meta: Optional[Dict[str, Any]] = None,
        autotune: bool = True,
    ):
        super().__init__(
            kernel_name=kernel_name,
            multiprocess_compile=multiprocess_compile,
            no_more_compile=no_more_compile,
            kernel_meta=kernel_meta,
            autotune=autotune,
        )
        torch_root_dir = Path(torch_npu.__file__).resolve().parent
        self.kernel = MlirKernel(self.kernel_name, torch_path=str(torch_root_dir), kernel_meta=self.kernel_meta)
        self.cache = get_cache_manager(self.kernel_hash or self.traced_graph_hash)

    def force_fallback(self, kernel_name: str) -> bool:
        k = self.kernel_name
        if not k:
            return False
        return k in anir_config.force_fallback_kernel_names

    def autotune_to_one_config(self, *args, **kwargs):
        if not self.launchers:
            return

        launcher_idx = self.get_primary_launcher_index()
        if self.is_fallback_kernels[launcher_idx]:
            return

        cloned_args = [
            clone_preserve_strides(arg) if isinstance(arg, torch.Tensor) else arg
            for arg in args
        ]
        try:
            _, accuracy_passed = self.acc_compare_and_dump(
                *cloned_args, dump_data=False, **kwargs
            )
            if accuracy_passed:
                return
            reason = "accuracy_failed"
        except Exception as e:
            reason = f"runtime_error: {e}"

        logger.error(
            f"AKG {reason} for {self.kernel_name}, fallback to FX."
        )
        self.launchers.clear()
        self.kernel_paths.clear()
        self.is_fallback_kernels.clear()
        self.register_fx_fallback(self.kernel_meta)

    def compile(self, input_mlir: str):
        if self.force_fallback(self.kernel_name):
            self.register_fx_fallback(self.kernel_meta)
            logger.warning(
                f"AKG compile skipped for {self.kernel_name}, forced fallback to FX."
            )
            return

        try:
            import torch_mlir
            from torch_mlir import ir
            from torch_mlir.compiler_utils import run_pipeline_with_repro_report

            ctx = ir.Context()
            torch_mlir.dialects.torch.register_dialect(ctx)
            mlir_module = ir.Module.parse(input_mlir, context=ctx)
            run_pipeline_with_repro_report(
                mlir_module,
                "builtin.module(torch-backend-to-linalg-on-tensors-backend-pipeline)",
                "Lowering Torch Backend IR -> Linalg-on-Tensors Backend IR",
            )

            kernel_file_name = f"lib{self.kernel_name}.so" if self.dynamic else f"{self.kernel_name}.o"
            kernel_meta_file_name = f"{self.kernel_name}.json"
            kernel_log_file_name = f"{self.kernel_name}.log"
            cache_kernel_path = self.cache.get_file(kernel_file_name)
            cache_kernel_meta_path = self.cache.get_file(kernel_meta_file_name)
            if (cache_kernel_path is None or cache_kernel_meta_path is None) and self.no_more_compile:
                raise RuntimeError("Skip compile.")
            if (
                cache_kernel_path is None
                or cache_kernel_meta_path is None
                or (anir_config.always_compile and cache_kernel_path not in global_cache)
            ):
                with tempfile.TemporaryDirectory() as tmpdir:
                    try:
                        self.kernel.compile(
                            str(mlir_module),
                            work_dir=tmpdir,
                            need_compile=True,
                            debug=anir_config.debug,
                        )
                        binary_output_path = os.path.join(tmpdir, kernel_file_name)
                        meta_output_path = os.path.join(tmpdir, kernel_meta_file_name)
                        with open(binary_output_path, "rb") as f:
                            cache_kernel_path = self.cache.put(f.read(), kernel_file_name, binary=True)
                        with open(meta_output_path, "rb") as f:
                            cache_kernel_meta_path = self.cache.put(f.read(), kernel_meta_file_name, binary=True)
                        global_cache.add(cache_kernel_path)
                    finally:
                        if anir_config.debug:
                            log_output_path = os.path.join(tmpdir, kernel_log_file_name)
                            if os.path.isfile(log_output_path):
                                shutil.copy(log_output_path, os.path.join(anir_config.debug_dir, kernel_log_file_name))
            else:
                self.kernel.compile(
                    str(mlir_module),
                    work_dir=os.path.dirname(cache_kernel_path),
                    need_compile=False,
                )
            self.register_launcher(self.kernel.run, kernel_path=cache_kernel_path)
        except Exception as e:
            self.register_fx_fallback(self.kernel_meta)
            logger.warning(
                f"AKG compile failed for {self.kernel_name}, fallback to FX. reason: {e}"
            )

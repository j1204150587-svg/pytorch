# Copyright (c) 2020 Huawei Technologies Co., Ltd
# Copyright (c) 2019, Facebook CORPORATION.
# All rights reserved.
#
# Licensed under the BSD 3-Clause License  (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# https://opensource.org/licenses/BSD-3-Clause
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
import os
import pathlib
import re
import stat
import textwrap
from collections import Counter, defaultdict, namedtuple
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Optional, List, Set, Union

import torchgen
import torchgen.api.dispatcher as dispatcher
import torchgen.api.native as native
import torchgen.dest as dest
import yaml
from torchgen.api.cpp import JIT_TO_CPP_DEFAULT
from torchgen.code_template import CodeTemplate
from torchgen.model import (
    BackendIndex,
    SchemaKind,
    TensorOptionsArguments,
)
from torchgen.gen import (
    error_check_native_functions,
    FileManager,
    get_grouped_native_functions,
    parse_native_yaml,
    parse_tags_yaml,
)
from torchgen.model import (
    BackendIndex,
    BackendMetadata,
    DispatchKey,
    is_cuda_dispatch_key,
    NativeFunction,
    NativeFunctionsGroup,
    OperatorName,
)
from torchgen.native_function_generation import add_generated_native_functions
from torchgen.selective_build.selector import SelectiveBuilder
from torchgen.utils import concatMap, context, NamespaceHelper, Target
from torchgen.context import native_function_manager
from torchgen.api.translate import translate
from torchgen.api.types import (
    BaseCType,
    ConstRefCType,
    CppSignatureGroup,
    Expr,
    MutRefCType,
    NamedCType,
    NativeSignature,
    tensorT
)
from torchgen.dest.register_dispatch_key import StructuredRegisterDispatchKey
from torchgen.gen_backend_stubs import gen_dispatchkey_nativefunc_headers
import torchgen.api.meta as meta
import torchgen.api.structured as structured

from torchnpugen.custom_functions import (
    gen_custom_functions_dispatch,
    gen_custom_ops_patch,
    gen_custom_trace,
    parse_custom_yaml,
)
from torchnpugen.gen_functionalization_type import (
    gen_functionalization_definition,
    gen_functionalization_registration,
)
from torchnpugen.gen_npu_c_shim import gen_npu_c_shim_files
from torchnpugen.utils import (
    DEVICE_NOCHECK_SET,
    field_tag,
    filt_compositeimplicitautograd_api,
    filt_exposed_api,
    gen_custom_yaml_path,
    gen_device_check,
    gen_npu_record_function_guard,
    gen_unstructured,
    gen_unsafe_tensor_check,
    get_grouped_native_functions_optional_out,
    get_opplugin_wrap_name,
    get_target_functions,
    get_target_native_registration,
    get_torchgen_dir,
    is_opapi,
    merge_custom_yaml,
    NativeFunctionsGroupOptionalOut,
    parse_npu_yaml,
    PathManager,
    rename_privateuse1_dispatch_key,
    update_internal_format_opapi_info,
    update_opapi_info,
    gen_dispatchkey_nativefunc_headers,
)


torchgen.model.dispatch_keys.append(torchgen.model.DispatchKey.AutogradPrivateUse1)

NPU_STRUCTURED_INPLACE_OPS: set[str] = set()
NPU_STRUCTURED_PRECOMPUTED_OPS: set[str] = set()


# Create backend_indices map for func retrieval with the key of each func we supported.
def create_backend_index(
    backend_ops: list[str],
    symint_ops: set[str],
    dispatch_key: DispatchKey,
    native_funcs_map: dict[OperatorName, NativeFunction],
    cpp_namespace: str,
    structured_ops: Optional[set[str]] = None,
) -> BackendIndex:
    metadata: dict[OperatorName, BackendMetadata] = {}
    for op in backend_ops:
        op_name = OperatorName.parse(op)
        if op_name not in native_funcs_map:
            raise KeyError(f"Found an invalid operator name: {op_name}")
        is_structured = structured_ops is not None and op in structured_ops
        if is_structured and not native_funcs_map[op_name].structured:
            raise ValueError(
                f"{op} is marked structured in op_plugin yaml, but the upstream "
                "native function is not a structured out variant."
            )
        # See Note [External Backends Follow Dispatcher API]
        kernel_name = dispatcher.name(native_funcs_map[op_name].func)
        if op in symint_ops and not is_structured:
            kernel_name += "_symint"
        m = BackendMetadata(kernel=kernel_name, structured=is_structured, cpp_namespace=cpp_namespace)
        metadata[op_name] = m
    return BackendIndex(
        dispatch_key=dispatch_key,
        use_out_as_primary=True,
        external=True,
        device_guard=True,
        index=metadata,
    )


# Check whether the function is placed at the wrong place.
def check_grouped_native_functions(
    backend_key: DispatchKey,
    autograd_key: DispatchKey,
    backend_indices: dict[DispatchKey, BackendIndex],
    grouped_native_functions: Sequence[NativeFunction | NativeFunctionsGroup],
):
    for g in grouped_native_functions:
        if isinstance(g, NativeFunction):
            forward_kernels = (
                []
                if backend_key is None
                else [
                    m
                    for m in [backend_indices[backend_key].get_kernel(g)]
                    if m is not None
                ]
            )
            backward_kernels = (
                []
                if autograd_key is None
                else [
                    m
                    for m in [backend_indices[autograd_key].get_kernel(g)]
                    if m is not None
                ]
            )
        else:
            if backend_key is None:
                forward_kernels = []
            else:
                forward_kernels = []
                for f in g.functions():
                    kernel = backend_indices[backend_key].get_kernel(f)
                    if kernel is not None:
                        forward_kernels.append(kernel)
            if autograd_key is None:
                backward_kernels = []
            else:
                backward_kernels = []
                for f in g.functions():
                    kernel = backend_indices[autograd_key].get_kernel(f)
                    if kernel is not None:
                        backward_kernels.append(kernel)

        forward_kernels = [f for f in forward_kernels if f is not None]
        backward_kernels = [f for f in backward_kernels if f is not None]

        if len(forward_kernels) != 0 and len(backward_kernels) != 0:
            raise ValueError(
                f'Currently, all variants of an op must either be registered to a backend key, \
                             or to a backend\'s autograd key. They cannot be mix and matched. If this is \
                             something you need, feel free to create an issue! {forward_kernels[0].kernel} \
                             is listed under "supported", but {backward_kernels[0].kernel} is listed under "autograd".'
            )


_GLOBAL_PARSE_NATIVE_YAML_CACHE = {}

# Parse native_functions.yaml into a sequence of NativeFunctions and Backend Indices.
ParsedYaml = namedtuple("ParsedYaml", ["native_functions", "backend_indices"])


def modify_func_in_native_yaml(func: str) -> str:
    # func_to_modify: {old_value: new_value}
    func_to_modify = {
        "matmul_backward(Tensor grad, Tensor self, Tensor other, bool[2] mask) -> (Tensor, Tensor)": "matmul_backward(Tensor grad_out, Tensor self, Tensor other, bool[2] mask) -> (Tensor, Tensor)"  # noqa: E501, B950
    }
    if func in func_to_modify:
        return func_to_modify[func]
    return func


def parse_native_and_custom_yaml(
    path: str, tag_path: str, custom_path: str
) -> ParsedYaml:
    global _GLOBAL_PARSE_NATIVE_YAML_CACHE
    if path not in _GLOBAL_PARSE_NATIVE_YAML_CACHE:
        valid_tags = parse_tags_yaml(tag_path)
        PathManager.check_directory_path_readable(path)
        with open(path) as f:
            es = yaml.safe_load(f)
        if not isinstance(es, list):
            raise TypeError("es is not list")
        rs: list[NativeFunction] = []
        bs: dict[DispatchKey, dict[OperatorName, BackendMetadata]] = defaultdict(dict)
        for e in es:
            e["func"] = modify_func_in_native_yaml(e["func"])
            func, m = NativeFunction.from_yaml(e, "Location", valid_tags)
            rs.append(func)
            BackendIndex.grow_index(bs, m)

        source_es = parse_npu_yaml(custom_path)
        custom_es = source_es.get("custom", []) + source_es.get("custom_autograd", [])
        supported_es = (
            source_es.get("supported", []) + source_es.get("autograd", []) + custom_es
        )
        for es in supported_es:
            update_opapi_info(es)
            update_internal_format_opapi_info(es)
        custom_es = field_tag(custom_es)
        for e in custom_es:
            func, m = NativeFunction.from_yaml(e, "Location", valid_tags)
            rs.append(func)
            BackendIndex.grow_index(bs, m)

        error_check_native_functions(rs)
        # Default dict is to prevent the codegen from barfing when we have a dispatch key that has no kernels yet.
        indices: dict[DispatchKey, BackendIndex] = defaultdict(
            lambda: BackendIndex(
                dispatch_key=DispatchKey.Undefined,
                use_out_as_primary=True,
                device_guard=True,
                external=False,
                index={},
            )
        )
        add_generated_native_functions(rs, bs)
        for k, v in bs.items():
            # All structured in-tree operators are implemented in terms of their out operator.
            indices[k] = BackendIndex(
                dispatch_key=k,
                use_out_as_primary=True,
                external=False,
                device_guard=is_cuda_dispatch_key(k),
                index=v,
            )
        _GLOBAL_PARSE_NATIVE_YAML_CACHE[path] = ParsedYaml(rs, indices)

    return _GLOBAL_PARSE_NATIVE_YAML_CACHE[path]


# Parses the external backend's yaml, and adds a new BackendIndex for the backend's dispatch key.
# Returns a Tuple of (true_backend, backend_key, autograd_key, cpp_namespace, updated BackendIndex mapping)
ParsedExternalYaml = namedtuple(
    "ParsedExternalYaml",
    ["true_backend", "backend_key", "autograd_key", "cpp_namespace", "backend_indices"],
)


def _get_backend_yaml_op_name(op: object) -> str:
    if isinstance(op, dict):
        func = op.get("func")
        if not isinstance(func, str):
            raise TypeError(f'expected "func" to be a string, but got: {func}')
        return func.split("(", 1)[0].strip()
    if isinstance(op, str):
        return op
    raise TypeError(f"expected an operator name or a dict, but got: {op}")


def _check_structured_delegate(
    op_name: OperatorName,
    op: dict[str, object],
    group: NativeFunctionsGroup,
) -> None:
    expected_delegate = group.out.func.name
    delegate = op.get("structured_delegate")
    if delegate is None:
        raise ValueError(
            f"{op_name} belongs to a structured group whose out variant is "
            f"{expected_delegate}, but it does not specify structured_delegate: "
            f"{expected_delegate}."
        )
    if not isinstance(delegate, str):
        raise TypeError(
            f'expected "structured_delegate" for {op_name} to be a string, '
            f"but got: {delegate}"
        )
    delegate_name = OperatorName.parse(delegate)
    if delegate_name != expected_delegate:
        raise ValueError(
            f"{op_name} specifies structured_delegate: {delegate_name}, "
            f"but its structured out variant is {expected_delegate}."
        )


def check_structured_group_consistency(
    supported_by_name: dict[OperatorName, dict[str, object]],
    structured_groups: dict[OperatorName, NativeFunctionsGroup],
    structured_group_members: dict[OperatorName, NativeFunctionsGroup],
) -> None:
    for out_name, group in sorted(structured_groups.items(), key=lambda item: str(item[0])):
        functional_name = group.functional.func.name
        functional_op = supported_by_name.get(functional_name)
        if functional_op is None:
            raise ValueError(
                f"{out_name} is marked structured in op_plugin yaml, "
                f"but its functional variant {functional_name} is not listed in supported."
            )
        _check_structured_delegate(functional_name, functional_op, group)

        if group.inplace is None:
            continue
        inplace_name = group.inplace.func.name
        inplace_op = supported_by_name.get(inplace_name)
        if inplace_op is None:
            continue
        if bool(inplace_op.get("structured", False)):
            continue
        _check_structured_delegate(inplace_name, inplace_op, group)

    for op_name, group in sorted(structured_group_members.items(), key=lambda item: str(item[0])):
        if group.out.func.name in structured_groups:
            continue
        out_name = group.out.func.name
        out_op = supported_by_name.get(out_name)
        if out_op is None or not bool(out_op.get("structured", False)):
            raise ValueError(
                f"{op_name} is annotated as part of a structured group, "
                f"but its out variant {out_name} is not marked structured in op_plugin yaml."
            )


def parse_backend_yaml(
    native_yaml_path: str,
    backend_yaml_path: str,
    grouped_native_functions: Sequence[NativeFunction | NativeFunctionsGroup],
    backend_indices: dict[DispatchKey, BackendIndex],
) -> ParsedExternalYaml:
    native_functions_map = {}
    native_function_groups = {}
    for f in grouped_native_functions:
        if isinstance(f, NativeFunction):
            native_functions_map[f.func.name] = f
        else:
            for func in f.functions():
                native_functions_map[func.func.name] = func
                native_function_groups[func.func.name] = f

    PathManager.check_directory_path_readable(backend_yaml_path)
    with open(backend_yaml_path) as f:
        yaml_values = yaml.safe_load(f)
    if not isinstance(yaml_values, dict):
        raise TypeError("yaml_values is not dict")

    # NestedTensor is a stub for now. (Not yet implemented.)
    valid_keys = [
        "backend",
        "cpp_namespace",
        "supported",
        "autograd",
        "custom",
        "custom_autograd",
        "symint",
        "quant",
        "nestedtensor",
    ]

    yaml_backend = yaml_values.pop("backend", None)
    true_backend = "PrivateUse1" if yaml_backend == "NPU" else yaml_backend
    if true_backend is None:
        raise ValueError("You must provide a value for 'backend'")
    backend = "NPU"

    cpp_namespace = yaml_values.pop("cpp_namespace", None)
    if cpp_namespace is None:
        raise ValueError("You must provide a value for 'cpp_namespace'")

    supported = yaml_values.pop("supported", [])
    if supported is None:
        supported = []  # Allow an empty list of supported ops
    if not isinstance(supported, list):
        raise TypeError(
            f'expected "supported" to be a list, but got type {type(supported)}'
        )

    symint = yaml_values.pop("symint", [])
    if symint is None:
        symint = []
    if not (isinstance(symint, list)):
        raise RuntimeError(
            f'expected "symint" to be a list, but got: {supported} (of type {type(supported)})'
        )
    symint = [op["func"].split("(")[0] if isinstance(op, dict) else op for op in symint]
    symint_set = set(symint)

    supported_autograd = yaml_values.pop("autograd", [])
    if not isinstance(supported_autograd, list):
        raise TypeError(
            f'expected "autograd" to be a list, but got: {supported_autograd}'
        )

    supported_list = []
    structured_ops: Set[str] = set()
    structured_groups: dict[OperatorName, NativeFunctionsGroup] = {}
    structured_group_members: dict[OperatorName, NativeFunctionsGroup] = {}
    supported_by_name: dict[OperatorName, dict[str, object]] = {}
    for op in supported:
        op_name = _get_backend_yaml_op_name(op)
        op_schema_name = OperatorName.parse(op_name)
        op_info = op if isinstance(op, dict) else {}
        supported_by_name[op_schema_name] = op_info
        if isinstance(op, dict):
            native_func = native_functions_map.get(op_schema_name)
            is_structured = bool(op.get('structured', False)) if op_name != "cat.out" else False
            has_structured_delegate = op.get('structured_delegate') is not None if op_name != "cat" else False
            if is_structured or has_structured_delegate:
                if native_func is None:
                    raise KeyError(f"Found an invalid structured operator name: {op_schema_name}")
                schema_kind = native_func.func.kind()
                group = native_function_groups.get(op_schema_name)
            if is_structured:
                if group is None:
                    raise ValueError(
                        f"{op_name} is marked structured in op_plugin yaml, "
                        "but it is not part of a structured native function group."
                    )
                if native_func.func.kind() == SchemaKind.out:
                    structured_ops.add(op_name)
                    structured_groups[op_schema_name] = group
                    if op.get('precomputed') is not None:
                        NPU_STRUCTURED_PRECOMPUTED_OPS.add(op_name)
                elif native_func.func.kind() == SchemaKind.inplace:
                    structured_group_members[op_schema_name] = group
                    NPU_STRUCTURED_INPLACE_OPS.add(op_name)
                else:
                    raise ValueError(
                        f"{op_name} is marked structured in op_plugin yaml, "
                        "but only out and inplace variants are supported."
                    )
            if has_structured_delegate:
                if schema_kind not in (SchemaKind.functional, SchemaKind.inplace):
                    raise ValueError(
                        f"{op_name} specifies structured_delegate in op_plugin yaml, "
                        "but only functional and inplace variants can delegate to a structured out variant."
                    )
                if group is None:
                    raise ValueError(
                        f"{op_name} specifies structured_delegate in op_plugin yaml, "
                        "but it is not part of a structured native function group."
                    )
                _check_structured_delegate(op_schema_name, op, group)
                structured_group_members[op_schema_name] = group
        if isinstance(op, dict) and op.get('device_check', None) == 'NoCheck':
            DEVICE_NOCHECK_SET.add(op['func'].split("(")[0])
        if isinstance(op, dict) and ({"impl_ns", "op_api", "device_check"} & set(op.keys())):
            supported_list.append(op['func'].split("(")[0])
        elif not isinstance(op, dict):
            supported_list.append(op)
    check_structured_group_consistency(
        supported_by_name,
        structured_groups,
        structured_group_members,
    )
    supported = supported_list

    supported_autograd = [
        op["func"].split("(")[0] if isinstance(op, dict) else op
        for op in supported_autograd
    ]
    supported_autograd += filt_compositeimplicitautograd_api(
        native_yaml_path, supported
    )

    custom = yaml_values.pop("custom", [])
    if not isinstance(custom, list):
        raise TypeError(f'expected "autograd" to be a list, but got: {custom}')

    for item in custom:
        try:
            supported.append(item["func"][: item["func"].index("(")])
        except ValueError as e:
            raise ValueError(f"Wrong format for function: {item['func']}") from e

    custom_autograd = yaml_values.pop("custom_autograd", [])
    if not isinstance(custom_autograd, list):
        raise TypeError(f'expected "autograd" to be a list, but got: {custom_autograd}')
    for item in custom_autograd:
        supported_autograd.append(item["func"][: item["func"].index("(")])

    quant = yaml_values.pop("quant", [])
    if not isinstance(quant, list):
        raise TypeError(f'expected "quant" to be a list, but got: {quant}')
    quant = [op["func"].split("(")[0] if isinstance(op, dict) else op for op in quant]

    nestedtensor = yaml_values.pop("nestedtensor", [])
    if not isinstance(nestedtensor, list):
        raise TypeError(
            f'expected "nestedtensor" to be a list, but got: {nestedtensor}'
        )
    nestedtensor = [
        op["func"].split("(")[0] if isinstance(op, dict) else op for op in nestedtensor
    ]

    # custom_supported is only supported for filt expose api, and is not useful here.
    yaml_values.pop("custom_supported", [])
    if len(yaml_values.keys()) > 0:
        raise KeyError(
            f"{backend_yaml_path} contains unexpected keys: {', '.join(yaml_values.keys())}. \
                       Only the following keys are supported: {', '.join(valid_keys)}"
        )

    backend_key: DispatchKey | None = None
    opapi_key = "OpApi"
    if len(supported) > 0:
        with context(
            lambda: f'The provided value for "backend" must be a valid DispatchKey, but got {backend}.'
        ):
            backend_key = DispatchKey.parse(backend)

        backend_idx = create_backend_index(
            supported, symint_set, backend_key, native_functions_map, cpp_namespace, structured_ops
        )
        opapi_backend_idx = create_backend_index(
            [op for op in supported if is_opapi(op)],
            symint_set, backend_key,
            native_functions_map,
            cpp_namespace,
            structured_ops,
        )
        if backend_key in backend_indices:
            raise KeyError("backend_key should not be in backend_indices.")
        backend_indices[backend_key] = backend_idx
        backend_indices[str(backend_key) + opapi_key] = opapi_backend_idx

    autograd_key: DispatchKey | None = None
    if len(supported_autograd) > 0:
        with context(
            lambda: f'The "autograd" key was specified, which indicates that you would like to override \
the behavior of autograd for some operators on your backend. However "Autograd{backend}" is not a valid DispatchKey.'
        ):
            autograd_key = DispatchKey.parse(f"Autograd{backend}")

        autograd_idx = create_backend_index(
            supported_autograd,
            symint_set,
            autograd_key,
            native_functions_map,
            cpp_namespace,
        )
        opapi_autograd_idx = create_backend_index(
            [op for op in supported_autograd if is_opapi(op)],
            symint_set,
            autograd_key,
            native_functions_map,
            cpp_namespace,
        )

        backend_indices[autograd_key] = autograd_idx
        backend_indices[str(autograd_key) + opapi_key] = opapi_autograd_idx

    quant_key = "Quantize"
    if len(quant) > 0:
        quant_idx = create_backend_index(
            quant, symint_set, backend_key, native_functions_map, cpp_namespace
        )
        if quant_key in backend_indices:
            raise KeyError("quant_key should not be in backend_indices.")
        backend_indices[str(backend_key) + quant_key] = quant_idx

    nestedtensor_key = "Nestedtensor"
    if len(nestedtensor) > 0:
        nestedtensor_idx = create_backend_index(
            nestedtensor, symint_set, backend_key, native_functions_map, cpp_namespace
        )
        if nestedtensor_key in backend_indices:
            raise KeyError("nestedtensor_key should not be in backend_indices.")
        backend_indices[str(backend_key) + nestedtensor_key] = nestedtensor_idx

    # check_grouped_native_functions(backend_key, autograd_key, backend_indices, grouped_native_functions)
    return ParsedExternalYaml(
        true_backend, backend_key, autograd_key, cpp_namespace, backend_indices
    )


def op_plugin_kernel_conut(op_plugin_ops_dir: str):
    actual_backend_kernel_name_counts = Counter()
    file_path = os.path.join(op_plugin_ops_dir, "OpInterface.h")
    PathManager.check_directory_path_readable(file_path)
    try:
        with open(file_path) as f:
            backend_defns = f.read()
    except OSError as e:
        raise AssertionError(
            f"Unable to read from the specified impl_path file: {file_path}"
        ) from e

    kernel_defn_regex = r"\w+(?=\()"
    actual_backend_kernel_name_counts += Counter(
        re.findall(kernel_defn_regex, backend_defns)
    )
    return actual_backend_kernel_name_counts


def pta_kernel_conut(class_name: str, pta_op_dir: str):
    actual_backend_kernel_name_counts = Counter()
    for cur_dir, _, filenames in os.walk(pta_op_dir):
        for filename in filenames:
            if not filename.endswith(".cpp"):
                continue
            file_path = os.path.join(cur_dir, filename)
            PathManager.check_directory_path_readable(file_path)
            try:
                with open(file_path) as f:
                    backend_defns = f.read()
            except OSError as err:
                raise AssertionError(
                    f"Unable to read from the specified impl_path file: {file_path}"
                ) from err

            kernel_defn_regex = rf"{class_name}::([\w\d]*)\([^\)]*\)\s*{{"
            actual_backend_kernel_name_counts += Counter(
                re.findall(kernel_defn_regex, backend_defns)
            )
    return actual_backend_kernel_name_counts


def check_op_plugin_kernels(
    native_functions: Sequence[NativeFunction],
    expected_kernel_counts: dict[str, list[NativeFunction]],
    actual_kernel_counts: dict[str, list[NativeFunction]],
):
    for f in native_functions:
        wrap_name = get_opplugin_wrap_name(f)
        expect_op_plugin_kernel_count = len(expected_kernel_counts[wrap_name])
        if expect_op_plugin_kernel_count > actual_kernel_counts[wrap_name]:
            return False
    return True


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate backend stub files")
    parser.add_argument(
        "-s",
        "--source_yaml",
        help="path to source yaml file containing operator external definitions",
    )
    parser.add_argument("-o", "--output_dir", help="output directory")
    parser.add_argument("--dry_run", type=bool, default=False, help="output directory")
    parser.add_argument(
        "--impl_path",
        type=str,
        default=None,
        help="path to the source C++ file containing kernel definitions",
    )
    parser.add_argument(
        "--op_plugin_impl_path",
        type=str,
        default=None,
        help="path to the source C++ file containing kernel definitions in op_plugin",
    )
    parser.add_argument(
        "--op_plugin_yaml_path",
        type=str,
        default=None,
        help="path to the source yaml file containing kernel definitions in op_plugin",
    )
    parser.add_argument(
        "--update_aoti_c_shim",
        action="store_true",
        help="Update AOTInductor C shim after adding an entry to inductor_fallback_ops in torchgen/aoti/fallback_ops.py. "
        "WARNING: Do not use this unless you are sure what you are doing!!!",
    )
    options = parser.parse_args()

    run(
        options.source_yaml,
        options.output_dir,
        options.dry_run,
        options.impl_path,
        options.op_plugin_impl_path,
        options.op_plugin_yaml_path,
        options.update_aoti_c_shim,
    )


def gen_npu_structured_registration_helpers(backend_index: BackendIndex) -> List[str]:
    helpers = dest.gen_registration_helpers(backend_index)
    if backend_index.dispatch_key.name not in ("NPU", "PrivateUse1"):
        return helpers
    if not any(metadata.structured for metadata in backend_index.index.values()):
        return helpers
    if any("create_out(" in helper for helper in helpers):
        return helpers
    return [
        """
Tensor create_out(IntArrayRef sizes, IntArrayRef strides, const TensorOptions &options) {
  if (strides.empty()) {
    return at::empty(sizes, options);
  }
  return at::empty_strided(sizes, strides, options);
}
""",
        *helpers,
        """
std::optional<Tensor> maybe_create_proxy(const Tensor &out, IntArrayRef sizes, IntArrayRef strides, const TensorOptions &options) {
  if (!strides.empty() && out.strides() != strides) {
    return at::empty_strided(sizes, strides, options);
  }
  return std::nullopt;
}
""",
    ]


def gen_dispatcher_registrations(
    fm: FileManager,
    class_name: str,
    backend_indices: dict[DispatchKey, BackendIndex],
    grouped_native_functions: Sequence[NativeFunction | NativeFunctionsGroup],
    backend_dispatch_key: DispatchKey,
    dispatch_key: DispatchKey,
    selector: "SelectiveBuilder",
    dispatch_key_name: str,
    register_dispatch_key_func: Callable,
    native_function_registrations: str = "",
    custom_op_names: set[str] = None,
):
    backend_index = backend_indices[backend_dispatch_key]
    ns_helper = NamespaceHelper(namespace_str="at")

    # 获取环境变量
    env_aclnn_extension_switch = os.getenv("ACLNN_EXTENSION_SWITCH")

    native_func_header = """\
#include "torch_npu/csrc/core/npu/NPURecovery.h"
#include "torch_npu/csrc/core/npu/NPUGuard.h"
#include "torch_npu/csrc/core/npu/NpuVariables.h"
#include "torch_npu/csrc/core/npu/NPUException.h"
#ifndef BUILD_LIBTORCH
#include "torch_npu/csrc/profiler/utils.h"
#endif

#include "torch_npu/csrc/aten/NPUNativeFunctions.h"
#include "torch_npu/csrc/framework/interface/EnvVariables.h"
#include "torch_npu/csrc/aten/NPUOpApiNativeFunctions.h"
#include "torch_npu/csrc/aten/NPUStructuredNativeFunctions.h"
"""

    # 根据环境变量决定是否包含FormatHelper.h
    if env_aclnn_extension_switch:
        native_func_header += ""
    else:
        native_func_header += """#include "torch_npu/csrc/framework/FormatHelper.h"
"""

    native_func_header += """#include "torch_npu/csrc/framework/utils/ForceAclnnList.h"
#include "torch_npu/csrc/framework/OpHook.h"
#include "torch_npu/csrc/aten/mirror/NPUMemoryOverlap.h"
#include "op_plugin/OpInterface.h"
"""
    static_template = CodeTemplate(
        """\
TORCH_LIBRARY_IMPL(aten, $dispatch_key, m) {
$dispatch_registrations_body
};"""
    )
    static_init_dispatch_registrations = static_template.substitute(
        dispatch_key=dispatch_key_name,
        dispatch_registrations_body=list(
            concatMap(
                register_dispatch_key_func(
                    backend_index,
                    Target.REGISTRATION,
                    selector,
                    rocm=False,
                    symint=True,
                    class_method_name=f"{class_name}",
                    skip_dispatcher_op_registration=False,
                ),
                grouped_native_functions,
            )
        ),
    )
    fm.write_with_template(
        f"Register{dispatch_key}.cpp",
        "RegisterDispatchKey.cpp",
        lambda: {
            "extra_cuda_headers": "",
            "external_backend_headers": native_func_header,
            "namespaced_headers": "",
            "DispatchKey": dispatch_key,
            "dispatch_headers": dest.gen_registration_headers(
                backend_index, per_operator_headers=False, rocm=False
            ),
            "ops_headers": "",
            "dispatch_helpers": gen_npu_structured_registration_helpers(backend_index),
            "dispatch_definitions": fm.substitute_with_template(
                "RegisterDispatchDefinitions.ini",
                lambda: {
                    "ns_prologue": ns_helper.prologue,
                    "ns_epilogue": ns_helper.epilogue,
                    "static_init_dispatch_registrations": static_init_dispatch_registrations,
                    "deferred_dispatch_registrations": "",
                    "dispatch_namespace": dispatch_key.lower(),
                    "dispatch_namespaced_definitions": native_function_registrations
                    if native_function_registrations or dispatch_key.lower() != "npu"
                    else list(
                        concatMap(
                            register_dispatch_key_func(
                                backend_index,
                                Target.NAMESPACED_DEFINITION,
                                selector,
                                rocm=False,
                                symint=True,
                                class_method_name=f'{class_name}',
                                skip_dispatcher_op_registration=False,
                            ),
                            [   g
                                for g in grouped_native_functions
                                if g.root_name not in custom_op_names
                            ]
                            if custom_op_names
                            else grouped_native_functions,
                        )
                    ),
                    "dispatch_anonymous_definitions": list(
                        concatMap(
                            register_dispatch_key_func(
                                backend_index,
                                Target.ANONYMOUS_DEFINITION,
                                selector,
                                rocm=False,
                                symint=True,
                                class_method_name=f"{class_name}",
                                skip_dispatcher_op_registration=False,
                            ),
                            grouped_native_functions,
                        )
                    ),
                },
            ).split("\n"),
        },
    )


def get_supported_structured_groups(
        grouped_native_functions: Sequence[Union[NativeFunction, NativeFunctionsGroup]],
        backend_index: BackendIndex,
) -> List[NativeFunctionsGroup]:
    structured_groups: List[NativeFunctionsGroup] = []
    for funcs in grouped_native_functions:
        if not isinstance(funcs, NativeFunctionsGroup):
            continue
        metadata = backend_index.get_kernel(funcs)
        if metadata is not None and metadata.structured:
            structured_groups.append(funcs)
    return structured_groups


def npu_structured_uses_precompute(g: NativeFunctionsGroup) -> bool:
    return str(g.out.func.name) in NPU_STRUCTURED_PRECOMPUTED_OPS


def npu_structured_impl_arguments(g: NativeFunctionsGroup):
    if npu_structured_uses_precompute(g):
        return structured.impl_arguments(g)
    return [*structured.meta_arguments(g), *structured.out_arguments(g)]


def npu_structured_call_args(g: NativeFunctionsGroup) -> str:
    impl_arg_names = {arg.name for arg in npu_structured_impl_arguments(g)}
    call_args: List[str] = []

    for arg in g.out.func.arguments.non_out:
        if isinstance(arg, TensorOptionsArguments):
            raise RuntimeError(f"{g.out.func.name} has TensorOptions, which structured kernels do not support")
        if hasattr(arg, "argument"):
            arg_name = arg.argument.name
        else:
            arg_name = arg.name
        if arg_name not in impl_arg_names:
            raise RuntimeError(
                f"Cannot call op_plugin::{dispatcher.name(g.out.func)} from structured impl for "
                f"{g.out.func.name}: original argument '{arg_name}' is not available after precompute."
            )
        call_args.append(arg_name)

    for arg in g.out.func.arguments.out:
        call_args.append(f"const_cast<at::Tensor&>({arg.name})")

    return ", ".join(call_args)


def npu_structured_inplace_arguments(f: NativeFunction):
    with native_function_manager(f):
        return dispatcher.arguments(f.func, symint=True)


def npu_structured_inplace_call_args(f: NativeFunction) -> str:
    return ", ".join(arg.name for arg in npu_structured_inplace_arguments(f))


def npu_structured_return_expr(f: NativeFunction, k: SchemaKind) -> str:
    if k is SchemaKind.functional:
        if len(f.func.returns) == 1:
            return "std::move(op.outputs_[0])"
        moved = ", ".join(f"std::move(op.outputs_[{i}])" for i in range(len(f.func.returns)))
        return f"std::make_tuple({moved})"
    if k is SchemaKind.inplace:
        return "self"
    if k is SchemaKind.out:
        if len(f.func.returns) == 1:
            return f.func.arguments.out[0].name
        refs = ", ".join(a.name for a in f.func.arguments.out)
        return f"std::forward_as_tuple({refs})"
    raise AssertionError(f"{k} structured operators are currently not supported")


def gen_npu_structured_return_with_op_hook(f: NativeFunction, sig: NativeSignature, ret_expr: str) -> str:
    returns_type = sig.returns_type()
    if isinstance(returns_type, MutRefCType):
        return f"""\
auto& op_hook_result = {ret_expr};
if (op_hook_enabled) {{
  at_npu::native::OpHook::GetInstance().PostHook(op_hook_result);
}}
return op_hook_result;"""
    return f"""\
auto op_hook_result = {ret_expr};
if (op_hook_enabled) {{
  at_npu::native::OpHook::GetInstance().PostHook(op_hook_result);
}}
return op_hook_result;"""


def gen_npu_structured_one(self, f: NativeFunction) -> Optional[str]:
    if f.manual_kernel_registration:
        raise AssertionError(f"Function {f.func.name} has manual_kernel_registration=True")

    if self.target is Target.REGISTRATION and not self.selector.is_native_function_selected(f):
        return None

    if not self.backend_index.has_kernel(f):
        return None

    metadata = self.backend_index.get_kernel(self.g)
    if metadata is None:
        raise AssertionError(f"No kernel metadata found for {self.g.functional.func.name}")

    kern = self.backend_index.get_kernel(f)
    sig = NativeSignature(
        f.func,
        prefix=f"wrapper_{self.backend_index.dispatch_key}_",
        symint=kern is not None and kern.supports_symint(),
    )

    cpp_sig_group = CppSignatureGroup.from_native_function(
        f, method=False, fallback_binding=False
    )

    if self.target is Target.NAMESPACED_DECLARATION:
        result = ""
        for cpp_sig in cpp_sig_group.signatures(symint=self.symint):
            result += f"TORCH_API {cpp_sig.decl()};\n"
        return result

    if self.target is Target.NAMESPACED_DEFINITION:
        def generate_defn(cpp_sig) -> str:
            return f"""
{cpp_sig.defn()} {{
return {sig.name()}({", ".join(e.expr for e in translate(cpp_sig.arguments(), sig.arguments()))});
}}
"""

        result = ""
        for cpp_sig in cpp_sig_group.signatures(symint=self.symint):
            result += generate_defn(cpp_sig)
        return result

    if self.target is Target.REGISTRATION:
        return f'm.impl("{f.func.name}", TORCH_FN({sig.name()}));'
    if self.target is not Target.ANONYMOUS_DEFINITION:
        return None

    k = f.func.kind()
    class_name = f"structured_{metadata.kernel}_{k.name}"
    parent_kernel = metadata.kernel
    if k is SchemaKind.inplace and str(f.func.name) in NPU_STRUCTURED_INPLACE_OPS:
        parent_kernel = dispatcher.name(f.func)
    parent_class = f"{metadata.cpp_namespace}::structured_{parent_kernel}"

    sig_body: List[str] = []
    context_args = list(sig.arguments())
    context_exprs = list(context_args)

    if self.backend_index.device_guard:
        device_check_args = [*f.func.arguments.out, *f.func.arguments.flat_positional]
        sig_body.append(
            dest.RegisterDispatchKey.gen_device_check(
                f.device_check, list(device_check_args), sig.name()
            )
        )
        sig_body.append(gen_unsafe_tensor_check(f, sig.name()))

    sig_body.append(gen_npu_record_function_guard())

    pre_hook_args = ", ".join(arg.name for arg in context_args)
    pre_hook_args = f", {pre_hook_args}" if pre_hook_args else ""
    sig_body.append("const bool op_hook_enabled = C10_UNLIKELY(at_npu::native::env::CheckOpHookEnable());")
    sig_body.append("if (op_hook_enabled) {")
    sig_body.append(f'  at_npu::native::OpHook::GetInstance().PreHook("{f.func.name}"{pre_hook_args});')
    sig_body.append("}")

    if k is SchemaKind.functional:
        sig_body.append(f"{class_name} op;")
    elif k is SchemaKind.inplace:
        sig_body.append(f"{class_name} op(self);")
    elif k is SchemaKind.out:
        out_args_str = ", ".join(a.name for a in f.func.arguments.out)
        sig_body.append(f"{class_name} op({out_args_str});")
    else:
        raise AssertionError(f"{k} structured operators are currently not supported")

    meta_exprs = ", ".join(
        e.expr for e in translate(context_exprs, structured.meta_arguments(self.g), method=False)
    )
    if npu_structured_uses_precompute(self.g) and self.g.out.precomputed:
        sig_body.append(f"auto precompute = op.meta({meta_exprs});")
        precomputed_values = [
            *self.g.out.precomputed.replace.values(),
            self.g.out.precomputed.add,
        ]
        for precomputed_elems in precomputed_values:
            context_exprs.extend(
                Expr(
                    expr=f"precompute.{arg.name}",
                    type=structured.argument_type(arg, binds=arg.name),
                )
                for arg in precomputed_elems
            )
        sig_body.append("(void)precompute;")
    else:
        sig_body.append(f"op.meta({meta_exprs});")

    out_args = structured.out_arguments(self.g)
    for i, out_arg in enumerate(out_args):
        if ConstRefCType(BaseCType(tensorT)) != out_arg.nctype.type:
            raise AssertionError(
                f"Expected out_arg type to be ConstRefCType(BaseCType(tensorT)), got {out_arg.nctype.type}"
            )
        expr = f"op.maybe_get_output({i})" if k is SchemaKind.out else f"op.outputs_[{i}]"
        context_exprs.append(
            Expr(
                expr=expr,
                type=NamedCType(out_arg.nctype.name, MutRefCType(BaseCType(tensorT))),
            )
        )

    if k is SchemaKind.inplace and str(f.func.name) in NPU_STRUCTURED_INPLACE_OPS:
        impl_exprs = npu_structured_inplace_call_args(f)
    else:
        impl_exprs = ", ".join(
            e.expr for e in translate(context_exprs, npu_structured_impl_arguments(self.g), method=False)
        )
    sig_body.append(f"op.impl({impl_exprs});")

    if k is SchemaKind.out or k is SchemaKind.inplace:
        for i in range(len(f.func.returns)):
            sig_body.append(
                f"if (op.proxy_outputs_[{i}].has_value()) op.outputs_[{i}].get().copy_(*op.proxy_outputs_[{i}]);"
            )

    sig_body.append(gen_npu_structured_return_with_op_hook(f, sig, npu_structured_return_expr(f, k)))
    sig_body_str = "\n".join(sig_body)

    return f"""\
{self.gen_class(
    f,
    k,
    class_name=class_name,
    parent_class=parent_class,
    generate_super=self.g.out.structured_inherits is not None,
)}

{sig.defn()} {{
{sig_body_str}
}}
"""


def gen_npu_structured_native_functions(
    fm: FileManager,
    grouped_native_functions: Sequence[Union[NativeFunction, NativeFunctionsGroup]],
    backend_index: BackendIndex,
) -> None:
    structured_groups = get_supported_structured_groups(grouped_native_functions, backend_index)
    includes = sorted({
        f"#include <ATen/ops/{meta.name(g)}_meta.h>"
        for g in structured_groups
    })

    declarations: List[str] = []
    definitions: List[str] = []
    for g in structured_groups:
        metadata = backend_index.get_kernel(g)
        if metadata is None:
            continue
        impl_args = ", ".join(arg.decl() for arg in npu_structured_impl_arguments(g))
        meta_name = meta.name(g)
        declarations.append(f"""\
struct structured_{metadata.kernel} : public at::meta::structured_{meta_name} {{
  void impl({impl_args});
}};
""")
        definitions.append(f"""\
void structured_{metadata.kernel}::impl({impl_args})
{{
  op_plugin::{metadata.kernel}({npu_structured_call_args(g)});
}}
""")
        for f in g.functions():
            if f.func.kind() != SchemaKind.inplace or str(f.func.name) not in NPU_STRUCTURED_INPLACE_OPS:
                continue
            inplace_kernel = dispatcher.name(f.func)
            inplace_impl_args = ", ".join(arg.decl() for arg in npu_structured_inplace_arguments(f))
            declarations.append(f"""\
struct structured_{inplace_kernel} : public at::meta::structured_{meta_name} {{
  void impl({inplace_impl_args});
}};
""")
            definitions.append(f"""\
void structured_{inplace_kernel}::impl({inplace_impl_args})
{{
  op_plugin::{inplace_kernel}({npu_structured_inplace_call_args(f)});
}}
""")

    generated_comment = "Autogenerated file by gen_backend_stubs.py. Do not edit directly!"
    template_dir = os.path.join(pathlib.Path(__file__).parent.absolute(), "templates")
    structured_fm = FileManager(install_dir=fm.install_dir, template_dir=template_dir, dry_run=fm.dry_run)
    structured_fm.write_with_template("NPUStructuredNativeFunctions.h", "NPUStructuredNativeFunctions.h", lambda: {
        "generated_comment": generated_comment,
        "meta_includes": includes,
        "structured_declarations": declarations,
    })
    structured_fm.write_with_template("NPUStructuredNativeFunctions.cpp", "NPUStructuredNativeFunctions.cpp", lambda: {
        "generated_comment": generated_comment,
        "structured_definitions": definitions,
    })


def get_supported_grouped_native_functions(
    grouped_native_functions: Sequence[NativeFunction | NativeFunctionsGroup],
    backend_index: BackendIndex,
) -> Sequence[NativeFunction | NativeFunctionsGroup]:
    supported_grouped_native_functions: Sequence[
        NativeFunction | NativeFunctionsGroup
    ] = []
    for funcs in grouped_native_functions:
        if isinstance(funcs, NativeFunctionsGroup) and not backend_index.has_kernel(
            funcs.out
        ):
            for f in funcs.functions():
                if backend_index.has_kernel(f):
                    supported_grouped_native_functions.append(f)
            continue
        supported_grouped_native_functions.append(funcs)
    return supported_grouped_native_functions


def gen_foreach_register(
    fm: FileManager,
    tags_yaml_path: str,
    native_yaml_path: str,
    grouped_native_functions: Sequence[NativeFunction | NativeFunctionsGroup],
    backend_indices: BackendIndex,
):
    cpu_backend_indices = parse_native_yaml(
        native_yaml_path, tags_yaml_path
    ).backend_indices[DispatchKey.CPU]
    foreach_dict: dict[str, str] = {}
    header_set = set()

    def get_foreach_kernel(func: NativeFunction):
        schema = func.func.name
        if not str(schema).startswith("_foreach"):
            return
        if schema in cpu_backend_indices.index and schema not in backend_indices.index:
            foreach_dict[str(schema)] = cpu_backend_indices.index[schema].kernel

    for f in grouped_native_functions:
        if isinstance(f, NativeFunctionsGroup):
            header_set.add(str(f.signature().name.name.base))
            for func in f.functions():
                get_foreach_kernel(func)
        else:
            header_set.add(str(f.func.name.name.base))
            get_foreach_kernel(f)

    kernel_template = CodeTemplate(
        """\
m.impl("${schema}", TORCH_FN(at::native::${kernel}));"""
    )
    header_template = CodeTemplate(
        """\
#include <ATen/ops/${function}_native.h>"""
    )
    # Sort for deterministic output
    fm.write_with_template(
        "ForeachRegister.cpp",
        "ForeachRegister.cpp",
        lambda: {
            "include_headers": [
                header_template.substitute(function=h)
                for h in sorted(header_set)
                if h.startswith("_foreach")
            ],
            "foreach_kernel": [
                kernel_template.substitute(schema=kv[0], kernel=kv[1])
                for kv in sorted(foreach_dict.items())
            ],
        },
    )


# 定义配置数据类
@dataclass
class SpecialRegisterConfig:
    dispatch_key: str
    filename: str
    header: str
    extra_impls: list[str]


KERNEL_TEMPLATE = CodeTemplate("""\
m.impl("${schema}", TORCH_FN(op_plugin::${kernel}));""")


def _is_aclnn_extension_codegen() -> bool:
    return bool(os.getenv("ACLNN_EXTENSION_SWITCH"))


def _quantized_register_header() -> str:
    headers = [
        "#include <ATen/ops/quantize_per_tensor.h>",
    ]
    if not _is_aclnn_extension_codegen():
        headers.append('#include "torch_npu/csrc/aten/ops/QuantizedFlipKernelNpu.h"')
    headers.append('#include "op_plugin/OpInterface.h"')
    return "\n".join(headers) + "\n"


def _quantized_extra_impls() -> list[str]:
    extra_impls = []
    if not _is_aclnn_extension_codegen():
        extra_impls.append('m.impl("flip", TORCH_FN(at_npu::native::quantized_flip));')
    extra_impls.extend([
        'm.impl("q_scale", TORCH_FN(at::native::q_scale_quant));',
        'm.impl("q_per_channel_scales", TORCH_FN(at::native::q_per_channel_scales));',
        'm.impl("q_zero_point", TORCH_FN(at::native::q_zero_point_quant));',
        'm.impl("q_per_channel_zero_points", TORCH_FN(at::native::q_per_channel_zero_points));',
        'm.impl("q_per_channel_axis", TORCH_FN(at::native::q_per_channel_axis));',
        'm.impl("qscheme", TORCH_FN(at::native::qscheme_quant));',
    ])
    return extra_impls


def _gen_special_registration_body(
    backend_indices: BackendIndex,
    config: SpecialRegisterConfig,
) -> str:
    """生成特殊注册的主体内容,生成内容需保证确定性"""
    kernel_regs = [
        KERNEL_TEMPLATE.substitute(schema=op_name, kernel=metadata.kernel)
        for op_name, metadata in sorted(
            backend_indices.index.items(), key=lambda x: str(x[0])
        )
    ]

    template = CodeTemplate("""\
TORCH_LIBRARY_IMPL(aten, $dispatch_key, m) {
$kernel_registrations
$extra_impls
};""")

    return template.substitute(
        dispatch_key=config.dispatch_key,
        kernel_registrations=kernel_regs,
        extra_impls="\n".join(config.extra_impls),
    )


def _write_special_register(
    fm: FileManager,
    config: SpecialRegisterConfig,
    static_init_dispatch_registrations: str,
) -> None:
    """写入特殊注册文件"""
    ns_helper = NamespaceHelper(namespace_str="at")

    dispatch_definitions = fm.substitute_with_template(
        "RegisterDispatchDefinitions.ini",
        lambda: {
            "ns_prologue": ns_helper.prologue,
            "ns_epilogue": ns_helper.epilogue,
            "static_init_dispatch_registrations": static_init_dispatch_registrations,
            "deferred_dispatch_registrations": "",
            "dispatch_namespace": "",
            "dispatch_namespaced_definitions": "",
            "dispatch_anonymous_definitions": "",
        },
    ).split("\n")

    fm.write_with_template(
        f"{config.filename}.cpp",
        "RegisterDispatchKey.cpp",
        lambda: {
            "extra_cuda_headers": "",
            "external_backend_headers": config.header,
            "namespaced_headers": "",
            "DispatchKey": "NPU",
            "dispatch_headers": "",
            "ops_headers": "",
            "dispatch_helpers": "",
            "dispatch_definitions": dispatch_definitions,
        },
    )


SPECIAL_REGISTERS = {
    "quantize": SpecialRegisterConfig(
        dispatch_key="QuantizedPrivateUse1",
        filename="QuantizedRegister",
        header=_quantized_register_header(),
        extra_impls=_quantized_extra_impls(),
    ),
    "nestedtensor": SpecialRegisterConfig(
        dispatch_key="NestedTensorPrivateUse1",
        filename="NestedTensorRegister",
        header="",
        extra_impls=[
            'm.impl("unbind.int", TORCH_FN(at::native::NestedTensor_unbind));',
            'm.impl("values", TORCH_FN(at::native::values_nested));',
            'm.impl("_nested_tensor_size", TORCH_FN(at::native::_nested_tensor_size));',
        ],
    ),
}


def gen_quantize_register(
    fm: FileManager,
    backend_indices: BackendIndex,
) -> None:
    """生成量化注册"""
    config = SPECIAL_REGISTERS["quantize"]
    static_init = _gen_special_registration_body(
        backend_indices["NPUQuantize"],
        config,
    )
    _write_special_register(fm, config, static_init)


def gen_nestedtensor_register(
    fm: FileManager,
    backend_indices: BackendIndex,
) -> None:
    """生成嵌套张量注册"""
    config = SPECIAL_REGISTERS["nestedtensor"]
    static_init = _gen_special_registration_body(
        backend_indices["NPUNestedtensor"],
        config,
    )
    _write_special_register(fm, config, static_init)


def gen_functionalization(
    fm: FileManager,
    selector: "SelectiveBuilder",
    grouped_native_functions: Sequence[
        NativeFunction | NativeFunctionsGroupOptionalOut
    ],
):
    def key_func(fn: NativeFunction | NativeFunctionsGroupOptionalOut) -> str:
        return fn.root_name

    def functionalization_env_callable(g):
        definition = gen_functionalization_definition(selector, g)
        register = gen_functionalization_registration(selector, g)
        return {
            "func_definitions": definition,
            "func_registrations": register,
        }

    fm.write_sharded(
        "RegisterFunctionalization.cpp",
        grouped_native_functions,
        key_fn=key_func,
        env_callable=functionalization_env_callable,
        num_shards=2,
        sharded_keys={
            "func_definitions",
            "func_registrations",
        },
    )
    return


def gen_target_registration(
    target_op_type: str,
    dispatch_key: DispatchKey,
    backend_indices: dict[DispatchKey, BackendIndex],
    grouped_native_functions: Sequence[NativeFunction | NativeFunctionsGroup],
    op_plugin_yaml_path: str,
    fm: FileManager,
    selector: "SelectiveBuilder",
    native_functions: list[NativeFunction] | None = None,
):
    target_ops = get_target_functions(
        op_plugin_yaml_path, target_op_type=target_op_type
    )
    target_native_functions = []
    for f in grouped_native_functions:
        if isinstance(f, NativeFunctionsGroup):
            for func in f.functions():
                if func.func in target_ops:
                    target_native_functions.append(func)
        elif f.func in target_ops:
            target_native_functions.append(f)

    metadata: dict[OperatorName, BackendMetadata] = {}
    for op in target_ops:
        kernel_name = dispatcher.name(op)
        metadata[op.name] = BackendMetadata(
            kernel=kernel_name, structured=False, cpp_namespace=target_op_type
        )
    backend_indices[dispatch_key] = BackendIndex(
        dispatch_key=dispatch_key,
        use_out_as_primary=False,
        external=True,
        device_guard=True,
        index=metadata,
    )

    native_registration = get_target_native_registration(
        dispatch_key, backend_indices, metadata, native_functions
    )
    gen_dispatcher_registrations(
        fm,
        backend_indices[dispatch_key].native_function_class_name(),
        backend_indices,
        target_native_functions,
        dispatch_key,
        dispatch_key,
        selector,
        dispatch_key_name=dispatch_key.name,
        register_dispatch_key_func=dest.RegisterDispatchKey,
        native_function_registrations=native_registration,
    )


def gen_per_operator_headers(
    fm: FileManager,
    ops_fm: FileManager,
    native_functions: Sequence[NativeFunction],
    grouped_native_functions: Sequence[NativeFunction | NativeFunctionsGroup],
    backend_indices: dict[DispatchKey, BackendIndex],
    dispatch_keys: Sequence[DispatchKey],
    selector: "SelectiveBuilder",
    custom_op_names: set[str] = None,
):
    """
    Generate per-operator dispatch header files (*_npu_dispatch.h) for NPU.

    This mirrors upstream's gen_per_operator_headers which generates
    *_cuda_dispatch.h and *_cpu_dispatch.h in ATen/ops/.

    Uses dest.RegisterDispatchKey with Target.NAMESPACED_DECLARATION to
    generate TORCH_API function declarations in at::npu namespace,
    exactly matching upstream's dispatch header format.

    Also generates NPUFunctions.h/NPUFunctions_inl.h which includes all per-operator
    dispatch headers, mirroring upstream's CUDAFunctions.h/CUDAFunctions_inl.h.
    """

    functions_by_root_name: dict[str, list[NativeFunction]] = defaultdict(list)
    for fn in native_functions:
        if custom_op_names and fn.root_name in custom_op_names:
            continue
        functions_by_root_name[fn.root_name].append(fn)

    grouped_functions_by_root_name: dict[
        str, list[NativeFunction | NativeFunctionsGroup]
    ] = defaultdict(list)
    for group in grouped_native_functions:
        name = group.root_name
        grouped_functions_by_root_name[name].append(group)

    for dispatch_key in dispatch_keys:
        if dispatch_key not in backend_indices:
            continue

        dispatch_namespace = dispatch_key.lower()
        dispatch_names = []

        for name, functions in functions_by_root_name.items():
            grouped_functions = grouped_functions_by_root_name.get(name, [])
            declarations = list(
                concatMap(
                    dest.RegisterDispatchKey(
                        backend_indices[dispatch_key],
                        Target.NAMESPACED_DECLARATION,
                        selector,
                        rocm=False,
                        symint=True,
                        class_method_name=None,
                        skip_dispatcher_op_registration=False,
                    ),
                    grouped_functions,
                )
            )

            if len(declarations) == 0:
                continue

            dispatch_names.append(name)

            ops_fm.write_with_template(
                f"{name}_{dispatch_namespace}_dispatch.h",
                "DispatchKeyFunction.h",
                lambda: {
                    "dispatch_namespace": dispatch_namespace,
                    "dispatch_namespaced_declarations": declarations,
                },
            )

        inl_headers = f"#include <torch_npu/csrc/aten/{dispatch_key}Functions_inl.h>"

        fm.write_with_template(
            f"{dispatch_key}Functions.h",
            "DispatchKeyFunctions.h",
            lambda: {
                "dispatch_key": str(dispatch_key),
                "inline_headers": inl_headers,
            },
        )
        fm.write_with_template(
            f"{dispatch_key}Functions_inl.h",
            "DispatchKeyFunctions_inl.h",
            lambda: {
                "dispatch_namespace": dispatch_namespace,
                "DispatchKeyFunctions_inl_includes": [
                    f"#include <torch_npu/csrc/aten/ops/{name}_{dispatch_namespace}_dispatch.h>"
                    for name in sorted(dispatch_names)
                ],
                "dispatch_namespaced_declarations": [],
            },
        )


def run(
    source_yaml: str,
    output_dir: str,
    dry_run: bool,
    impl_path: str | None,
    op_plugin_impl_path: str | None,
    op_plugin_yaml_path: str | None,
    update_aoti_c_shim: bool,
) -> None:
    rename_privateuse1_dispatch_key()
    torchgen_path = get_torchgen_dir()

    template_dir = os.path.join(torchgen_path, "packaged/ATen/templates")

    def make_file_manager(install_dir: str) -> FileManager:
        return FileManager(
            install_dir=install_dir, template_dir=template_dir, dry_run=dry_run
        )

    fm = make_file_manager(output_dir)
    ops_output_dir = os.path.join(output_dir, "ops")
    if not os.path.exists(ops_output_dir):
        os.makedirs(ops_output_dir, exist_ok=True)
    ops_fm = make_file_manager(ops_output_dir)
    merge_custom_yaml(source_yaml, op_plugin_yaml_path)
    source_yaml = gen_custom_yaml_path(source_yaml)
    source_es = parse_npu_yaml(source_yaml)
    custom_entries = source_es.get("custom", []) + source_es.get("custom_autograd", [])
    custom_op_names = set()
    for entry in custom_entries:
        if isinstance(entry, dict) and "func" in entry:
            op_name = entry["func"].split("(")[0].strip()
            parsed = OperatorName.parse(op_name)
            custom_op_names.add(parsed.name.base)
    tags_yaml_path = os.path.join(torchgen_path, "packaged/ATen/native/tags.yaml")
    native_yaml_path = os.path.join(
        torchgen_path, "packaged/ATen/native/native_functions.yaml"
    )
    parsed_yaml = parse_native_and_custom_yaml(
        native_yaml_path, tags_yaml_path, source_yaml
    )
    get_target_functions(op_plugin_yaml_path)
    native_functions, backend_indices = (
        parsed_yaml.native_functions,
        parsed_yaml.backend_indices,
    )
    grouped_native_functions = get_grouped_native_functions(native_functions)
    parsed_backend_yaml = parse_backend_yaml(
        native_yaml_path, source_yaml, grouped_native_functions, backend_indices
    )
    true_backend = parsed_backend_yaml.true_backend
    backend_key = parsed_backend_yaml.backend_key
    autograd_key = parsed_backend_yaml.autograd_key
    cpp_namespace = parsed_backend_yaml.cpp_namespace
    backend_indices = parsed_backend_yaml.backend_indices
    selector = SelectiveBuilder.get_nop_selector()
    if backend_key is not None:
        backend_dispatch_key: DispatchKey = backend_key
        autograd_dispatch_key: DispatchKey = autograd_key
        class_name = backend_indices[backend_dispatch_key].native_function_class_name()
        gen_dispatchkey_nativefunc_headers(
            fm,
            class_name,
            cpp_namespace,
            backend_indices,
            grouped_native_functions,
            backend_key,
            None,
        )

        gen_dispatchkey_nativefunc_headers(
            fm,
            "NPUNativeOpApiFunctions",
            cpp_namespace,
            backend_indices,
            grouped_native_functions,
            str(backend_key) + "OpApi",
            None,
        )

        gen_npu_structured_native_functions(
            fm,
            grouped_native_functions,
            backend_indices[backend_dispatch_key],
        )

        gen_per_operator_headers(
            fm,
            ops_fm,
            native_functions,
            grouped_native_functions,
            backend_indices,
            [backend_dispatch_key],
            selector,
            custom_op_names,
        )

        for dispatch_key in [backend_dispatch_key, autograd_dispatch_key]:
            if not dispatch_key:
                continue
            gen_dispatcher_registrations(
                fm,
                class_name,
                backend_indices,
                get_supported_grouped_native_functions(
                    grouped_native_functions, backend_indices[dispatch_key]
                ),
                dispatch_key,
                dispatch_key,
                selector,
                dispatch_key_name=dispatch_key.name.replace("NPU", true_backend),
                register_dispatch_key_func=dest.RegisterDispatchKey,
                custom_op_names=custom_op_names,
            )

        gen_quantize_register(fm, backend_indices)
        gen_nestedtensor_register(fm, backend_indices)

        pta_template_dir = os.path.join(
            pathlib.Path(__file__).parent.absolute(), "templates"
        )
        fm = FileManager(
            install_dir=output_dir, template_dir=pta_template_dir, dry_run=dry_run
        )

        custom_functions, custom_backend_indices = parse_custom_yaml(
            source_yaml, tags_yaml_path
        )
        grouped_custom_functions = get_grouped_native_functions_optional_out(
            custom_functions
        )
        gen_functionalization(fm, selector, grouped_custom_functions)
        gen_custom_trace(fm, custom_functions, custom_backend_indices)
        gen_custom_functions_dispatch(fm, custom_functions)

        gen_foreach_register(
            fm,
            tags_yaml_path,
            native_yaml_path,
            grouped_native_functions,
            backend_indices[backend_dispatch_key],
        )

        custom_ops_patch_dir = os.path.join(output_dir, "../../utils/")
        fm = FileManager(
            install_dir=custom_ops_patch_dir,
            template_dir=pta_template_dir,
            dry_run=dry_run,
        )
        gen_custom_ops_patch(fm, custom_functions)

        filt_exposed_list = filt_exposed_api(source_yaml)

        env_aclnn_extension_switch = os.getenv("ACLNN_EXTENSION_SWITCH")
        env_aclnn_extension_path = os.getenv("ACLNN_EXTENSION_PATH")
        # if apply aclnn extension
        if env_aclnn_extension_switch and os.path.exists(env_aclnn_extension_path):
            exposed_path = pathlib.Path(
                os.path.join(env_aclnn_extension_path, "torch_npu/utils/exposed_api.py")
            )
        # original code logic
        else:
            exposed_path = (
                pathlib.Path(__file__)
                .parents[1]
                .joinpath("torch_npu/utils/exposed_api.py")
            )

        PathManager.remove_path_safety(exposed_path)
        with os.fdopen(
            os.open(exposed_path, os.O_RDWR | os.O_CREAT, stat.S_IWUSR | stat.S_IRUSR),
            "w",
        ) as f:
            f.write(f"public_npu_functions = {filt_exposed_list}")
        os.chmod(
            exposed_path, stat.S_IRUSR | stat.S_IEXEC | stat.S_IRGRP | stat.S_IXGRP
        )
        fm = make_file_manager(output_dir)
        gen_target_registration(
            "sparse",
            DispatchKey.SparsePrivateUse1,
            backend_indices,
            grouped_native_functions,
            op_plugin_yaml_path,
            fm,
            selector,
            native_functions,
        )

        gen_target_registration(
            "sparse_csr",
            DispatchKey.SparseCsrPrivateUse1,
            backend_indices,
            grouped_native_functions,
            op_plugin_yaml_path,
            fm,
            selector,
            native_functions,
        )

        aoti_output_dir = os.path.join(output_dir, "../inductor/aoti_torch/generated")
        if not os.path.exists(aoti_output_dir):
            os.makedirs(aoti_output_dir, exist_ok=True)
        aoti_fm = make_file_manager(aoti_output_dir)
        structured_native_functions = [
            g for g in grouped_native_functions if isinstance(g, NativeFunctionsGroup)
        ]
        gen_npu_c_shim_files(
            aoti_fm,
            native_functions,
            backend_indices,
            [backend_dispatch_key],
            structured_native_functions,
            update_aoti_c_shim,
        )


def apply_torchgen_patch():
    dest.RegisterDispatchKey.gen_unstructured = gen_unstructured
    dest.RegisterDispatchKey.gen_device_check = gen_device_check
    original_compute_native_function_declaration = dest.compute_native_function_declaration
    original_gen_class = StructuredRegisterDispatchKey.gen_class
    original_gen_class_set_output_body = StructuredRegisterDispatchKey.gen_class_set_output_body
    original_gen_one = StructuredRegisterDispatchKey.gen_one

    def compute_native_function_declaration(g, backend_index):
        metadata = backend_index.get_kernel(g)
        if isinstance(g, NativeFunctionsGroup) and metadata is not None and metadata.structured and backend_index.external:
            return []
        return original_compute_native_function_declaration(g, backend_index)

    def gen_class_set_output_body(self, k, maybe_create_proxy):
        if self.backend_index.dispatch_key.name not in ("NPU", "PrivateUse1"):
            return original_gen_class_set_output_body(self, k, maybe_create_proxy)

        maybe_set_guard = """
auto current_device = guard_.current_device();
if (C10_UNLIKELY(current_device.has_value())) {
  TORCH_INTERNAL_ASSERT(*current_device == options.device(),
    "structured kernels don't support multi-device outputs");
} else {
  guard_.reset_device(options.device());
}
"""

        if maybe_create_proxy:
            create_proxy = """
auto maybe_proxy = maybe_create_proxy(out, sizes, strides, options);
if (C10_UNLIKELY(maybe_proxy.has_value())) {
    proxy_outputs_[output_idx] = std::move(maybe_proxy).value();
}
"""
        else:
            create_proxy = ""

        if k is SchemaKind.functional:
            return f"""{maybe_set_guard}
outputs_[output_idx] = create_out(sizes, strides, options);"""
        elif k is SchemaKind.inplace:
            return f"""{maybe_set_guard}
const auto& out = outputs_[output_idx].get();
check_inplace(out, sizes, options);
{create_proxy}"""
        elif k is SchemaKind.out:
            return f"""{maybe_set_guard}
const auto& out = outputs_[output_idx].get();
resize_out(out, sizes, strides, options);
{create_proxy}"""
        else:
            raise AssertionError(f"{k} structured operators are currently not supported")

    def gen_class(self, f, k, *, class_name, parent_class, generate_super):
        if self.backend_index.dispatch_key.name not in ("NPU", "PrivateUse1"):
            return original_gen_class(
                self,
                f,
                k,
                class_name=class_name,
                parent_class=parent_class,
                generate_super=generate_super,
            )

        if k is SchemaKind.functional:
            output_type = "Tensor"
            output_value = "outputs_[output_idx]"
            proxy_field = ""
        elif k is SchemaKind.inplace:
            output_type = "std::reference_wrapper<Tensor>"
            output_value = "proxy_outputs_[output_idx].has_value() ? *proxy_outputs_[output_idx] : outputs_[output_idx].get()"
            proxy_field = f"std::array<::std::optional<Tensor>, {len(f.func.returns)}> proxy_outputs_;"
        elif k is SchemaKind.out:
            output_type = "std::reference_wrapper<Tensor>"
            output_value = "proxy_outputs_[output_idx].has_value() ? *proxy_outputs_[output_idx] : outputs_[output_idx].get()"
            proxy_field = f"std::array<::std::optional<Tensor>, {len(f.func.returns)}> proxy_outputs_;"
        else:
            raise RuntimeError(f"Unsupported SchemaKind {k}")

        indent = " " * 4
        class_ctor_str = self.gen_class_ctor(k, class_name, len(f.func.returns))
        lines = (
            f"struct {class_name} final : public {parent_class} {{",
            f"{textwrap.indent(class_ctor_str, indent)}",
            f"{textwrap.indent(self.gen_class_set_output_functions(k, parent_class, generate_super), indent)}",
            "    const Tensor& maybe_get_output(int64_t output_idx) override {",
            f"      return {output_value};\n",
            "    }",
            f"    std::array<{output_type}, {len(f.func.returns)}> outputs_;",
            f"{textwrap.indent(proxy_field, indent)}",
            "    c10_npu::OptionalNPUGuard guard_;",
            "};",
        )
        return "\n".join(line for line in lines if line)

    def gen_one(self, f):
        if self.backend_index.dispatch_key.name in ("NPU", "PrivateUse1"):
            return gen_npu_structured_one(self, f)
        return original_gen_one(self, f)

    dest.compute_native_function_declaration = compute_native_function_declaration
    StructuredRegisterDispatchKey.gen_class = gen_class
    StructuredRegisterDispatchKey.gen_class_set_output_body = gen_class_set_output_body
    StructuredRegisterDispatchKey.gen_one = gen_one
    # generate default arguments
    JIT_TO_CPP_DEFAULT["contiguous_format"] = "c10::MemoryFormat::Contiguous"
    dispatcher.arguments = native.arguments


if __name__ == "__main__":
    apply_torchgen_patch()
    main()

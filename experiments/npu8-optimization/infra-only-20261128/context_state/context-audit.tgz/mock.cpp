#include <atomic>
#include <cassert>
#include <chrono>
#include <condition_variable>
#include <cstdlib>
#include <cstring>
#include <future>
#include <functional>
#include <iostream>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <unordered_map>

using aclError = int;
using aclrtContext = void*;
constexpr aclError ACL_ERROR_NONE=0;
namespace c10 { using DeviceIndex=int8_t; }
namespace at_npu::native::env {
bool compatible=false;
bool CheckCompatibleImpl() { return compatible; }
}
#define TORCH_CHECK(cond,...) do { if(!(cond)) throw std::runtime_error("framework check"); } while(0)
#define NPU_CHECK_ERROR_WITHOUT_UCE(expr) do { if((expr)!=0) throw std::runtime_error("acl error"); } while(0)
#define ASCEND_LOGI(...) ((void)0)
namespace c10_npu {
thread_local int local_device=-1;
thread_local int targetDeviceIndex=-1;
std::unordered_map<int8_t,aclrtContext> used_devices;
std::recursive_mutex mtx;
bool NeedMainThreadBind(){return false;}
void SetThreadAffinity(int){}
int device_count(){return 4;}
bool primary_active=false, fail_set=false, fail_context=false, null_context=false, fail_reset=false, throw_reset=false;
int primary_calls=0, reset_calls=0;
int aclrtSetDevice(c10::DeviceIndex) {return fail_set?1:0;}
int aclrtGetCurrentContext(aclrtContext* out)
{
    if(fail_context) return 1;
    *out=null_context?nullptr:reinterpret_cast<void*>(uintptr_t{1});
    return 0;
}
namespace acl {
int AclrtGetPrimaryCtxState(c10::DeviceIndex,void*,int32_t* value)
{
    ++primary_calls;
    *value=primary_active;
    return 0;
}
}
std::function<void()> reset_callback;
int aclrtResetDevice(int8_t) {
    ++reset_calls;
    if(reset_callback)reset_callback();
    if(throw_reset)throw std::runtime_error("mock vendor exception");
    return fail_reset?1:0;
}
namespace {
std::atomic<uint64_t> active_context_mask{0};
// Mutated only while holding mtx. A vendor reset may call back on the same thread.
unsigned context_reset_depth = 0;
std::atomic<uint64_t> context_read_counts[4]{};

bool context_flag(const char* name)
{
    const char* value = std::getenv(name);
    return value && std::strcmp(value, "1") == 0;
}

uint64_t context_bit(int32_t device)
{
    static const bool enabled = context_flag("NPU_CONTEXT_POSITIVE_MASK");
    if (!enabled || static_cast<uint32_t>(device) >= 64) {
        return 0;
    }
    return uint64_t{1} << static_cast<unsigned>(device);
}

void count_context_read(unsigned index)
{
    static const bool enabled = context_flag("NPU_DYNAMIC_REBASE_COUNT");
    if (enabled) context_read_counts[index].fetch_add(1, std::memory_order_relaxed);
}

struct ActiveContextReset {
    ActiveContextReset()
    {
        ++context_reset_depth;
        active_context_mask.exchange(0, std::memory_order_acq_rel);
    }
    ~ActiveContextReset() { --context_reset_depth; }
};
} // namespace

extern "C" __attribute__((visibility("default"))) uint64_t npu_active_context_counter(unsigned index)
{
    return index < 4 ? context_read_counts[index].load(std::memory_order_relaxed) : 0;
}

bool hasPrimaryContext(c10::DeviceIndex device_index)
{
    /* This interface is implemented to align with 'c10::cuda::hasPrimaryContext(device_index)' interface,
     * but it has performance overhead due to calling AclrtGetPrimaryCtxState API.
     * For internal usage, it's recommended to use the more performant isDeviceCtxActive
     * function which checks the locally cached device context state.
     */
    TORCH_CHECK(device_index >= 0 && device_index < device_count(),
        "hasPrimaryContext expects a valid device index, but got device_index=", device_index, PTA_ERROR(ErrCode::VALUE));
    int32_t ctx_is_active = 0;
    NPU_CHECK_ERROR_WITHOUT_UCE(acl::AclrtGetPrimaryCtxState(device_index, nullptr, &ctx_is_active));
    return ctx_is_active == 1;
}
aclError SetDevice(c10::DeviceIndex device)
{
    TORCH_CHECK(device >= 0, "device id must be positive!", PTA_ERROR(ErrCode::VALUE));
    targetDeviceIndex = -1;
    if (local_device == device) {
        return ACL_ERROR_NONE;
    }

    if (c10_npu::NeedMainThreadBind()) {
        c10_npu::SetThreadAffinity(device);
    }

    aclError err = aclrtSetDevice(device);
    if (err == ACL_ERROR_NONE) {
        local_device = device;
        std::lock_guard<std::recursive_mutex> lock(mtx);
        if (used_devices.find(local_device) == used_devices.end()) {
            NPU_CHECK_ERROR_WITHOUT_UCE(aclrtGetCurrentContext(&used_devices[local_device]));
        }
    }
    return err;
}
aclError ResetUsedDevices()
{
    std::lock_guard<std::recursive_mutex> lock(mtx);
    ActiveContextReset reset;
    for (const auto it : used_devices) {
        aclError err = aclrtResetDevice(it.first);
        if (err != ACL_ERROR_NONE) {
            return err;
        }
    }
    used_devices.clear();
    return ACL_ERROR_NONE;
}
bool isDeviceCtxActive(int32_t device)
{
    if (at_npu::native::env::CheckCompatibleImpl()) {
        count_context_read(3);
        return hasPrimaryContext(device);
    }
    const uint64_t bit = context_bit(device);
    if (bit && (active_context_mask.load(std::memory_order_acquire) & bit)) {
        count_context_read(0);
        return true;
    }
    std::lock_guard<std::recursive_mutex> lock(mtx);
    count_context_read(1);
    if (used_devices.find(device) == used_devices.end()) {
        return false;
    }
    const bool present = used_devices[device] != nullptr;
    if (present && bit && context_reset_depth == 0) {
        active_context_mask.fetch_or(bit, std::memory_order_release);
        count_context_read(2);
    }
    return present;
}
aclError MaybeSetDevice(c10::DeviceIndex device)
{
    if (isDeviceCtxActive(device)) {
        NPU_CHECK_ERROR_WITHOUT_UCE(SetDevice(device));
    } else {
        ASCEND_LOGI("MaybeSetDevice: NPU device %d has not been initialized! We will set targetDeviceIndex.", device);
        targetDeviceIndex = device;
    }
    return ACL_ERROR_NONE;
}
void LazySetDevice(c10::DeviceIndex device)
{
    if (local_device != device) {
        aclError err = aclrtSetDevice(device);
        if (err == ACL_ERROR_NONE) {
            local_device = device;
            std::lock_guard<std::recursive_mutex> lock(mtx);
            if (used_devices.find(local_device) == used_devices.end()) {
                NPU_CHECK_ERROR_WITHOUT_UCE(aclrtGetCurrentContext(&used_devices[local_device]));
            }
        }
        NPU_CHECK_ERROR_WITHOUT_UCE(err);
    }
}
} // namespace c10_npu

int main()
{
    using namespace c10_npu;
    const bool enabled=std::string(std::getenv("NPU_CONTEXT_POSITIVE_MASK"))=="1";
    assert(!isDeviceCtxActive(0) && !isDeviceCtxActive(64) && !isDeviceCtxActive(-1));
    assert(MaybeSetDevice(2)==0 && targetDeviceIndex==2);
    std::cout<<"absent states and lazy target\n";
    fail_set=true;
    assert(SetDevice(0)!=0 && !isDeviceCtxActive(0)); fail_set=false;
    fail_context=true;
    try {SetDevice(0);assert(false);} catch(const std::runtime_error&) {}
    assert(!isDeviceCtxActive(0)); fail_context=false;
    assert(ResetUsedDevices()==0);
    local_device=-1;
    null_context=true; assert(SetDevice(0)==0 && !isDeviceCtxActive(0)); null_context=false;
    assert(ResetUsedDevices()==0); local_device=-1;
    std::cout<<"SetDevice failure, context error and explicit null never publish positive\n";
    assert(SetDevice(0)==0); assert(isDeviceCtxActive(0));
    uint64_t h=npu_active_context_counter(0);
    assert(isDeviceCtxActive(0) && npu_active_context_counter(0)-h==uint64_t(enabled));
    LazySetDevice(63); assert(isDeviceCtxActive(63) && isDeviceCtxActive(63));
    LazySetDevice(64); assert(isDeviceCtxActive(64) && isDeviceCtxActive(64));
    assert(isDeviceCtxActive(256) && isDeviceCtxActive(-256));
    assert(!isDeviceCtxActive(65)); // no change to original int8-key conversion on table fallback
    std::cout<<"0 and 63 cacheable, 64, negative, above-range preserve original table semantics\n";
    at_npu::native::env::compatible=true;
    primary_active=false; assert(!isDeviceCtxActive(0));
    primary_active=true; assert(isDeviceCtxActive(0));
    try {isDeviceCtxActive(-1);assert(false);}catch(const std::runtime_error&) {}
    assert(primary_calls==2);
    at_npu::native::env::compatible=false;
    std::cout<<"compatibility re-queries primary context, including invalid-device error\n";
    // Fail mid-reset: the unmodified used_devices map remains authoritative even if a mock
    // device has already been reset. An external reader blocks rather than observing stale bits.
    std::promise<void> entered, release;
    std::shared_future<void> may_exit=release.get_future().share();
    bool callback_first=true;
    reset_callback=[&] {
        if(callback_first) {callback_first=false;assert(isDeviceCtxActive(0));entered.set_value();may_exit.wait();}
    };
    auto resetting=std::async(std::launch::async,[]{return ResetUsedDevices();});
    entered.get_future().wait();
    std::promise<void> launched;
    auto reading=std::async(std::launch::async,[&]{launched.set_value();return isDeviceCtxActive(0);});
    launched.get_future().wait();
    assert(reading.wait_for(std::chrono::milliseconds(40))==std::future_status::timeout);
    release.set_value();
    assert(resetting.get()==0 && !reading.get() && !isDeviceCtxActive(0));
    reset_callback={};
    std::cout<<"successful reset with recursive lookup and concurrent reader\n";
    local_device=-1;LazySetDevice(0);LazySetDevice(1);
    assert(isDeviceCtxActive(0) && isDeviceCtxActive(1));
    unsigned calls=0;
    reset_callback=[&] { if(++calls==2) fail_reset=true; };
    assert(ResetUsedDevices()!=0); fail_reset=false;reset_callback={};
    assert(active_context_mask.load()==0 && isDeviceCtxActive(0) && isDeviceCtxActive(1));
    throw_reset=true;
    try {ResetUsedDevices();assert(false);}catch(const std::runtime_error&){}
    throw_reset=false;
    assert(context_reset_depth==0 && active_context_mask.load()==0 && isDeviceCtxActive(0));
    assert(ResetUsedDevices()==0 && !isDeviceCtxActive(0));
    std::cout<<"partial reset failure and unwinding retain original table and refill under lock\n";
    return 0;
}

"""Exercise both native embedding entries in independent eager processes on the reserved device."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import time

def worker(args):
    import torch
    import torch_npu
    torch.npu.set_device(0)
    shapes = json.loads(Path(args.schedule).read_text())
    assert len(shapes)==60 and len(set(map(tuple,shapes)))==60
    streams = [torch.npu.current_stream(), torch.npu.Stream()]
    table_ids = (0, 1, 15, 16, 31, 32)
    fwd = torch.ops.aten.embedding.default
    back = torch.ops.aten.embedding_dense_backward.default
    def make(batch, length, owner=0):
        cpu_ids = ((torch.arange(batch*length*4096).reshape(batch,length,1024,4)+owner*5)%13)
        cpu_grad = ((torch.arange(batch*length*4*64).reshape(batch,length,4,64)+owner)%3-1).to(torch.bfloat16)
        cpu_weight = ((torch.arange(64*64).reshape(64,64)+owner)%31).to(torch.bfloat16)
        return (cpu_weight,cpu_ids,cpu_grad),(cpu_weight.npu(),cpu_ids.npu(),cpu_grad.npu())
    if args.mode=="gate":
        checked=0
        for n,(b,s) in enumerate([shapes[4],shapes[5],shapes[6],shapes[-1],shapes[4]]):
            pending=[]
            for owner,stream in enumerate(streams):
                with torch.npu.stream(stream):
                    (cw,ci,cg),(w,i,g)=make(b,s,owner+n)
                    for t in table_ids:
                        idx=i[:,:,t,:]
                        cpu=ci[:,:,t,:]
                        pad=7 if owner else -1
                        pending.append((fwd(w,idx,pad,False,False), fwd(cw,cpu,pad,False,False)))
                        pending.append((back(g,idx,64,pad,False), back(cg,cpu,64,pad,False)))
            torch.npu.synchronize()
            assert all(torch.equal(device.cpu(),expected) for device,expected in pending)
            checked+=len(pending)
        result=dict(checked=checked,streams=2)
    else:
        windows={}
        for label,cohort in (("1x19",[shapes[4]]),("2x14",[shapes[5]]),("all",shapes)):
            banks=[make(b,s)[1] for b,s in cohort]
            def launch():
                calls=0
                for _ in range(2 if len(banks)>1 else 24):
                    for w,i,g in banks:
                        for t in (0,16):
                            idx=i[:,:,t,:]
                            fwd(w,idx,-1,False,False)
                            back(g,idx,64,-1,False)
                            calls+=2
                return calls
            launch()
            torch.npu.synchronize()
            measured=[]
            for _ in range(9):
                start=time.perf_counter_ns()
                count=launch()
                torch.npu.synchronize()
                measured.append((time.perf_counter_ns()-start)/1000/count)
            windows[label]=dict(calls_per_window=count,us_per_call=measured,median=statistics.median(measured))
        result=dict(windows=windows)
    mapped={line.split()[-1] for line in Path("/proc/self/maps").read_text().splitlines() if line.endswith("/libtorch_npu.so")}
    expected = Path("/artifacts/infra-only-20261128/stock-overlay/goal70-embedding-workspace/torch_npu/lib/libtorch_npu.so")
    receipt = json.loads((Path(__file__).parent/"build/receipt.json").read_bytes())
    assert len(mapped)==1 and Path(next(iter(mapped))).resolve()==expected.resolve(), mapped
    assert hashlib.sha256(expected.read_bytes()).hexdigest()==receipt["sha256"]
    result["mapped_library"] = str(expected)
    print("RESULT "+json.dumps(result),flush=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("schedule")
    parser.add_argument("output")
    parser.add_argument("--mode",choices=["gate","timing"])
    args=parser.parse_args()
    if args.mode:
        worker(args)
        return
    out=Path(args.output)
    summary=[]
    for mode,order in (("gate","ab"),("timing","ab"),("timing","ba")):
        for leg in order:
            env=dict(os.environ,NPU_EMBED_WS_DATAPTR=str(int(leg=="b")),
                     NPU_EMBED_WS_COUNT=str(int(mode=="gate")),ACLNN_CACHE_LIMIT="65536",
                     NPU_DYNAMIC_REBASE_FORWARD="1",NPU_DYNAMIC_REBASE_INDICES="1")
            proc=subprocess.run([sys.executable,"-B",__file__,args.schedule,args.output,"--mode",mode],
                                env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            (out.parent/(mode+"-"+order+"-"+leg+".log")).write_text(proc.stdout)
            proc.check_returncode()
            result=json.loads(re.search(r"^RESULT (.*)$",proc.stdout,re.M)[1])
            counters=[list(map(int,m)) for m in re.findall(r"EMBED_WORKSPACE raw=(\d+) tensor=(\d+) zero=(\d+) bytes=(\d+)",proc.stdout)]
            if mode=="gate":
                assert result["checked"]==120 and counters
                result["counts"]=[sum(column) for column in zip(*counters)]
            summary.append(dict(mode=mode,order=order,leg=leg,**result))
            out.write_text(json.dumps(summary,indent=2))
        if mode=="gate":
            a,b=summary[0]["counts"],summary[1]["counts"]
            assert a[0]==0 and b[1]==0 and a[1]==b[0] and a[2:]==b[2:],(a,b)
            if b[0]==0:
                return

if __name__=="__main__":
    main()

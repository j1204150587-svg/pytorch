#pragma once

#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include "torch_npu/csrc/core/npu/NPUCachingAllocator.h"
#include "torch_npu/csrc/core/npu/NPUGraphsUtils.h"
#include "torch_npu/csrc/framework/utils/OpPreparation.h"
#ifndef BUILD_LIBTORCH
#include "torch_npu/csrc/profiler/utils.h"
#endif

namespace embedding_workspace {
inline bool flag(const char *name)
{
    const char *value = std::getenv(name);
    return value && std::strcmp(value, "1") == 0;
}

struct Counters {
    std::atomic<uint64_t> raw{0}, tensor{0}, zero{0}, bytes{0};
    ~Counters()
    {
        std::fprintf(stderr, "EMBED_WORKSPACE raw=%llu tensor=%llu zero=%llu bytes=%llu\n",
            static_cast<unsigned long long>(raw.load()), static_cast<unsigned long long>(tensor.load()),
            static_cast<unsigned long long>(zero.load()), static_cast<unsigned long long>(bytes.load()));
    }
};

inline void record(bool raw, uint64_t size)
{
    static const bool audit = flag("NPU_EMBED_WS_COUNT");
    if (!audit) {
        return;
    }
    static Counters counters;
    (size == 0 ? counters.zero : raw ? counters.raw : counters.tensor).fetch_add(1, std::memory_order_relaxed);
    counters.bytes.fetch_add(size, std::memory_order_relaxed);
}

class Workspace {
public:
    void *allocate(uint64_t size)
    {
        if (size == 0) {
            record(false, 0);
            return nullptr;
        }
        static const bool enabled = flag("NPU_EMBED_WS_DATAPTR");
        if (enabled && size <= static_cast<uint64_t>(std::numeric_limits<int64_t>::max())
            && c10_npu::option::OptionsManager::GetTaskQueueEnable() == 1
            && c10_npu::currentStreamCaptureStatusMayInitCtx() == c10_npu::CaptureStatus::None) {
#ifndef BUILD_LIBTORCH
            torch_npu::profiler::NPURecordFunction guard;
#endif
            raw_ = c10_npu::NPUCachingAllocator::get()->allocate(size);
            if (raw_.get() != nullptr) {
                record(true, size);
                return raw_.get();
            }
        }
        tensor_ = at_npu::native::OpPreparation::unsafe_empty_workspace(size);
        record(false, size);
        return const_cast<void *>(tensor_.storage().data());
    }

private:
    c10::DataPtr raw_;
    at::Tensor tensor_;
};
} // namespace embedding_workspace

"""Rebuild only the two embedding call sites against the pinned combined embedding library."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

here = Path(__file__).resolve().parent
study = here.parents[1]
parent = json.loads((study/"embedding/build/build-receipt.json").read_text())
stage = here / "build"
stage.mkdir(exist_ok=False)
source = Path(parent["stage"])
plugin = Path(parent["base"])/"checkout/third_party/op-plugin"
forward = "op_plugin/ops/opapi/EmbeddingKernelNpuOpApi.cpp"
backward = "op_plugin/ops/opapi/StructKernelNpuOpApi.cpp"
common = "op_plugin/utils/op_api_common.h"
helper = "op_plugin/utils/embedding_workspace_handle.h"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(data)

def once(old, needle, change):
    assert old.count(needle)==1, needle
    return old.replace(needle,change)

for name in parent["patched_sources_sha256"]:
    assert sha(source/name)==parent["patched_sources_sha256"][name]
assert sha(Path(parent["library"]))==parent["library_sha256"]
assert parent["library_sha256"]=="4e4adcd8348f437abefb6f48c14b224f4b1b5342b145ddd4b745964f45ec2d8c"
for obj in parent["compile"]:
    assert sha(Path(obj["object"]))==obj["object_sha256"]

# Use a separate template instantiation for the two selected operator call sites.
# Other units keep their original hit_cache specialization.
header=(plugin/common).read_text()
a=header.index("template <typename... Args> bool hit_cache(")
b=header.index("template <typename ...Ts>",a)
fn=header[a:b]
original=fn[fn.index("    void *workspace_addr"):fn.index("    auto acl_call")]
special=once(fn, "bool hit_cache(", "bool hit_cache_embedding_workspace(")
special=once(special,original,"    embedding_workspace::Workspace workspace;\n    void *workspace_addr = workspace.allocate(workspace_size);\n")
# A separate header keeps the original common fast path byte-for-byte identical.
helper_text=(here/"workspace.h").read_text()+"\n"+special
write(stage/helper,helper_text)
for name,op in ((forward,"aclnnEmbedding"),(backward,"aclnnEmbeddingDenseBackward")):
    src=(source/name).read_text()
    src=once(src,'#include "op_plugin/utils/dynamic_embedding_scope.h"',
             '#include "op_plugin/utils/dynamic_embedding_scope.h"\n#include "'+helper+'"')
    i=src.index("    EXEC_NPU_CMD("+op+",")
    j=src.index(");",i)+2
    src=src[:i]+"#define hit_cache hit_cache_embedding_workspace\n"+src[i:j]+"\n#undef hit_cache"+src[j:]
    write(stage/name,src)

diff=[]
for name in (forward,backward,helper):
    old=(source/name).read_text() if (source/name).exists() else ""
    diff.extend(difflib.unified_diff(old.splitlines(True),(stage/name).read_text().splitlines(True),
        fromfile="a/"+name if old else "/dev/null",tofile="b/"+name))
patch=here/"workspace-handle.patch"
write(patch,"".join(diff))
verify=stage/"verify"
verify.mkdir()
for name in (forward,backward):
    write(verify/name,(source/name).read_text())
subprocess.run(["git","apply","--no-index",str(patch)],cwd=verify,check=True)
assert all(sha(verify/name)==sha(stage/name) for name in (forward,backward,helper))
link=list(parent["link"])
units=[]
for item in parent["compile"]:
    if item["source"] not in (forward,backward):
        continue
    name=item["source"]
    obj=stage/(Path(name).name+".o")
    cmd=list(item["argv"])
    cmd[1:1]=["-I"+str(stage)]
    cmd[cmd.index("-o")+1]=str(obj)
    cmd[cmd.index("-c")+1]=str(stage/name)
    subprocess.run(cmd,cwd=item["cwd"],check=True)
    index=link.index(item["object"])
    link[index]=str(obj)
    units.append(dict(source=name,cmd=cmd,object_sha256=sha(obj)))
library=stage/"libtorch_npu.so"
link[link.index("-o")+1]=str(library)
subprocess.run(link,cwd=Path(parent["base"])/"checkout/build",check=True)
write(stage/"receipt.json",json.dumps(dict(library=str(library),sha256=sha(library),parent=parent["library_sha256"],
    sources={n:sha(stage/n) for n in (forward,backward,helper)},common_sha256=sha(plugin/common),patch=sha(patch),units=units,link=link),indent=2))

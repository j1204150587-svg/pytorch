"""Use the archived operator gate, then the original training runner for each pair."""
import json
from pathlib import Path
import re
import subprocess
import sys

here=Path(__file__).resolve().parent
study=here.parents[1]
name="goal70-embedding-workspace"
inner="/artifacts/"+study.name
receipt=json.loads((here/"build/receipt.json").read_bytes())
switch="NPU_EMBED_WS_DATAPTR"
subprocess.run([sys.executable,str(study/"make_recipe.py"),name,receipt["library"],receipt["sha256"],switch,
                "--diagnostic-switch","NPU_EMBED_WS_COUNT"],check=True)
for suffix in ("","-audit"):
    file=study/"recipes"/(name+suffix+".json")
    recipe=json.loads(file.read_bytes())
    recipe["common"].update(ACLNN_CACHE_LIMIT="65536",NPU_DYNAMIC_REBASE_FORWARD="1",NPU_DYNAMIC_REBASE_INDICES="1")
    file.write_text(json.dumps(recipe,indent=2))
micro=here/"micro-verified-map"
if not (micro/"train.exit").exists():
    subprocess.run(["flock","-x","/run/lock/recsys-gr-ds019-npu8-infra-study.lock",sys.executable,
                    str(study/"operator_probe.py"),"--package",inner+"/stock-overlay/"+name,str(micro),
                    inner+"/followup70-20261128/workspace-handle/micro.py","@WORK/configs/dynamic_shapes_npu8.json",
                    "@OUT/results.json"],check=True)
assert (micro/"train.exit").read_text().strip()=="0"
results=json.loads((micro/"results.json").read_bytes())
if results[1]["counts"][0]==0:
    print("No nonzero hot workspaces in the independent gate",flush=True)
    sys.exit(0)
timings=[r for r in results if r["mode"]=="timing"]
deltas=[]
for order in ("ab","ba"):
    legs={r["leg"]:r["windows"] for r in timings if r["order"]==order}
    deltas.append({k:legs["a"][k]["median"]-legs["b"][k]["median"] for k in legs["a"]})
print("microseconds saved per operator",deltas,flush=True)
for mode,order in (("audit","ab"),("no-profiler","ab"),("no-profiler","ba"),("l0","ab"),("l0","ba"),("l1","ab")):
    directory=study/"pairs"/f"{name}-{mode}-{order}"
    if not (directory/"result.json").exists():
        subprocess.run([sys.executable,"-B","runner/host_pair.py","--runner","archived-runner","--recipe",
            "recipes/"+name+("-audit" if mode=="audit" else "")+".json","--out",str(directory),"--mode",mode,
            "--order",order],cwd=study,check=True)
    result=json.loads((directory/"result.json").read_bytes())
    assert result["exit"]==0
    if mode=="audit":
        assert result["audit_passed"] and result["audited_steps"]==8
        counts=[]
        for leg in ("01-A","02-B"):
            log=(Path(result["directory"])/leg/"run.log").read_text(errors="replace")
            rows=[list(map(int,r)) for r in re.findall(r"EMBED_WORKSPACE raw=(\d+) tensor=(\d+) zero=(\d+) bytes=(\d+)",log)]
            assert rows
            counts.append([sum(column) for column in zip(*rows)])
        a,b=counts
        assert a[0]==0 and a[1]==b[0] and b[1]==0 and a[2:]==b[2:],counts
        (here/"counts.json").write_text(json.dumps(counts,indent=2))
        if b[0]==0 or all(d<0 for group in deltas for d in group.values()):
            print("No activation or both microbenchmark orders regress on all cohorts",flush=True)
            break
    print("verified",mode,order,flush=True)

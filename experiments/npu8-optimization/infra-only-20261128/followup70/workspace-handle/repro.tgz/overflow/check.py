"""Exercise original BF16 ZeRO-2 overflow and recovery around real dynamic embedding calls."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import sys

cli=argparse.ArgumentParser()
cli.add_argument("workspace",type=Path)
cli.add_argument("result",type=Path)
cli.add_argument("recipe",type=Path)
cli.add_argument("arm",choices=("A","B"))
args=cli.parse_args()
recipe=json.loads(args.recipe.read_bytes())
os.environ.update(recipe["common"])
os.environ[recipe["switch"]]=recipe[args.arm]
with socket.socket() as s:
    s.bind(("127.0.0.1",0))
    port=s.getsockname()[1]
os.environ.update(LOCAL_RANK="0",RANK="0",WORLD_SIZE="1",MASTER_ADDR="127.0.0.1",MASTER_PORT=str(port),
                  DS_ACCELERATOR="npu",RECSYS_ZERO2_BATCH_OVERFLOW="1")
import torch
import torch_npu
import deepspeed
sys.path.insert(0,str(args.workspace))
import overflow
assert hashlib.sha256(Path(overflow.__file__).read_bytes()).hexdigest()=="b2bb6481d20438ffe07033fab6ea2aa14097cb62c3e7209cb619c503cc427a55"
torch.manual_seed(1234)
torch.npu.set_device(0)
deepspeed.init_distributed(dist_backend="hccl",auto_mpi_discovery=False)
config=json.loads((args.workspace/"configs/deepspeed_zero2_bf16_overflow_on.json").read_bytes())
config.update(train_micro_batch_size_per_gpu=1,train_batch_size=1)
schedule=json.loads((args.workspace/"configs/dynamic_shapes_npu8.json").read_bytes())
class Lookup(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.weight=torch.nn.Parameter(torch.linspace(-.5,.5,4096).reshape(64,64))
    def forward(self,ids):
        values=torch.nn.functional.embedding(ids,self.weight)
        return values.float().mean()
model=Lookup()
opt=torch.optim.AdamW(model.parameters(),lr=.01,foreach=False)
engine,_,_,_=deepspeed.initialize(model=model,optimizer=opt,config=config,dist_init_required=False)
zero=engine.optimizer
scan=overflow.install(zero)
def hash_tensor(t):
    return hashlib.sha256(t.detach().contiguous().reshape(-1).cpu().view(torch.uint8).numpy().tobytes()).hexdigest()
def snapshot():
    masters=zero.single_partition_of_fp32_groups
    return dict(master=[hash_tensor(x) for x in masters],bf16=[hash_tensor(x) for x in zero.bit16_groups_flat],
                adamw=[{k:hash_tensor(v) if torch.is_tensor(v) else v for k,v in zero.optimizer.state.get(x,{}).items()} for x in masters])
results=[]
for i,case in enumerate(("finite","inf","finite","nan","finite","-inf","finite")):
    b,length=schedule[4+i%3]
    parent=(torch.arange(b*length*64*4)%64).reshape(b,length,64,4).npu()
    ids=parent[:,:,3,:]
    loss=engine(ids)
    engine.backward(loss)
    grad,=[g for group in zero.averaged_gradients.values() for g in group if g is not None]
    assert grad.numel()==4096 and grad.dtype==torch.bfloat16
    if case!="finite":
        grad.reshape(-1)[133]=float(case)
    before=snapshot()
    skipped=int(engine.skipped_steps)
    grad_sha=hash_tensor(grad)
    engine.step()
    torch.npu.synchronize()
    after=snapshot()
    expect=case!="finite"
    assert bool(zero.overflow)==expect and int(engine.skipped_steps)-skipped==int(expect)
    assert bool(engine.was_step_applied())!=expect
    assert (before==after)==expect and (expect or before["master"]!=after["master"])
    results.append(dict(shape=[b,length],case=case,loss=float(loss),grad_sha256=grad_sha,
                        before=before,after=after,skipped=expect))
libs={x.split()[-1] for x in Path("/proc/self/maps").read_text().splitlines() if x.endswith("/libtorch_npu.so")}
assert libs==set(recipe["libraries"])
for name in libs:
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==recipe["libraries"][name]
assert scan.fast_calls==7 and not scan.fallback_calls and not scan.errors
args.result.write_text(json.dumps(dict(arm=args.arm,switch=recipe["switch"],library_sha=recipe["libraries"],
                                     steps=results,scan=scan.snapshot()),indent=2))
torch.distributed.destroy_process_group()

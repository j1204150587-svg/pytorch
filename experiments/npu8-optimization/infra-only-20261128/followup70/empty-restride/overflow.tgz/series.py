"""Serialize independent injected-overflow probes through both existing NPU8 locks."""
import json
from pathlib import Path
import subprocess
import sys

here=Path(__file__).resolve().parent
study=here.parents[1]
inside="/artifacts/"+study.name
for candidate in ("goal70-empty-stride","goal70-embedding-workspace","goal70-release-ring","goal70-compatible-key"):
    recipe=study/"recipes"/(candidate+"-audit.json")
    settings=json.loads(recipe.read_bytes())
    results=[]
    for arm in "AB":
        path=here/(candidate+"-"+arm)
        if not (path/"train.exit").exists():
            subprocess.run(["flock","-x","/run/lock/recsys-gr-ds019-npu8-infra-study.lock",sys.executable,
                "-B",str(study/"operator_probe.py"),"--package",settings["common"]["PYTHONPATH"],str(path),
                inside+"/followup70-20261128/overflow/check.py","@WORK","@OUT/result.json",
                inside+"/recipes/"+recipe.name,arm],check=True)
        assert (path/"train.exit").read_text().strip()=="0"
        results.append(json.loads((path/"result.json").read_bytes()))
    assert results[0]["steps"]==results[1]["steps"]
    print(candidate,"verified 4 finite updates, 3 skips; both arms agree",flush=True)

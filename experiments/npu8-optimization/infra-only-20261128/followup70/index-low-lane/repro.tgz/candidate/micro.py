"""Validate physical int32 narrowing against a strided low-word view on the target NPU."""
import json
import sys
from pathlib import Path
import torch
import torch_npu

schedule=json.loads(Path(sys.argv[1]).read_bytes())
out=Path(sys.argv[2])
torch.npu.set_device(0)
report=dict(byteorder=sys.byteorder,soc=torch.npu.get_device_name(0),values={},dynamic=[])
def checkpoint():
    out.write_text(json.dumps(report,indent=2))
def low(x):
    raw=x.view(torch.int32)
    return raw[...,::2]
values=[-(1<<63),-(1<<63)+1,-(1<<32)-1,-(1<<32),-(1<<31)-1,-(1<<31),-1,0,1,
        (1<<31)-1,1<<31,(1<<32)-1,1<<32,(1<<32)+1,(1<<63)-1]
x=torch.tensor(values*4,dtype=torch.int64).reshape(-1,4).npu()
actual=x.to(torch.int32).cpu()
half=low(x).cpu()
report["values"]=dict(input=values,actual=actual.view(-1).tolist()[:len(values)],low=half.view(-1).tolist()[:len(values)],
                      equal=torch.equal(actual,half),device_input_dtype=str(x.dtype))
checkpoint()
if not torch.equal(actual,half):
    print("device cast differs for int64 boundary values",flush=True)
    sys.exit(0)
op=torch.ops.aten.embedding_dense_backward.default
gen=torch.Generator().manual_seed(1234)
for i,(b,l) in enumerate(schedule):
    host=torch.randint(0,64,(b,l,64,4),dtype=torch.long,generator=gen)
    ids=host.npu()[:,:,i%64,:]
    lo=low(ids)
    assert lo.untyped_storage().data_ptr()==ids.untyped_storage().data_ptr()
    assert list(lo.stride())==[2*s for s in ids.stride()]
    assert lo.storage_offset()==2*ids.storage_offset()
    assert torch.equal(ids.to(torch.int32).cpu(),lo.cpu())
    grad=torch.randn((b,l,4,64),generator=gen).bfloat16().npu()
    for pad in (-1,7):
        a=op(grad,ids,64,pad,False).cpu()
        z=op(grad,lo,64,pad,False).cpu()
        diff=int((a.view(torch.int16)!=z.view(torch.int16)).sum())
        report["dynamic"].append(dict(shape=[b,l],pad=pad,offset=ids.storage_offset(),mismatch=diff))
        if diff:
            checkpoint()
            print("bitwise mismatch in native gradients",flush=True)
            sys.exit(0)
report["passed"]=True
checkpoint()

"""Rebuild the embedding backward call and descriptor/key generator on their verified parent."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

here=Path(__file__).resolve().parent
study=here.parents[1]
q=json.loads((study/"embedding/build/build-receipt.json").read_bytes())
base=Path(q["stage"])
stage=here/"build"
stage.mkdir(exist_ok=False)
def sha(f):
    return hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert sha(q["library"])==q["library_sha256"]=="4e4adcd8348f437abefb6f48c14b224f4b1b5342b145ddd4b745964f45ec2d8c"
for f,h in q["patched_sources_sha256"].items():
    assert sha(base/f)==h
for item in q["compile"]: assert sha(item["object"])==item["object_sha256"]
heads="op_plugin/utils/dynamic_embedding_scope.h"
impl="op_plugin/utils/dynamic_embedding_scope.inc"
op="op_plugin/ops/opapi/StructKernelNpuOpApi.cpp"
common="op_plugin/utils/op_api_common.cpp"
texts={f:(base/f).read_text() for f in (heads,impl,op,common)}
def replace(f,old,new):
    assert texts[f].count(old)==1,(f,old)
    texts[f]=texts[f].replace(old,new)
replace(heads,"    ~Scope();","    void selectNarrowIndex(const at::Tensor &grad, const at::Tensor &indices, int64_t weights, int64_t padding, bool scale);\n    ~Scope();")
replace(impl,'#include <atomic>','#include <atomic>\n#include "torch_npu/csrc/core/npu/NpuVariables.h"')
replace(impl,"Scope::~Scope()", (here/"narrow.inc").read_text()+"\nScope::~Scope()")
replace(op,"    dynamic_embedding_rebase::Scope scope(indices);","    dynamic_embedding_rebase::Scope scope(indices);\n    scope.selectNarrowIndex(grad_output, indices, num_weights, padding_idx, scale_grad_by_freq);")
replace(common, "    auto st = at_tensor.scalar_type();\n    MEMCPY_TO_BUF(&st, sizeof(st));",
        "    const auto *view = dynamic_embedding_rebase::for_tensor(at_tensor);\n"
        "    const bool narrow = dynamic_embedding_rebase::isNarrow(view);\n"
        "    auto st = narrow ? at::kInt : at_tensor.scalar_type();\n    MEMCPY_TO_BUF(&st, sizeof(st));")
replace(common,"    MEMCPY_TO_BUF(at_tensor.strides().data(), static_cast<int64_t>(at_tensor.sizes().size() * sizeof(int64_t)));\n"
        "    // offset\n    const auto *view = dynamic_embedding_rebase::for_tensor(at_tensor);",
        "    if (narrow) {\n        int64_t strides[] = {2*at_tensor.stride(0), 2*at_tensor.stride(1), 2*at_tensor.stride(2)};\n"
        "        MEMCPY_TO_BUF(strides, sizeof(strides));\n    } else {\n"
        "        MEMCPY_TO_BUF(at_tensor.strides().data(), static_cast<int64_t>(at_tensor.dim()*sizeof(int64_t)));\n    }\n    // offset")
anchor="    at::ScalarType scalar_data_type = at_tensor.scalar_type();"
i=texts[common].index("aclTensor *ConvertType(const at::Tensor &at_tensor)")
j=texts[common].index(anchor,i)
texts[common]=texts[common][:j]+texts[common][j:].replace(anchor,
        "    const bool narrow = dynamic_embedding_rebase::isNarrow(view);\n"
        "    at::ScalarType scalar_data_type = narrow ? at::kInt : at_tensor.scalar_type();",1)
where=texts[common].index("    const auto dimNum",j)
texts[common]=texts[common][:where]+"    if (narrow) {\n        for (auto &s : wrapperStride) { s *= 2; }\n    }\n"+texts[common][where:]
diff=[]
for f,t in texts.items():
    path=stage/f
    path.parent.mkdir(exist_ok=True,parents=True)
    path.write_text(t)
    diff.extend(difflib.unified_diff((base/f).read_text().splitlines(True),t.splitlines(True),fromfile="a/"+f,tofile="b/"+f))
patch=here/"index-low-lane.patch"
patch.write_text("".join(diff))
link=list(q["link"])
units=[]
for obj in q["compile"]:
    f=obj["source"]
    if f not in (op,common): continue
    cmd=list(obj["argv"])
    target=stage/(Path(f).name+".o")
    cmd[1:1]=["-I"+str(stage)]
    cmd[cmd.index("-c")+1]=str(stage/f)
    cmd[cmd.index("-o")+1]=str(target)
    subprocess.run(cmd,cwd=obj["cwd"],check=True)
    link[link.index(obj["object"])]=str(target)
    units.append(dict(file=f,cmd=cmd,sha256=sha(target),cwd=obj["cwd"]))
lib=stage/"libtorch_npu.so"
link[link.index("-o")+1]=str(lib)
subprocess.run(link,cwd=q["link_cwd"],check=True)
(stage/"receipt.json").write_text(json.dumps(dict(parent=q["library_sha256"],pta=q["pta_sha"],plugin=q["op_plugin_sha"],
        original={f:sha(base/f) for f in texts},patched={f:sha(stage/f) for f in texts},units=units,link=link,
        library=str(lib),sha256=sha(lib),patch_sha256=sha(patch)),indent=2))

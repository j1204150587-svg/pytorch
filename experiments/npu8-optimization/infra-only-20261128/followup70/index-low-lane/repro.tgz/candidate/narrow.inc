namespace {
constexpr uint64_t narrowDomain = 0x454d424c4f333201ULL;
struct NarrowAudit {
    uint64_t hit=0, fallback=0;
    ~NarrowAudit() {
        std::fprintf(stderr, "NPU_NARROW_INDEX hit=%llu fallback=%llu\n",
            static_cast<unsigned long long>(hit), static_cast<unsigned long long>(fallback));
    }
};
} // namespace

bool isNarrow(const View *v)
{
    return v && v->domain==narrowDomain;
}

void Scope::selectNarrowIndex(const at::Tensor &grad, const at::Tensor &indices, int64_t weights,
                              int64_t padding, bool scale)
{
    static const bool enabled = flag("NPU_EMBED_NARROW_INDEX");
    static const bool audit = flag("NPU_EMBED_NARROW_AUDIT");
    bool hit = false;
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    if (enabled && count_==1 && weights==64 && !scale && (padding==-1 || (padding>=0 && padding<weights))
        && grad.scalar_type()==at::kBFloat16 && grad.device()==indices.device() && grad.is_contiguous()
        && grad.dim()==4 && grad.size(3)==64 && indices.size(0)<=4 && indices.size(1)>=12 && indices.size(1)<=32
        && grad.size(0)==indices.size(0) && grad.size(1)==indices.size(1) && grad.size(2)==4
        && c10_npu::GetSocVersion()==c10_npu::SocVersion::Ascend910_9362) {
        constexpr int64_t limit = std::numeric_limits<int64_t>::max()/2;
        View &v = views_[0];
        if (v.storage_elements<=limit && indices.stride(0)<=limit && indices.stride(1)<=limit) {
            // The original base denotes the same bytes. Counts and strides now
            // measure four-byte elements, selecting the little-endian low word.
            v.offset *= 2;
            v.storage_elements *= 2;
            v.domain = narrowDomain;
            hit = true;
        }
    }
#endif
    if (audit) {
        static thread_local NarrowAudit counter;
        if (hit) { ++counter.hit; } else { ++counter.fallback; }
    }
}

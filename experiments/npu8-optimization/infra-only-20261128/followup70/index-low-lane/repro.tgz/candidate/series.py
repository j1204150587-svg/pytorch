"""Proceed past each gate only after the physical narrowing, plugin, and training checks pass."""
import json
from pathlib import Path
import re
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
study = here.parents[1]
name = "goal70-index-low-lane"
inner = "/artifacts/" + study.name


def read(path):
    return json.loads(path.read_bytes())


def wait_for(path, seconds):
    end = time.monotonic() + seconds
    while not path.is_file():
        if time.monotonic() >= end:
            raise TimeoutError(str(path))
        time.sleep(5)


wait_for(here/"probe/train.exit", 10800)
if (here/"probe/train.exit").read_text().strip() != "0":
    raise RuntimeError("physical narrowing probe failed; inspect the original run.log")
if not read(here/"probe/result.json").get("passed"):
    print("Physical or gradient equivalence failed; stopped before native gate.", flush=True)
    sys.exit(0)
wait_for(here/"build/receipt.json", 1800)
receipt = read(here/"build/receipt.json")
subprocess.run([sys.executable, str(study/"make_recipe.py"), name, receipt["library"], receipt["sha256"],
                "NPU_EMBED_NARROW_INDEX", "--diagnostic-switch", "NPU_EMBED_NARROW_AUDIT"], check=True)
for suffix in ("", "-audit"):
    f = study/"recipes"/(name+suffix+".json")
    recipe = read(f)
    recipe["common"].update(ACLNN_CACHE_LIMIT="65536", NPU_DYNAMIC_REBASE_INDICES="1", NPU_DYNAMIC_REBASE_FORWARD="1")
    f.write_text(json.dumps(recipe, indent=2))
gate = here/"native-probe"
if not (gate/"train.exit").exists():
    subprocess.run(["flock", "-x", "/run/lock/recsys-gr-ds019-npu8-infra-study.lock", sys.executable,
                    str(study/"operator_probe.py"), "--package", inner+"/stock-overlay/"+name, str(gate),
                    inner+"/followup70-20261128/index-low-lane/native_gate.py",
                    "@WORK/configs/dynamic_shapes_npu8.json", "@OUT/results.json"], check=True)
assert (gate/"train.exit").read_text().strip()=="0" and read(gate/"results.json")["B"]["counts"]==[122, 3]
for mode, order in (("audit","ab"), ("l1","ab"), ("no-profiler","ab"), ("no-profiler","ba"), ("l0","ab"), ("l0","ba")):
    out = study/"pairs"/f"{name}-{mode}-{order}"
    if not (out/"result.json").exists():
        subprocess.run([sys.executable, "-B", "runner/host_pair.py", "--runner", "archived-runner",
                        "--recipe", "recipes/"+name+("-audit" if mode=="audit" else "")+".json",
                        "--out", str(out), "--mode", mode, "--order", order], cwd=study, check=True)
    result = read(out/"result.json")
    assert result["exit"]==0
    if mode=="audit":
        assert result["audit_passed"] and result["audited_steps"]==8
        counts = []
        for leg in ("01-A", "02-B"):
            log = (Path(result["directory"])/leg/"run.log").read_text(errors="replace")
            rows = re.findall(r"NPU_NARROW_INDEX hit=(\d+) fallback=(\d+)", log)
            assert rows
            counts.append([sum(map(int,col)) for col in zip(*rows)])
        (here/"counts.json").write_text(json.dumps(counts,indent=2))
        assert counts[0][0]==0 and sum(counts[0])==sum(counts[1])
        if counts[1][0]==0:
            print("Original training has zero eligible calls.",flush=True)
            break
    if mode=="l1":
        subprocess.run([sys.executable,"-B",str(here/"physical.py"),result["directory"]],check=True)
    print("verified",mode,order,flush=True)

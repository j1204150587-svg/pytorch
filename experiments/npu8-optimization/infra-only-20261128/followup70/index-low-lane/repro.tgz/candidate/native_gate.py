"""Compare the built plugin against the original backward entry and a CPU oracle."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys


def worker(shapes, output):
    import torch
    import torch_npu

    torch.npu.set_device(0)
    here = Path(__file__).parent
    receipt = json.loads((here / "build/receipt.json").read_bytes())
    libs = {Path(l.split()[-1]).resolve() for l in Path("/proc/self/maps").read_text().splitlines()
            if l.endswith("/libtorch_npu.so")}
    expected = Path("/artifacts/infra-only-20261128/stock-overlay/goal70-index-low-lane/torch_npu/lib/libtorch_npu.so")
    assert libs == {expected.resolve()}
    with expected.open("rb") as fp:
        assert hashlib.file_digest(fp, "sha256").hexdigest() == receipt["sha256"]
    backward = torch.ops.aten.embedding_dense_backward.default
    generator = torch.Generator().manual_seed(1234)
    streams = [torch.npu.current_stream(), torch.npu.Stream()]
    state = hashlib.sha256()
    calls = 0
    for i, (batch, length) in enumerate(shapes + [shapes[4]]):
        jobs = []
        for j, stream in enumerate(streams):
            with torch.npu.stream(stream):
                raw = torch.randint(0, 32, (batch, length, 1024, 4), generator=generator)
                dev = raw.npu()
                t = (i * 29 + j * 15) % 1024
                host = raw[:, :, t, :]
                ids = dev[:, :, t, :]
                grad = torch.randint(-5, 6, (batch, length, 4, 64), generator=generator).bfloat16()
                pad = 7 if j else -1
                jobs.append((backward(grad.npu(), ids, 64, pad, False), backward(grad, host, 64, pad, False)))
        torch.npu.synchronize()
        for result, reference in jobs:
            actual = result.cpu().view(torch.int16)
            assert torch.equal(actual, reference.view(torch.int16))
            state.update(actual.numpy().tobytes())
            calls += 1
    b, l = shapes[5]
    ids = torch.zeros((b, l, 4), dtype=torch.int64)
    for dtype, width, weights in [(torch.float32, 64, 64), (torch.bfloat16, 32, 64), (torch.bfloat16, 64, 65)]:
        grad = torch.ones((b, l, 4, width), dtype=dtype)
        assert torch.equal(backward(grad.npu(), ids.npu(), weights, -1, False).cpu(),
                           backward(grad, ids, weights, -1, False))
    Path(output).write_text(json.dumps(dict(dynamic=calls, fallback=3, digest=state.hexdigest(),
                                            library=receipt["sha256"], streams=len(streams)), indent=2))


def main():
    cli = argparse.ArgumentParser()
    cli.add_argument("schedule", type=Path)
    cli.add_argument("output", type=Path)
    cli.add_argument("--worker", action="store_true")
    args = cli.parse_args()
    shapes = json.loads(args.schedule.read_bytes())
    assert len(set(map(tuple, shapes))) == len(shapes) == 60
    if args.worker:
        worker(shapes, args.output)
        return
    summary = {}
    for leg, enabled in [("A", "0"), ("B", "1")]:
        out = args.output.with_suffix("." + leg + ".json")
        env = dict(os.environ, NPU_EMBED_NARROW_INDEX=enabled, NPU_EMBED_NARROW_AUDIT="1",
                   NPU_DYNAMIC_REBASE_INDICES="1", NPU_DYNAMIC_REBASE_FORWARD="1", ACLNN_CACHE_LIMIT="65536")
        child = subprocess.run([sys.executable, "-B", __file__, str(args.schedule), str(out), "--worker"],
                               env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        args.output.with_suffix("." + leg + ".log").write_text(child.stdout)
        child.check_returncode()
        rows = re.findall(r"NPU_NARROW_INDEX hit=(\d+) fallback=(\d+)", child.stdout)
        hit, fallback = [sum(map(int, col)) for col in zip(*rows)]
        summary[leg] = dict(**json.loads(out.read_bytes()), counts=[hit, fallback])
    assert summary["A"]["counts"] == [0, 125] and summary["B"]["counts"] == [122, 3], summary
    assert summary["A"]["digest"] == summary["B"]["digest"]
    args.output.write_text(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
